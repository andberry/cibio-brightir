-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `caches`
--

DROP TABLE IF EXISTS `caches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `caches` (
  `name` varchar(191) NOT NULL,
  `data` mediumtext NOT NULL,
  `expires` datetime NOT NULL,
  PRIMARY KEY (`name`),
  KEY `expires` (`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caches`
--

LOCK TABLES `caches` WRITE;
/*!40000 ALTER TABLE `caches` DISABLE KEYS */;
INSERT INTO `caches` VALUES
('Modules.info','{\"114\":{\"name\":\"PagePermissions\",\"title\":\"Page Permissions\",\"version\":105,\"autoload\":true,\"singular\":true,\"created\":1777585556,\"permanent\":true},\"139\":{\"name\":\"SystemUpdater\",\"title\":\"System Updater\",\"version\":21,\"singular\":true,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"197\":{\"name\":\"AdminThemeUikit\",\"title\":\"Uikit\",\"version\":36,\"icon\":\"smile-o\",\"autoload\":\"template=admin\",\"created\":1777585616,\"configurable\":4},\"32\":{\"name\":\"InputfieldSubmit\",\"title\":\"Submit\",\"version\":103,\"created\":1777585556,\"permanent\":true},\"15\":{\"name\":\"InputfieldPageListSelect\",\"title\":\"Page List Select\",\"version\":101,\"created\":1777585556,\"permanent\":true},\"137\":{\"name\":\"InputfieldPageListSelectMultiple\",\"title\":\"Page List Select Multiple\",\"version\":103,\"created\":1777585556,\"permanent\":true},\"36\":{\"name\":\"InputfieldSelect\",\"title\":\"Select\",\"version\":103,\"created\":1777585556,\"permanent\":true},\"25\":{\"name\":\"InputfieldAsmSelect\",\"title\":\"asmSelect\",\"version\":203,\"created\":1777585556,\"permanent\":true},\"41\":{\"name\":\"InputfieldName\",\"title\":\"Name\",\"version\":100,\"created\":1777585556,\"permanent\":true},\"94\":{\"name\":\"InputfieldDatetime\",\"title\":\"Datetime\",\"version\":108,\"created\":1777585556,\"permanent\":true},\"238\":{\"name\":\"InputfieldIcon\",\"title\":\"Icon\",\"version\":3,\"created\":1777585627},\"86\":{\"name\":\"InputfieldPageName\",\"title\":\"Page Name\",\"version\":106,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"122\":{\"name\":\"InputfieldPassword\",\"title\":\"Password\",\"version\":102,\"created\":1777585556,\"permanent\":true},\"149\":{\"name\":\"InputfieldSelector\",\"title\":\"Selector\",\"version\":28,\"autoload\":\"template=admin\",\"created\":1777585556,\"configurable\":3,\"addFlag\":32},\"78\":{\"name\":\"InputfieldFieldset\",\"title\":\"Fieldset\",\"version\":101,\"created\":1777585556,\"permanent\":true},\"85\":{\"name\":\"InputfieldInteger\",\"title\":\"Integer\",\"version\":105,\"created\":1777585556,\"permanent\":true},\"112\":{\"name\":\"InputfieldPageTitle\",\"title\":\"Page Title\",\"version\":102,\"created\":1777585556,\"permanent\":true},\"40\":{\"name\":\"InputfieldHidden\",\"title\":\"Hidden\",\"version\":101,\"created\":1777585556,\"permanent\":true},\"56\":{\"name\":\"InputfieldImage\",\"title\":\"Images\",\"version\":129,\"created\":1777585556,\"permanent\":true},\"79\":{\"name\":\"InputfieldMarkup\",\"title\":\"Markup\",\"version\":102,\"created\":1777585556,\"permanent\":true},\"30\":{\"name\":\"InputfieldForm\",\"title\":\"Form\",\"version\":107,\"created\":1777585556,\"permanent\":true},\"667\":{\"name\":\"InputfieldTextTags\",\"title\":\"Text Tags\",\"version\":7,\"icon\":\"tags\",\"created\":1777797753},\"155\":{\"name\":\"InputfieldTinyMCE\",\"title\":\"TinyMCE\",\"version\":618,\"icon\":\"keyboard-o\",\"requiresVersions\":{\"ProcessWire\":[\">=\",\"3.0.200\"],\"MarkupHTMLPurifier\":[\">=\",0]},\"created\":1777585556,\"configurable\":4},\"55\":{\"name\":\"InputfieldFile\",\"title\":\"Files\",\"version\":129,\"created\":1777585556,\"permanent\":true},\"38\":{\"name\":\"InputfieldCheckboxes\",\"title\":\"Checkboxes\",\"version\":108,\"created\":1777585556,\"permanent\":true},\"43\":{\"name\":\"InputfieldSelectMultiple\",\"title\":\"Select Multiple\",\"version\":101,\"created\":1777585556,\"permanent\":true},\"37\":{\"name\":\"InputfieldCheckbox\",\"title\":\"Checkbox\",\"version\":106,\"created\":1777585556,\"permanent\":true},\"108\":{\"name\":\"InputfieldURL\",\"title\":\"URL\",\"version\":103,\"created\":1777585556},\"90\":{\"name\":\"InputfieldFloat\",\"title\":\"Float\",\"version\":105,\"created\":1777585556,\"permanent\":true},\"662\":{\"name\":\"InputfieldToggle\",\"title\":\"Toggle\",\"version\":1,\"created\":1777797753},\"39\":{\"name\":\"InputfieldRadios\",\"title\":\"Radio Buttons\",\"version\":106,\"created\":1777585556,\"permanent\":true},\"60\":{\"name\":\"InputfieldPage\",\"title\":\"Page\",\"version\":109,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"131\":{\"name\":\"InputfieldButton\",\"title\":\"Button\",\"version\":100,\"created\":1777585556,\"permanent\":true},\"35\":{\"name\":\"InputfieldTextarea\",\"title\":\"Textarea\",\"version\":103,\"created\":1777585556,\"permanent\":true},\"34\":{\"name\":\"InputfieldText\",\"title\":\"Text\",\"version\":106,\"created\":1777585556,\"permanent\":true},\"80\":{\"name\":\"InputfieldEmail\",\"title\":\"Email\",\"version\":102,\"created\":1777585556},\"10\":{\"name\":\"ProcessLogin\",\"title\":\"Login\",\"version\":109,\"permission\":\"page-view\",\"created\":1777585556,\"configurable\":4,\"permanent\":true},\"14\":{\"name\":\"ProcessPageSort\",\"title\":\"Page Sort and Move\",\"version\":101,\"permission\":\"page-edit\",\"created\":1777585556,\"permanent\":true},\"150\":{\"name\":\"ProcessPageLister\",\"title\":\"Lister\",\"version\":26,\"icon\":\"search\",\"permission\":\"page-lister\",\"created\":1777585556,\"configurable\":true,\"permanent\":true,\"useNavJSON\":true,\"addFlag\":32},\"129\":{\"name\":\"ProcessPageEditImageSelect\",\"title\":\"Page Edit Image\",\"version\":121,\"permission\":\"page-edit\",\"singular\":1,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"48\":{\"name\":\"ProcessField\",\"title\":\"Fields\",\"version\":114,\"icon\":\"cube\",\"permission\":\"field-admin\",\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true,\"addFlag\":32},\"233\":{\"name\":\"ProcessLogger\",\"title\":\"Logs\",\"version\":2,\"icon\":\"tree\",\"permission\":\"logs-view\",\"singular\":1,\"created\":1777585627,\"useNavJSON\":true},\"66\":{\"name\":\"ProcessUser\",\"title\":\"Users\",\"version\":107,\"icon\":\"group\",\"permission\":\"user-admin\",\"created\":1777585556,\"configurable\":\"ProcessUserConfig.php\",\"permanent\":true,\"useNavJSON\":true},\"104\":{\"name\":\"ProcessPageSearch\",\"title\":\"Page Search\",\"version\":108,\"permission\":\"page-edit\",\"singular\":1,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"17\":{\"name\":\"ProcessPageAdd\",\"title\":\"Page Add\",\"version\":109,\"icon\":\"plus-circle\",\"permission\":\"page-edit\",\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true},\"121\":{\"name\":\"ProcessPageEditLink\",\"title\":\"Page Edit Link\",\"version\":112,\"icon\":\"link\",\"permission\":\"page-edit\",\"singular\":true,\"created\":1777585556,\"configurable\":4,\"permanent\":true},\"47\":{\"name\":\"ProcessTemplate\",\"title\":\"Templates\",\"version\":114,\"icon\":\"cubes\",\"permission\":\"template-admin\",\"created\":1777585556,\"configurable\":4,\"permanent\":true,\"useNavJSON\":true},\"12\":{\"name\":\"ProcessPageList\",\"title\":\"Page List\",\"version\":124,\"icon\":\"sitemap\",\"permission\":\"page-edit\",\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true},\"138\":{\"name\":\"ProcessProfile\",\"title\":\"User Profile\",\"version\":105,\"permission\":\"profile-edit\",\"singular\":1,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"182\":{\"name\":\"ProcessRecentPages\",\"title\":\"Recent Pages\",\"version\":2,\"icon\":\"clock-o\",\"permission\":\"page-edit-recent\",\"singular\":1,\"created\":1777585616,\"useNavJSON\":true,\"nav\":[{\"url\":\"?edited=1\",\"label\":\"Edited\",\"icon\":\"users\",\"navJSON\":\"navJSON\\/?edited=1\"},{\"url\":\"?added=1\",\"label\":\"Created\",\"icon\":\"users\",\"navJSON\":\"navJSON\\/?added=1\"},{\"url\":\"?edited=1&me=1\",\"label\":\"Edited by me\",\"icon\":\"user\",\"navJSON\":\"navJSON\\/?edited=1&me=1\"},{\"url\":\"?added=1&me=1\",\"label\":\"Created by me\",\"icon\":\"user\",\"navJSON\":\"navJSON\\/?added=1&me=1\"},{\"url\":\"another\\/\",\"label\":\"Add another\",\"icon\":\"plus-circle\",\"navJSON\":\"anotherNavJSON\\/\"}]},\"134\":{\"name\":\"ProcessPageType\",\"title\":\"Page Type\",\"version\":101,\"singular\":1,\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true,\"addFlag\":32},\"50\":{\"name\":\"ProcessModule\",\"title\":\"Modules\",\"version\":121,\"permission\":\"module-admin\",\"created\":1777585556,\"permanent\":true,\"useNavJSON\":true,\"nav\":[{\"url\":\"?site#tab_site_modules\",\"label\":\"Site\",\"icon\":\"plug\",\"navJSON\":\"navJSON\\/?site=1\"},{\"url\":\"?core#tab_core_modules\",\"label\":\"Core\",\"icon\":\"plug\",\"navJSON\":\"navJSON\\/?core=1\"},{\"url\":\"?configurable#tab_configurable_modules\",\"label\":\"Configure\",\"icon\":\"gear\",\"navJSON\":\"navJSON\\/?configurable=1\"},{\"url\":\"?install#tab_install_modules\",\"label\":\"Install\",\"icon\":\"sign-in\",\"navJSON\":\"navJSON\\/?install=1\"},{\"url\":\"?new#tab_new_modules\",\"label\":\"New\",\"icon\":\"plus\"},{\"url\":\"?reset=1\",\"label\":\"Refresh\",\"icon\":\"refresh\"}]},\"87\":{\"name\":\"ProcessHome\",\"title\":\"Admin Home\",\"version\":101,\"permission\":\"page-view\",\"created\":1777585556,\"permanent\":true},\"68\":{\"name\":\"ProcessRole\",\"title\":\"Roles\",\"version\":104,\"icon\":\"gears\",\"permission\":\"role-admin\",\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true},\"109\":{\"name\":\"ProcessPageTrash\",\"title\":\"Page Trash\",\"version\":103,\"singular\":1,\"created\":1777585556,\"permanent\":true},\"136\":{\"name\":\"ProcessPermission\",\"title\":\"Permissions\",\"version\":101,\"icon\":\"gear\",\"permission\":\"permission-admin\",\"singular\":1,\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true},\"83\":{\"name\":\"ProcessPageView\",\"title\":\"Page View\",\"version\":106,\"permission\":\"page-view\",\"created\":1777585556,\"permanent\":true},\"76\":{\"name\":\"ProcessList\",\"title\":\"List\",\"version\":101,\"permission\":\"page-view\",\"created\":1777585556,\"permanent\":true},\"7\":{\"name\":\"ProcessPageEdit\",\"title\":\"Page Edit\",\"version\":112,\"icon\":\"edit\",\"permission\":\"page-edit\",\"singular\":1,\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true},\"723\":{\"name\":\"TextformatterMarkdownExtra\",\"title\":\"Markdown\\/Parsedown Extra\",\"version\":180,\"singular\":1,\"created\":1777798259,\"configurable\":4},\"61\":{\"name\":\"TextformatterEntities\",\"title\":\"HTML Entity Encoder (htmlspecialchars)\",\"version\":100,\"created\":1777585556},\"98\":{\"name\":\"MarkupPagerNav\",\"title\":\"Pager (Pagination) Navigation\",\"version\":105,\"created\":1777585556},\"113\":{\"name\":\"MarkupPageArray\",\"title\":\"PageArray Markup\",\"version\":100,\"autoload\":true,\"singular\":true,\"created\":1777585556},\"156\":{\"name\":\"MarkupHTMLPurifier\",\"title\":\"HTML Purifier\",\"version\":497,\"created\":1777585556},\"67\":{\"name\":\"MarkupAdminDataTable\",\"title\":\"Admin Data Table\",\"version\":108,\"created\":1777585556,\"permanent\":true},\"280\":{\"name\":\"FileValidatorZip\",\"title\":\"ZIP file validator\",\"version\":1,\"icon\":\"file-archive-o\",\"created\":1777585660,\"configurable\":4,\"validates\":[\"zip\"]},\"125\":{\"name\":\"SessionLoginThrottle\",\"title\":\"Session Login Throttle\",\"version\":103,\"autoload\":\"function\",\"singular\":true,\"created\":1777585556,\"configurable\":3},\"103\":{\"name\":\"JqueryTableSorter\",\"title\":\"jQuery Table Sorter Plugin\",\"version\":\"2.31.3\",\"singular\":1,\"created\":1777585556},\"151\":{\"name\":\"JqueryMagnific\",\"title\":\"jQuery Magnific Popup\",\"version\":\"1.1.0\",\"singular\":1,\"created\":1777585556},\"116\":{\"name\":\"JqueryCore\",\"title\":\"jQuery Core\",\"version\":\"1.12.4\",\"singular\":true,\"created\":1777585556,\"permanent\":true},\"45\":{\"name\":\"JqueryWireTabs\",\"title\":\"jQuery Wire Tabs Plugin\",\"version\":110,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"117\":{\"name\":\"JqueryUI\",\"title\":\"jQuery UI\",\"version\":\"1.10.4\",\"singular\":true,\"created\":1777585556,\"permanent\":true},\"115\":{\"name\":\"PageRender\",\"title\":\"Page Render\",\"version\":105,\"autoload\":true,\"singular\":true,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"696\":{\"name\":\"FieldtypeOptions\",\"title\":\"Select Options\",\"version\":2,\"singular\":1,\"created\":1777797930},\"1\":{\"name\":\"FieldtypeTextarea\",\"title\":\"Textarea\",\"version\":107,\"created\":1777585556,\"permanent\":true},\"89\":{\"name\":\"FieldtypeFloat\",\"title\":\"Float\",\"version\":108,\"singular\":1,\"created\":1777585556,\"permanent\":true},\"135\":{\"name\":\"FieldtypeURL\",\"title\":\"URL\",\"version\":101,\"singular\":1,\"created\":1777585556,\"permanent\":true},\"57\":{\"name\":\"FieldtypeImage\",\"title\":\"Images\",\"version\":102,\"created\":1777585556,\"configurable\":4,\"permanent\":true},\"84\":{\"name\":\"FieldtypeInteger\",\"title\":\"Integer\",\"version\":102,\"created\":1777585556,\"permanent\":true},\"107\":{\"name\":\"FieldtypeFieldsetTabOpen\",\"title\":\"Fieldset in Tab (Open)\",\"version\":100,\"singular\":1,\"created\":1777585556,\"permanent\":true},\"29\":{\"name\":\"FieldtypeEmail\",\"title\":\"E-Mail\",\"version\":101,\"singular\":true,\"created\":1777585556},\"27\":{\"name\":\"FieldtypeModule\",\"title\":\"Module Reference\",\"version\":102,\"singular\":true,\"created\":1777585556,\"permanent\":true},\"106\":{\"name\":\"FieldtypeFieldsetClose\",\"title\":\"Fieldset (Close)\",\"version\":100,\"singular\":1,\"created\":1777585556,\"permanent\":true},\"97\":{\"name\":\"FieldtypeCheckbox\",\"title\":\"Checkbox\",\"version\":101,\"singular\":true,\"created\":1777585556,\"permanent\":true},\"111\":{\"name\":\"FieldtypePageTitle\",\"title\":\"Page Title\",\"version\":100,\"singular\":true,\"created\":1777585556,\"permanent\":true},\"3\":{\"name\":\"FieldtypeText\",\"title\":\"Text\",\"version\":102,\"created\":1777585556,\"permanent\":true},\"105\":{\"name\":\"FieldtypeFieldsetOpen\",\"title\":\"Fieldset (Open)\",\"version\":101,\"singular\":1,\"created\":1777585556,\"permanent\":true},\"28\":{\"name\":\"FieldtypeDatetime\",\"title\":\"Datetime\",\"version\":105,\"created\":1777585556},\"677\":{\"name\":\"FieldtypeRepeater\",\"title\":\"Repeater\",\"version\":113,\"installs\":[\"InputfieldRepeater\"],\"autoload\":true,\"singular\":true,\"created\":1777797837,\"configurable\":3},\"679\":{\"name\":\"FieldtypeFieldsetPage\",\"title\":\"Fieldset (Page)\",\"version\":1,\"requiresVersions\":{\"FieldtypeRepeater\":[\">=\",0]},\"autoload\":true,\"singular\":true,\"created\":1777797837,\"configurable\":3},\"678\":{\"name\":\"InputfieldRepeater\",\"title\":\"Repeater\",\"version\":111,\"requiresVersions\":{\"FieldtypeRepeater\":[\">=\",0]},\"created\":1777797837},\"4\":{\"name\":\"FieldtypePage\",\"title\":\"Page Reference\",\"version\":107,\"autoload\":true,\"singular\":true,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"133\":{\"name\":\"FieldtypePassword\",\"title\":\"Password\",\"version\":101,\"singular\":true,\"created\":1777585556,\"permanent\":true},\"6\":{\"name\":\"FieldtypeFile\",\"title\":\"Files\",\"version\":107,\"created\":1777585556,\"configurable\":4,\"permanent\":true},\"739\":{\"name\":\"InputfieldColor\",\"title\":\"Color\",\"version\":116,\"created\":1777798842},\"738\":{\"name\":\"FieldtypeColor\",\"title\":\"Color\",\"version\":118,\"installs\":[\"InputfieldColor\"],\"singular\":1,\"created\":1777798842},\"750\":{\"name\":\"InputfieldPageAutocomplete\",\"title\":\"Page Auto Complete\",\"version\":113}}','2010-04-08 03:10:01'),
('Modules.site/modules/','FieldtypeColor/FieldtypeOptionsColor.module\nFieldtypeColor/InputfieldColor.module\nFieldtypeColor/FieldtypeColor.module','2010-04-08 03:10:01'),
('Modules.wire/modules/','PagePermissions.module\nSystem/SystemUpdater/SystemUpdater.module\nSystem/SystemNotifications/SystemNotifications.module\nSystem/SystemNotifications/FieldtypeNotifications.module\nLanguageSupport/FieldtypeTextLanguage.module\nLanguageSupport/ProcessLanguageTranslator.module\nLanguageSupport/LanguageTabs.module\nLanguageSupport/LanguageSupportFields.module\nLanguageSupport/ProcessLanguage.module\nLanguageSupport/FieldtypePageTitleLanguage.module\nLanguageSupport/FieldtypeTextareaLanguage.module\nLanguageSupport/LanguageSupportPageNames.module\nLanguageSupport/LanguageSupport.module\nPage/PageFrontEdit/PageFrontEdit.module\nAdminTheme/AdminThemeReno/AdminThemeReno.module\nAdminTheme/AdminThemeUikit/AdminThemeUikit.module\nAdminTheme/AdminThemeDefault/AdminThemeDefault.module\nPagePaths.module\nInputfield/InputfieldSubmit/InputfieldSubmit.module\nInputfield/InputfieldCKEditor/InputfieldCKEditor.module\nInputfield/InputfieldPageListSelect/InputfieldPageListSelect.module\nInputfield/InputfieldPageListSelect/InputfieldPageListSelectMultiple.module\nInputfield/InputfieldSelect.module\nInputfield/InputfieldAsmSelect/InputfieldAsmSelect.module\nInputfield/InputfieldName.module\nInputfield/InputfieldDatetime/InputfieldDatetime.module\nInputfield/InputfieldIcon/InputfieldIcon.module\nInputfield/InputfieldPageName/InputfieldPageName.module\nInputfield/InputfieldPassword/InputfieldPassword.module\nInputfield/InputfieldSelector/InputfieldSelector.module\nInputfield/InputfieldFieldset.module\nInputfield/InputfieldInteger.module\nInputfield/InputfieldPageTitle/InputfieldPageTitle.module\nInputfield/InputfieldHidden.module\nInputfield/InputfieldImage/InputfieldImage.module\nInputfield/InputfieldMarkup.module\nInputfield/InputfieldForm.module\nInputfield/InputfieldTextTags/InputfieldTextTags.module\nInputfield/InputfieldTinyMCE/InputfieldTinyMCE.module.php\nInputfield/InputfieldFile/InputfieldFile.module\nInputfield/InputfieldCheckboxes/InputfieldCheckboxes.module\nInputfield/InputfieldSelectMultiple.module\nInputfield/InputfieldPageAutocomplete/InputfieldPageAutocomplete.module\nInputfield/InputfieldCheckbox/InputfieldCheckbox.module\nInputfield/InputfieldURL.module\nInputfield/InputfieldFloat.module\nInputfield/InputfieldToggle/InputfieldToggle.module\nInputfield/InputfieldRadios/InputfieldRadios.module\nInputfield/InputfieldPageTable/InputfieldPageTable.module\nInputfield/InputfieldPage/InputfieldPage.module\nInputfield/InputfieldButton.module\nInputfield/InputfieldTextarea.module\nInputfield/InputfieldText/InputfieldText.module\nInputfield/InputfieldEmail.module\nProcess/ProcessLogin/ProcessLogin.module\nProcess/ProcessPageSort.module\nProcess/ProcessPageLister/ProcessPageLister.module\nProcess/ProcessPageEditImageSelect/ProcessPageEditImageSelect.module\nProcess/ProcessField/ProcessField.module\nProcess/ProcessPagesExportImport/ProcessPagesExportImport.module\nProcess/ProcessLogger/ProcessLogger.module\nProcess/ProcessUser/ProcessUser.module\nProcess/ProcessPageSearch/ProcessPageSearch.module\nProcess/ProcessPageAdd/ProcessPageAdd.module\nProcess/ProcessPageEditLink/ProcessPageEditLink.module\nProcess/ProcessTemplate/ProcessTemplate.module\nProcess/ProcessPageList/ProcessPageList.module\nProcess/ProcessProfile/ProcessProfile.module\nProcess/ProcessPageClone.module\nProcess/ProcessRecentPages/ProcessRecentPages.module\nProcess/ProcessPageType/ProcessPageType.module\nProcess/ProcessModule/ProcessModule.module\nProcess/ProcessHome.module\nProcess/ProcessRole/ProcessRole.module\nProcess/ProcessPageTrash.module\nProcess/ProcessPermission/ProcessPermission.module\nProcess/ProcessForgotPassword/ProcessForgotPassword.module\nProcess/ProcessPageView.module\nProcess/ProcessList.module\nProcess/ProcessCommentsManager/ProcessCommentsManager.module\nProcess/ProcessPageEdit/ProcessPageEdit.module\nTextformatter/TextformatterSmartypants/TextformatterSmartypants.module\nTextformatter/TextformatterNewlineUL.module\nTextformatter/TextformatterStripTags.module\nTextformatter/TextformatterNewlineBR.module\nTextformatter/TextformatterMarkdownExtra/TextformatterMarkdownExtra.module\nTextformatter/TextformatterPstripper.module\nTextformatter/TextformatterEntities.module\nMarkup/MarkupPagerNav/MarkupPagerNav.module\nMarkup/MarkupPageArray.module\nMarkup/MarkupPageFields.module\nMarkup/MarkupRSS.module\nMarkup/MarkupHTMLPurifier/MarkupHTMLPurifier.module\nMarkup/MarkupCache.module\nMarkup/MarkupAdminDataTable/MarkupAdminDataTable.module\nFileValidatorZip.module\nSession/SessionHandlerDB/ProcessSessionDB.module\nSession/SessionHandlerDB/SessionHandlerDB.module\nSession/SessionLoginThrottle/SessionLoginThrottle.module\nPages/PagesVersions/PagesVersions.module.php\nImage/ImageSizerEngineAnimatedGif/ImageSizerEngineAnimatedGif.module\nImage/ImageSizerEngineIMagick/ImageSizerEngineIMagick.module\nFileCompilerTags.module\nPagePathHistory.module\nJquery/JqueryTableSorter/JqueryTableSorter.module\nJquery/JqueryMagnific/JqueryMagnific.module\nJquery/JqueryCore/JqueryCore.module\nJquery/JqueryWireTabs/JqueryWireTabs.module\nJquery/JqueryUI/JqueryUI.module\nLazyCron.module\nPageRender.module\nFieldtype/FieldtypeOptions/FieldtypeOptions.module\nFieldtype/FieldtypeTextarea.module\nFieldtype/FieldtypeDecimal.module\nFieldtype/FieldtypeFloat.module\nFieldtype/FieldtypeURL.module\nFieldtype/FieldtypePageTable.module\nFieldtype/FieldtypeSelector.module\nFieldtype/FieldtypeToggle.module\nFieldtype/FieldtypeImage/FieldtypeImage.module\nFieldtype/FieldtypeInteger.module\nFieldtype/FieldtypeFieldsetTabOpen.module\nFieldtype/FieldtypeEmail.module\nFieldtype/FieldtypeModule.module\nFieldtype/FieldtypeFieldsetClose.module\nFieldtype/FieldtypeCache.module\nFieldtype/FieldtypeComments/CommentFilterAkismet.module\nFieldtype/FieldtypeComments/FieldtypeComments.module\nFieldtype/FieldtypeComments/InputfieldCommentsAdmin.module\nFieldtype/FieldtypeCheckbox.module\nFieldtype/FieldtypePageTitle.module\nFieldtype/FieldtypeText.module\nFieldtype/FieldtypeFieldsetOpen.module\nFieldtype/FieldtypeDatetime.module\nFieldtype/FieldtypeRepeater/FieldtypeFieldsetPage.module\nFieldtype/FieldtypeRepeater/FieldtypeRepeater.module\nFieldtype/FieldtypeRepeater/InputfieldRepeater.module\nFieldtype/FieldtypePage.module\nFieldtype/FieldtypePassword.module\nFieldtype/FieldtypeFile/FieldtypeFile.module','2010-04-08 03:10:01'),
('ModulesUninstalled.info','{\"SystemNotifications\":{\"name\":\"SystemNotifications\",\"title\":\"System Notifications\",\"version\":12,\"versionStr\":\"0.1.2\",\"summary\":\"Adds support for notifications in ProcessWire (currently in development)\",\"icon\":\"bell\",\"installs\":[\"FieldtypeNotifications\"],\"autoload\":true,\"created\":1777585371,\"installed\":false,\"configurable\":\"SystemNotificationsConfig.php\",\"core\":true},\"FieldtypeNotifications\":{\"name\":\"FieldtypeNotifications\",\"title\":\"Notifications\",\"version\":4,\"versionStr\":\"0.0.4\",\"summary\":\"Field that stores user notifications.\",\"requiresVersions\":{\"SystemNotifications\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeTextLanguage\":{\"name\":\"FieldtypeTextLanguage\",\"title\":\"Text (Multi-language)\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Field that stores a single line of text in multiple languages\",\"requiresVersions\":{\"LanguageSupportFields\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"ProcessLanguageTranslator\":{\"name\":\"ProcessLanguageTranslator\",\"title\":\"Language Translator\",\"version\":103,\"versionStr\":\"1.0.3\",\"author\":\"Ryan Cramer\",\"summary\":\"Provides language translation capabilities for ProcessWire core and modules.\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"permission\":\"lang-edit\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"LanguageTabs\":{\"name\":\"LanguageTabs\",\"title\":\"Languages Support - Tabs\",\"version\":117,\"versionStr\":\"1.1.7\",\"author\":\"adamspruijt, ryan, flipzoom\",\"summary\":\"Organizes multi-language fields into tabs for a cleaner easier to use interface.\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"autoload\":\"template=admin\",\"singular\":true,\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"LanguageSupportFields\":{\"name\":\"LanguageSupportFields\",\"title\":\"Languages Support - Fields\",\"version\":101,\"versionStr\":\"1.0.1\",\"author\":\"Ryan Cramer\",\"summary\":\"Required to use multi-language fields.\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"installs\":[\"FieldtypePageTitleLanguage\",\"FieldtypeTextareaLanguage\",\"FieldtypeTextLanguage\"],\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"core\":true},\"ProcessLanguage\":{\"name\":\"ProcessLanguage\",\"title\":\"Languages\",\"version\":103,\"versionStr\":\"1.0.3\",\"author\":\"Ryan Cramer\",\"summary\":\"Manage system languages\",\"icon\":\"language\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"permission\":\"lang-edit\",\"permissions\":{\"lang-edit\":\"Administer languages and static translation files\"},\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true,\"useNavJSON\":true},\"FieldtypePageTitleLanguage\":{\"name\":\"FieldtypePageTitleLanguage\",\"title\":\"Page Title (Multi-Language)\",\"version\":100,\"versionStr\":\"1.0.0\",\"author\":\"Ryan Cramer\",\"summary\":\"Field that stores a page title in multiple languages. Use this only if you want title inputs created for ALL languages on ALL pages. Otherwise create separate languaged-named title fields, i.e. title_fr, title_es, title_fi, etc. \",\"requiresVersions\":{\"LanguageSupportFields\":[\">=\",0],\"FieldtypeTextLanguage\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeTextareaLanguage\":{\"name\":\"FieldtypeTextareaLanguage\",\"title\":\"Textarea (Multi-language)\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Field that stores a multiple lines of text in multiple languages\",\"requiresVersions\":{\"LanguageSupportFields\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"LanguageSupportPageNames\":{\"name\":\"LanguageSupportPageNames\",\"title\":\"Languages Support - Page Names\",\"version\":14,\"versionStr\":\"0.1.4\",\"author\":\"Ryan Cramer\",\"summary\":\"Required to use multi-language page names.\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0],\"LanguageSupportFields\":[\">=\",0]},\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"LanguageSupport\":{\"name\":\"LanguageSupport\",\"title\":\"Languages Support\",\"version\":104,\"versionStr\":\"1.0.4\",\"author\":\"Ryan Cramer\",\"summary\":\"ProcessWire multi-language support.\",\"installs\":[\"ProcessLanguage\",\"ProcessLanguageTranslator\"],\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true,\"addFlag\":32},\"PageFrontEdit\":{\"name\":\"PageFrontEdit\",\"title\":\"Front-End Page Editor\",\"version\":6,\"versionStr\":\"0.0.6\",\"author\":\"Ryan Cramer\",\"summary\":\"Enables front-end editing of page fields.\",\"icon\":\"cube\",\"permissions\":{\"page-edit-front\":\"Use the front-end page editor\"},\"autoload\":true,\"created\":1777585371,\"installed\":false,\"configurable\":\"PageFrontEditConfig.php\",\"core\":true,\"license\":\"MPL 2.0\"},\"AdminThemeReno\":{\"name\":\"AdminThemeReno\",\"title\":\"Reno\",\"version\":17,\"versionStr\":\"0.1.7\",\"author\":\"Tom Reno (Renobird)\",\"summary\":\"Admin theme for ProcessWire 2.5+ by Tom Reno (Renobird)\",\"requiresVersions\":{\"AdminThemeDefault\":[\">=\",0]},\"autoload\":\"template=admin\",\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"AdminThemeUikit\":{\"name\":\"AdminThemeUikit\",\"title\":\"Uikit\",\"version\":36,\"versionStr\":\"0.3.6\",\"summary\":\"Uikit v3 admin theme\",\"icon\":\"smile-o\",\"autoload\":\"template=admin\",\"created\":1777585616,\"installed\":false,\"configurable\":4,\"core\":true},\"PagePaths\":{\"name\":\"PagePaths\",\"title\":\"Page Paths\",\"version\":4,\"versionStr\":\"0.0.4\",\"summary\":\"Enables page paths\\/urls to be queryable by selectors. Also offers potential for improved load performance. Builds an index at install (may take time on a large site).\",\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"InputfieldCKEditor\":{\"name\":\"InputfieldCKEditor\",\"title\":\"CKEditor\",\"version\":172,\"versionStr\":\"1.7.2\",\"summary\":\"CKEditor textarea rich text editor.\",\"installs\":[\"MarkupHTMLPurifier\"],\"created\":1777585371,\"installed\":false,\"core\":true},\"InputfieldIcon\":{\"name\":\"InputfieldIcon\",\"title\":\"Icon\",\"version\":3,\"versionStr\":\"0.0.3\",\"summary\":\"Select an icon\",\"created\":1777585371,\"installed\":false,\"core\":true},\"InputfieldTextTags\":{\"name\":\"InputfieldTextTags\",\"title\":\"Text Tags\",\"version\":7,\"versionStr\":\"0.0.7\",\"summary\":\"Enables input of user entered tags or selection of predefined tags.\",\"icon\":\"tags\",\"created\":1777585371,\"installed\":false,\"core\":true},\"InputfieldPageAutocomplete\":{\"name\":\"InputfieldPageAutocomplete\",\"title\":\"Page Auto Complete\",\"version\":113,\"versionStr\":\"1.1.3\",\"summary\":\"Multiple Page selection using auto completion and sorting capability. Intended for use as an input field for Page reference fields.\",\"created\":1777585371,\"installed\":false,\"core\":true},\"InputfieldToggle\":{\"name\":\"InputfieldToggle\",\"title\":\"Toggle\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"A toggle providing similar input capability to a checkbox but much more configurable.\",\"created\":1777585371,\"installed\":false,\"core\":true},\"InputfieldPageTable\":{\"name\":\"InputfieldPageTable\",\"title\":\"ProFields: Page Table\",\"version\":14,\"versionStr\":\"0.1.4\",\"summary\":\"Inputfield to accompany FieldtypePageTable\",\"requiresVersions\":{\"FieldtypePageTable\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"ProcessPagesExportImport\":{\"name\":\"ProcessPagesExportImport\",\"title\":\"Pages Export\\/Import\",\"version\":1,\"versionStr\":\"0.0.1\",\"author\":\"Ryan Cramer\",\"summary\":\"Enables exporting and importing of pages. Development version, not yet recommended for production use.\",\"icon\":\"paper-plane-o\",\"permission\":\"page-edit-export\",\"created\":1777585371,\"installed\":false,\"core\":true,\"page\":{\"name\":\"export-import\",\"parent\":\"page\",\"title\":\"Export\\/Import\"}},\"ProcessLogger\":{\"name\":\"ProcessLogger\",\"title\":\"Logs\",\"version\":2,\"versionStr\":\"0.0.2\",\"author\":\"Ryan Cramer\",\"summary\":\"View and manage system logs.\",\"icon\":\"tree\",\"permission\":\"logs-view\",\"permissions\":{\"logs-view\":\"Can view system logs\",\"logs-edit\":\"Can manage system logs\"},\"created\":1777585371,\"installed\":false,\"core\":true,\"page\":{\"name\":\"logs\",\"parent\":\"setup\",\"title\":\"Logs\"},\"useNavJSON\":true},\"ProcessPageClone\":{\"name\":\"ProcessPageClone\",\"title\":\"Page Clone\",\"version\":106,\"versionStr\":\"1.0.6\",\"summary\":\"Provides ability to clone\\/copy\\/duplicate pages in the admin. Adds a &quot;copy&quot; option to all applicable pages in the PageList.\",\"permission\":\"page-clone\",\"permissions\":{\"page-clone\":\"Clone a page\",\"page-clone-tree\":\"Clone a tree of pages\"},\"autoload\":\"template=admin\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true,\"page\":{\"name\":\"clone\",\"title\":\"Clone\",\"parent\":\"page\",\"status\":1024}},\"ProcessRecentPages\":{\"name\":\"ProcessRecentPages\",\"title\":\"Recent Pages\",\"version\":2,\"versionStr\":\"0.0.2\",\"author\":\"Ryan Cramer\",\"summary\":\"Shows a list of recently edited pages in your admin.\",\"href\":\"http:\\/\\/modules.processwire.com\\/\",\"icon\":\"clock-o\",\"permission\":\"page-edit-recent\",\"permissions\":{\"page-edit-recent\":\"Can see recently edited pages\"},\"singular\":1,\"created\":1777585616,\"installed\":false,\"core\":true,\"page\":{\"name\":\"recent-pages\",\"parent\":\"page\",\"title\":\"Recent\"},\"useNavJSON\":true,\"nav\":[{\"url\":\"?edited=1\",\"label\":\"Edited\",\"icon\":\"users\",\"navJSON\":\"navJSON\\/?edited=1\"},{\"url\":\"?added=1\",\"label\":\"Created\",\"icon\":\"users\",\"navJSON\":\"navJSON\\/?added=1\"},{\"url\":\"?edited=1&me=1\",\"label\":\"Edited by me\",\"icon\":\"user\",\"navJSON\":\"navJSON\\/?edited=1&me=1\"},{\"url\":\"?added=1&me=1\",\"label\":\"Created by me\",\"icon\":\"user\",\"navJSON\":\"navJSON\\/?added=1&me=1\"},{\"url\":\"another\\/\",\"label\":\"Add another\",\"icon\":\"plus-circle\",\"navJSON\":\"anotherNavJSON\\/\"}]},\"ProcessForgotPassword\":{\"name\":\"ProcessForgotPassword\",\"title\":\"Forgot Password\",\"version\":104,\"versionStr\":\"1.0.4\",\"summary\":\"Provides password reset\\/email capability for the Login process.\",\"permission\":\"page-view\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"ProcessCommentsManager\":{\"name\":\"ProcessCommentsManager\",\"title\":\"Comments\",\"version\":12,\"versionStr\":\"0.1.2\",\"author\":\"Ryan Cramer\",\"summary\":\"Manage comments in your site outside of the page editor.\",\"icon\":\"comments\",\"requiresVersions\":{\"FieldtypeComments\":[\">=\",0]},\"permission\":\"comments-manager\",\"permissions\":{\"comments-manager\":\"Use the comments manager\"},\"created\":1777585371,\"installed\":false,\"searchable\":\"comments\",\"core\":true,\"page\":{\"name\":\"comments\",\"parent\":\"setup\",\"title\":\"Comments\"},\"nav\":[{\"url\":\"?go=approved\",\"label\":\"Approved\"},{\"url\":\"?go=pending\",\"label\":\"Pending\"},{\"url\":\"?go=spam\",\"label\":\"Spam\"},{\"url\":\"?go=all\",\"label\":\"All\"}]},\"TextformatterSmartypants\":{\"name\":\"TextformatterSmartypants\",\"title\":\"SmartyPants Typographer\",\"version\":171,\"versionStr\":\"1.7.1\",\"summary\":\"Smart typography for web sites, by Michel Fortin based on SmartyPants by John Gruber. If combined with Markdown, it should be applied AFTER Markdown.\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true,\"url\":\"https:\\/\\/github.com\\/michelf\\/php-smartypants\"},\"TextformatterNewlineUL\":{\"name\":\"TextformatterNewlineUL\",\"title\":\"Newlines to Unordered List\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Converts newlines to <li> list items and surrounds in an <ul> unordered list. \",\"created\":1777585371,\"installed\":false,\"core\":true},\"TextformatterStripTags\":{\"name\":\"TextformatterStripTags\",\"title\":\"Strip Markup Tags\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Strips HTML\\/XHTML Markup Tags\",\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"TextformatterNewlineBR\":{\"name\":\"TextformatterNewlineBR\",\"title\":\"Newlines to XHTML Line Breaks\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Converts newlines to XHTML line break <br \\/> tags. \",\"created\":1777585371,\"installed\":false,\"core\":true},\"TextformatterMarkdownExtra\":{\"name\":\"TextformatterMarkdownExtra\",\"title\":\"Markdown\\/Parsedown Extra\",\"version\":180,\"versionStr\":\"1.8.0\",\"summary\":\"Markdown\\/Parsedown extra lightweight markup language by Emanuil Rusev. Based on Markdown by John Gruber.\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"TextformatterPstripper\":{\"name\":\"TextformatterPstripper\",\"title\":\"Paragraph Stripper\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Strips paragraph <p> tags that may have been applied by other text formatters before it. \",\"created\":1777585371,\"installed\":false,\"core\":true},\"MarkupPageFields\":{\"name\":\"MarkupPageFields\",\"title\":\"Markup Page Fields\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Adds $page->renderFields() and $page->images->render() methods that return basic markup for output during development and debugging.\",\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"core\":true,\"permanent\":true},\"MarkupRSS\":{\"name\":\"MarkupRSS\",\"title\":\"Markup RSS Feed\",\"version\":105,\"versionStr\":\"1.0.5\",\"summary\":\"Renders an RSS feed. Given a PageArray, renders an RSS feed of them.\",\"icon\":\"rss-square\",\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"MarkupCache\":{\"name\":\"MarkupCache\",\"title\":\"Markup Cache\",\"version\":101,\"versionStr\":\"1.0.1\",\"summary\":\"A simple way to cache segments of markup in your templates. \",\"href\":\"https:\\/\\/processwire.com\\/api\\/modules\\/markupcache\\/\",\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"FileValidatorZip\":{\"name\":\"FileValidatorZip\",\"title\":\"ZIP file validator\",\"version\":1,\"versionStr\":\"0.0.1\",\"author\":\"Ryan Cramer\",\"summary\":\"Validates ZIP files with various configurable rules.\",\"icon\":\"file-archive-o\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true,\"validates\":[\"zip\"]},\"ProcessSessionDB\":{\"name\":\"ProcessSessionDB\",\"title\":\"Sessions\",\"version\":5,\"versionStr\":\"0.0.5\",\"summary\":\"Enables you to browse active database sessions.\",\"icon\":\"dashboard\",\"requiresVersions\":{\"SessionHandlerDB\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true,\"page\":{\"name\":\"sessions-db\",\"parent\":\"access\",\"title\":\"Sessions\"}},\"SessionHandlerDB\":{\"name\":\"SessionHandlerDB\",\"title\":\"Session Handler Database\",\"version\":6,\"versionStr\":\"0.0.6\",\"summary\":\"Installing this module makes ProcessWire store sessions in the database rather than the file system. Note that this module will log you out after install or uninstall.\",\"installs\":[\"ProcessSessionDB\"],\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"PagesVersions\":{\"name\":\"PagesVersions\",\"title\":\"Pages Versions\",\"version\":2,\"versionStr\":\"0.0.2\",\"author\":\"Ryan Cramer\",\"summary\":\"Provides a version control API for pages in ProcessWire.\",\"icon\":\"code-fork\",\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"core\":true},\"ImageSizerEngineAnimatedGif\":{\"name\":\"ImageSizerEngineAnimatedGif\",\"title\":\"Animated GIF Image Sizer\",\"version\":1,\"versionStr\":\"0.0.1\",\"author\":\"Horst Nogajski\",\"summary\":\"Upgrades image manipulations for animated GIFs.\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"ImageSizerEngineIMagick\":{\"name\":\"ImageSizerEngineIMagick\",\"title\":\"IMagick Image Sizer\",\"version\":3,\"versionStr\":\"0.0.3\",\"author\":\"Horst Nogajski\",\"summary\":\"Upgrades image manipulations to use PHP\'s ImageMagick library when possible.\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"FileCompilerTags\":{\"name\":\"FileCompilerTags\",\"title\":\"Tags File Compiler\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Enables {var} or {var.property} variables in markup sections of a file. Can be used with any API variable.\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"PagePathHistory\":{\"name\":\"PagePathHistory\",\"title\":\"Page Path History\",\"version\":8,\"versionStr\":\"0.0.8\",\"summary\":\"Keeps track of past URLs where pages have lived and automatically redirects (301 permanent) to the new location whenever the past URL is accessed.\",\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"LazyCron\":{\"name\":\"LazyCron\",\"title\":\"Lazy Cron\",\"version\":104,\"versionStr\":\"1.0.4\",\"summary\":\"Provides hooks that are automatically executed at various intervals. It is called \'lazy\' because it\'s triggered by a pageview, so the interval is guaranteed to be at least the time requested, rather than exactly the time requested. This is fine for most cases, but you can make it not lazy by connecting this to a real CRON job. See the module file for details. \",\"href\":\"https:\\/\\/processwire.com\\/api\\/modules\\/lazy-cron\\/\",\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeOptions\":{\"name\":\"FieldtypeOptions\",\"title\":\"Select Options\",\"version\":2,\"versionStr\":\"0.0.2\",\"summary\":\"Field that stores single and multi select options.\",\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeDecimal\":{\"name\":\"FieldtypeDecimal\",\"title\":\"Decimal\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Field that stores a decimal number\",\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypePageTable\":{\"name\":\"FieldtypePageTable\",\"title\":\"ProFields: Page Table\",\"version\":8,\"versionStr\":\"0.0.8\",\"summary\":\"A fieldtype containing a group of editable pages.\",\"installs\":[\"InputfieldPageTable\"],\"autoload\":true,\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeSelector\":{\"name\":\"FieldtypeSelector\",\"title\":\"Selector\",\"version\":13,\"versionStr\":\"0.1.3\",\"author\":\"Avoine + ProcessWire\",\"summary\":\"Build a page finding selector visually.\",\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeToggle\":{\"name\":\"FieldtypeToggle\",\"title\":\"Toggle (Yes\\/No)\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Configurable yes\\/no, on\\/off toggle alternative to a checkbox, plus optional \\u201cother\\u201d option.\",\"requiresVersions\":{\"InputfieldToggle\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeCache\":{\"name\":\"FieldtypeCache\",\"title\":\"Cache\",\"version\":102,\"versionStr\":\"1.0.2\",\"summary\":\"Caches the values of other fields for fewer runtime queries. Can also be used to combine multiple text fields and have them all be searchable under the cached field name.\",\"created\":1777585371,\"installed\":false,\"core\":true},\"CommentFilterAkismet\":{\"name\":\"CommentFilterAkismet\",\"title\":\"Comment Filter: Akismet\",\"version\":200,\"versionStr\":\"2.0.0\",\"summary\":\"Uses the Akismet service to identify comment spam. Module plugin for the Comments Fieldtype.\",\"requiresVersions\":{\"FieldtypeComments\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"FieldtypeComments\":{\"name\":\"FieldtypeComments\",\"title\":\"Comments\",\"version\":110,\"versionStr\":\"1.1.0\",\"summary\":\"Field that stores user posted comments for a single Page\",\"installs\":[\"InputfieldCommentsAdmin\"],\"created\":1777585371,\"installed\":false,\"core\":true},\"InputfieldCommentsAdmin\":{\"name\":\"InputfieldCommentsAdmin\",\"title\":\"Comments Admin\",\"version\":104,\"versionStr\":\"1.0.4\",\"summary\":\"Provides an administrative interface for working with comments\",\"requiresVersions\":{\"FieldtypeComments\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeFieldsetPage\":{\"name\":\"FieldtypeFieldsetPage\",\"title\":\"Fieldset (Page)\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Fieldset with fields isolated to separate namespace (page), enabling re-use of fields.\",\"requiresVersions\":{\"FieldtypeRepeater\":[\">=\",0]},\"autoload\":true,\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"FieldtypeRepeater\":{\"name\":\"FieldtypeRepeater\",\"title\":\"Repeater\",\"version\":113,\"versionStr\":\"1.1.3\",\"summary\":\"Maintains a collection of fields that are repeated for any number of times.\",\"installs\":[\"InputfieldRepeater\"],\"autoload\":true,\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"InputfieldRepeater\":{\"name\":\"InputfieldRepeater\",\"title\":\"Repeater\",\"version\":111,\"versionStr\":\"1.1.1\",\"summary\":\"Repeats fields from another template. Provides the input for FieldtypeRepeater.\",\"requiresVersions\":{\"FieldtypeRepeater\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"AdminThemeDefault\":{\"name\":\"AdminThemeDefault\",\"title\":\"Default\",\"version\":14,\"versionStr\":\"0.1.4\",\"summary\":\"Minimal admin theme that supports all ProcessWire features.\",\"autoload\":\"template=admin\",\"created\":1777585371,\"installed\":false,\"configurable\":19,\"core\":true},\"FieldtypeOptionsColor\":{\"name\":\"FieldtypeOptionsColor\",\"title\":\"Select Color Options\",\"version\":102,\"versionStr\":\"1.0.2\",\"summary\":\"Field that stores colors as single and multi select options.\",\"requiresVersions\":{\"FieldtypeOptions\":[\">=\",0]},\"installs\":[\"FieldtypeOptions\"],\"created\":1777798785,\"installed\":false}}','2010-04-08 03:10:01'),
('ModulesVerbose.info','{\"114\":{\"summary\":\"Adds various permission methods to Page objects that are used by Process modules.\",\"core\":true,\"versionStr\":\"1.0.5\"},\"139\":{\"summary\":\"Manages system versions and upgrades.\",\"core\":true,\"versionStr\":\"0.2.1\"},\"197\":{\"summary\":\"Uikit v3 admin theme\",\"core\":true,\"versionStr\":\"0.3.6\"},\"32\":{\"summary\":\"Form submit button\",\"core\":true,\"versionStr\":\"1.0.3\"},\"15\":{\"summary\":\"Selection of a single page from a ProcessWire page tree list\",\"core\":true,\"versionStr\":\"1.0.1\"},\"137\":{\"summary\":\"Selection of multiple pages from a ProcessWire page tree list\",\"core\":true,\"versionStr\":\"1.0.3\"},\"36\":{\"summary\":\"Selection of a single value from a select pulldown\",\"core\":true,\"versionStr\":\"1.0.3\"},\"25\":{\"summary\":\"Multiple selection, progressive enhancement to select multiple\",\"core\":true,\"versionStr\":\"2.0.3\"},\"41\":{\"summary\":\"Text input validated as a ProcessWire name field\",\"core\":true,\"versionStr\":\"1.0.0\"},\"94\":{\"summary\":\"Inputfield that accepts date and optionally time\",\"core\":true,\"versionStr\":\"1.0.8\"},\"238\":{\"summary\":\"Select an icon\",\"core\":true,\"versionStr\":\"0.0.3\"},\"86\":{\"summary\":\"Text input validated as a ProcessWire Page name field\",\"core\":true,\"versionStr\":\"1.0.6\"},\"122\":{\"summary\":\"Password input with confirmation field.\",\"core\":true,\"versionStr\":\"1.0.2\"},\"149\":{\"summary\":\"Build a page finding selector visually.\",\"author\":\"Avoine + ProcessWire\",\"core\":true,\"versionStr\":\"0.2.8\"},\"78\":{\"summary\":\"Groups one or more fields together in a container\",\"core\":true,\"versionStr\":\"1.0.1\"},\"85\":{\"summary\":\"Integer (positive or negative)\",\"core\":true,\"versionStr\":\"1.0.5\"},\"112\":{\"summary\":\"Handles input of Page Title and auto-generation of Page Name (when name is blank)\",\"core\":true,\"versionStr\":\"1.0.2\"},\"40\":{\"summary\":\"Hidden input in a form\",\"core\":true,\"versionStr\":\"1.0.1\"},\"56\":{\"summary\":\"One or more image uploads (sortable)\",\"core\":true,\"versionStr\":\"1.2.9\"},\"79\":{\"summary\":\"Contains any other markup and optionally child Inputfields\",\"core\":true,\"versionStr\":\"1.0.2\"},\"30\":{\"summary\":\"Contains one or more fields in a form\",\"core\":true,\"versionStr\":\"1.0.7\"},\"667\":{\"summary\":\"Enables input of user entered tags or selection of predefined tags.\",\"core\":true,\"versionStr\":\"0.0.7\"},\"155\":{\"summary\":\"TinyMCE rich text editor version 6.8.2.\",\"core\":true,\"versionStr\":\"6.1.8\"},\"55\":{\"summary\":\"One or more file uploads (sortable)\",\"core\":true,\"versionStr\":\"1.2.9\"},\"38\":{\"summary\":\"Multiple checkbox toggles\",\"core\":true,\"versionStr\":\"1.0.8\"},\"43\":{\"summary\":\"Select multiple items from a list\",\"core\":true,\"versionStr\":\"1.0.1\"},\"37\":{\"summary\":\"Single checkbox toggle\",\"core\":true,\"versionStr\":\"1.0.6\"},\"108\":{\"summary\":\"URL in valid format\",\"core\":true,\"versionStr\":\"1.0.3\"},\"90\":{\"summary\":\"Floating point number with precision\",\"core\":true,\"versionStr\":\"1.0.5\"},\"662\":{\"summary\":\"A toggle providing similar input capability to a checkbox but much more configurable.\",\"core\":true,\"versionStr\":\"0.0.1\"},\"39\":{\"summary\":\"Radio buttons for selection of a single item\",\"core\":true,\"versionStr\":\"1.0.6\"},\"60\":{\"summary\":\"Select one or more pages\",\"core\":true,\"versionStr\":\"1.0.9\"},\"131\":{\"summary\":\"Form button element that you can optionally pass an href attribute to.\",\"core\":true,\"versionStr\":\"1.0.0\"},\"35\":{\"summary\":\"Multiple lines of text\",\"core\":true,\"versionStr\":\"1.0.3\"},\"34\":{\"summary\":\"Single line of text\",\"core\":true,\"versionStr\":\"1.0.6\"},\"80\":{\"summary\":\"E-Mail address in valid format\",\"core\":true,\"versionStr\":\"1.0.2\"},\"10\":{\"summary\":\"Login to ProcessWire\",\"core\":true,\"versionStr\":\"1.0.9\"},\"14\":{\"summary\":\"Handles page sorting and moving for PageList\",\"core\":true,\"versionStr\":\"1.0.1\"},\"150\":{\"summary\":\"Admin tool for finding and listing pages by any property.\",\"author\":\"Ryan Cramer\",\"core\":true,\"versionStr\":\"0.2.6\",\"permissions\":{\"page-lister\":\"Use Page Lister\"}},\"129\":{\"summary\":\"Provides image manipulation functions for image fields and rich text editors.\",\"core\":true,\"versionStr\":\"1.2.1\"},\"48\":{\"summary\":\"Edit individual fields that hold page data\",\"core\":true,\"versionStr\":\"1.1.4\",\"searchable\":\"fields\"},\"233\":{\"summary\":\"View and manage system logs.\",\"author\":\"Ryan Cramer\",\"core\":true,\"versionStr\":\"0.0.2\",\"permissions\":{\"logs-view\":\"Can view system logs\",\"logs-edit\":\"Can manage system logs\"},\"page\":{\"name\":\"logs\",\"parent\":\"setup\",\"title\":\"Logs\"}},\"66\":{\"summary\":\"Manage system users\",\"core\":true,\"versionStr\":\"1.0.7\",\"searchable\":\"users\"},\"104\":{\"summary\":\"Provides a page search engine for admin use.\",\"core\":true,\"versionStr\":\"1.0.8\"},\"17\":{\"summary\":\"Add a new page\",\"core\":true,\"versionStr\":\"1.0.9\"},\"121\":{\"summary\":\"Provides a link capability as used by some Fieldtype modules (like rich text editors).\",\"core\":true,\"versionStr\":\"1.1.2\"},\"47\":{\"summary\":\"List and edit the templates that control page output\",\"core\":true,\"versionStr\":\"1.1.4\",\"searchable\":\"templates\"},\"12\":{\"summary\":\"List pages in a hierarchical tree structure\",\"core\":true,\"versionStr\":\"1.2.4\"},\"138\":{\"summary\":\"Enables user to change their password, email address and other settings that you define.\",\"core\":true,\"versionStr\":\"1.0.5\"},\"182\":{\"summary\":\"Shows a list of recently edited pages in your admin.\",\"author\":\"Ryan Cramer\",\"href\":\"http:\\/\\/modules.processwire.com\\/\",\"core\":true,\"versionStr\":\"0.0.2\",\"permissions\":{\"page-edit-recent\":\"Can see recently edited pages\"},\"page\":{\"name\":\"recent-pages\",\"parent\":\"page\",\"title\":\"Recent\"}},\"134\":{\"summary\":\"List, Edit and Add pages of a specific type\",\"core\":true,\"versionStr\":\"1.0.1\"},\"50\":{\"summary\":\"List, edit or install\\/uninstall modules\",\"core\":true,\"versionStr\":\"1.2.1\"},\"87\":{\"summary\":\"Acts as a placeholder Process for the admin root. Ensures proper flow control after login.\",\"core\":true,\"versionStr\":\"1.0.1\"},\"68\":{\"summary\":\"Manage user roles and what permissions are attached\",\"core\":true,\"versionStr\":\"1.0.4\"},\"109\":{\"summary\":\"Handles emptying of Page trash\",\"core\":true,\"versionStr\":\"1.0.3\"},\"136\":{\"summary\":\"Manage system permissions\",\"core\":true,\"versionStr\":\"1.0.1\"},\"83\":{\"summary\":\"All page views are routed through this Process\",\"core\":true,\"versionStr\":\"1.0.6\"},\"76\":{\"summary\":\"Lists the Process assigned to each child page of the current\",\"core\":true,\"versionStr\":\"1.0.1\"},\"7\":{\"summary\":\"Edit a Page\",\"core\":true,\"versionStr\":\"1.1.2\"},\"723\":{\"summary\":\"Markdown\\/Parsedown extra lightweight markup language by Emanuil Rusev. Based on Markdown by John Gruber.\",\"core\":true,\"versionStr\":\"1.8.0\"},\"61\":{\"summary\":\"Entity encode ampersands, quotes (single and double) and greater-than\\/less-than signs using htmlspecialchars(str, ENT_QUOTES). It is recommended that you use this on all text\\/textarea fields except those using a rich text editor or a markup language like Markdown.\",\"core\":true,\"versionStr\":\"1.0.0\"},\"98\":{\"summary\":\"Generates markup for pagination navigation\",\"core\":true,\"versionStr\":\"1.0.5\"},\"113\":{\"summary\":\"Adds renderPager() method to all PaginatedArray types, for easy pagination output. Plus a render() method to PageArray instances.\",\"core\":true,\"versionStr\":\"1.0.0\"},\"156\":{\"summary\":\"Front-end to the HTML Purifier library.\",\"core\":true,\"versionStr\":\"4.9.7\"},\"67\":{\"summary\":\"Generates markup for data tables used by ProcessWire admin\",\"core\":true,\"versionStr\":\"1.0.8\"},\"280\":{\"summary\":\"Validates ZIP files with various configurable rules.\",\"author\":\"Ryan Cramer\",\"core\":true,\"versionStr\":\"0.0.1\"},\"125\":{\"summary\":\"Throttles login attempts to help prevent dictionary attacks.\",\"core\":true,\"versionStr\":\"1.0.3\"},\"103\":{\"summary\":\"Provides a jQuery plugin for sorting tables.\",\"href\":\"https:\\/\\/mottie.github.io\\/tablesorter\\/\",\"core\":true,\"versionStr\":\"2.31.3\"},\"151\":{\"summary\":\"Provides lightbox capability for image galleries. Replacement for FancyBox. Uses Magnific Popup by @dimsemenov.\",\"href\":\"https:\\/\\/github.com\\/dimsemenov\\/Magnific-Popup\\/\",\"core\":true,\"versionStr\":\"1.1.0\"},\"116\":{\"summary\":\"jQuery Core as required by ProcessWire Admin and plugins\",\"href\":\"https:\\/\\/jquery.com\",\"core\":true,\"versionStr\":\"1.12.4\"},\"45\":{\"summary\":\"Provides a jQuery plugin for generating tabs in ProcessWire.\",\"core\":true,\"versionStr\":\"1.1.0\"},\"117\":{\"summary\":\"jQuery UI as required by ProcessWire and plugins\",\"href\":\"https:\\/\\/ui.jquery.com\",\"core\":true,\"versionStr\":\"1.10.4\"},\"115\":{\"summary\":\"Adds a render method to Page and caches page output.\",\"core\":true,\"versionStr\":\"1.0.5\"},\"696\":{\"summary\":\"Field that stores single and multi select options.\",\"core\":true,\"versionStr\":\"0.0.2\"},\"1\":{\"summary\":\"Field that stores multiple lines of text\",\"core\":true,\"versionStr\":\"1.0.7\"},\"89\":{\"summary\":\"Field that stores a floating point number\",\"core\":true,\"versionStr\":\"1.0.8\"},\"135\":{\"summary\":\"Field that stores a URL\",\"core\":true,\"versionStr\":\"1.0.1\"},\"57\":{\"summary\":\"Field that stores one or more GIF, JPG, or PNG images\",\"core\":true,\"versionStr\":\"1.0.2\"},\"84\":{\"summary\":\"Field that stores an integer\",\"core\":true,\"versionStr\":\"1.0.2\"},\"107\":{\"summary\":\"Open a fieldset to group fields. Same as Fieldset (Open) except that it displays in a tab instead.\",\"core\":true,\"versionStr\":\"1.0.0\"},\"29\":{\"summary\":\"Field that stores an e-mail address\",\"core\":true,\"versionStr\":\"1.0.1\"},\"27\":{\"summary\":\"Field that stores a reference to another module\",\"core\":true,\"versionStr\":\"1.0.2\"},\"106\":{\"summary\":\"Close a fieldset opened by FieldsetOpen. \",\"core\":true,\"versionStr\":\"1.0.0\"},\"97\":{\"summary\":\"This Fieldtype stores an ON\\/OFF toggle via a single checkbox. The ON value is 1 and OFF value is 0.\",\"core\":true,\"versionStr\":\"1.0.1\"},\"111\":{\"summary\":\"Field that stores a page title\",\"core\":true,\"versionStr\":\"1.0.0\"},\"3\":{\"summary\":\"Field that stores a single line of text\",\"core\":true,\"versionStr\":\"1.0.2\"},\"105\":{\"summary\":\"Open a fieldset to group fields. Should be followed by a Fieldset (Close) after one or more fields.\",\"core\":true,\"versionStr\":\"1.0.1\"},\"28\":{\"summary\":\"Field that stores a date and optionally time\",\"core\":true,\"versionStr\":\"1.0.5\"},\"677\":{\"summary\":\"Maintains a collection of fields that are repeated for any number of times.\",\"core\":true,\"versionStr\":\"1.1.3\"},\"679\":{\"summary\":\"Fieldset with fields isolated to separate namespace (page), enabling re-use of fields.\",\"core\":true,\"versionStr\":\"0.0.1\"},\"678\":{\"summary\":\"Repeats fields from another template. Provides the input for FieldtypeRepeater.\",\"core\":true,\"versionStr\":\"1.1.1\"},\"4\":{\"summary\":\"Field that stores one or more references to ProcessWire pages\",\"core\":true,\"versionStr\":\"1.0.7\"},\"133\":{\"summary\":\"Field that stores a hashed and salted password\",\"core\":true,\"versionStr\":\"1.0.1\"},\"6\":{\"summary\":\"Field that stores one or more files\",\"core\":true,\"versionStr\":\"1.0.7\"},\"739\":{\"summary\":\"Inputfield for colors\",\"href\":\"https:\\/\\/processwire.com\\/talk\\/topic\\/16679-fieldtypecolor\\/\",\"versionStr\":\"1.1.6\"},\"738\":{\"summary\":\"Field that stores a color value as 32bit integer reflecting a RGBA value. Many options for Input (HTML5 Inputfield Color, Textfield with changing background, various jQuery\\/JS ColorPickers, custom jQuery\\/JS\\/CSS) and Output (RGB, RGBA, HSL, HSLA, HEX, Array).\",\"href\":\"https:\\/\\/processwire.com\\/talk\\/topic\\/16679-fieldtypecolor\\/\",\"versionStr\":\"1.1.8\"},\"750\":{\"summary\":\"Multiple Page selection using auto completion and sorting capability. Intended for use as an input field for Page reference fields.\",\"core\":true,\"versionStr\":\"1.1.3\"}}','2010-04-08 03:10:01'),
('ModulesVersions.info','[]','2010-04-08 03:10:01'),
('Permissions.names','{\"logs-edit\":1014,\"logs-view\":1013,\"page-delete\":34,\"page-edit\":32,\"page-edit-recent\":1011,\"page-lister\":1006,\"page-lock\":54,\"page-move\":35,\"page-sort\":50,\"page-template\":51,\"page-view\":36,\"profile-edit\":53,\"user-admin\":52}','2010-04-08 03:10:10');
/*!40000 ALTER TABLE `caches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_admin_theme`
--

DROP TABLE IF EXISTS `field_admin_theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_admin_theme` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_admin_theme`
--

LOCK TABLES `field_admin_theme` WRITE;
/*!40000 ALTER TABLE `field_admin_theme` DISABLE KEYS */;
INSERT INTO `field_admin_theme` VALUES
(41,197);
/*!40000 ALTER TABLE `field_admin_theme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_brand_color`
--

DROP TABLE IF EXISTS `field_brand_color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_brand_color` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(10) unsigned NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_brand_color`
--

LOCK TABLES `field_brand_color` WRITE;
/*!40000 ALTER TABLE `field_brand_color` DISABLE KEYS */;
INSERT INTO `field_brand_color` VALUES
(1051,1,0),
(1052,2,0);
/*!40000 ALTER TABLE `field_brand_color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_c_image`
--

DROP TABLE IF EXISTS `field_c_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_c_image` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(191) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `filedata` mediumtext DEFAULT NULL,
  `filesize` int(11) DEFAULT NULL,
  `created_users_id` int(10) unsigned NOT NULL DEFAULT 0,
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT 0,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `ratio` decimal(4,2) DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `filesize` (`filesize`),
  KEY `width` (`width`),
  KEY `height` (`height`),
  KEY `ratio` (`ratio`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `filedata` (`filedata`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_c_image`
--

LOCK TABLES `field_c_image` WRITE;
/*!40000 ALTER TABLE `field_c_image` DISABLE KEYS */;
INSERT INTO `field_c_image` VALUES
(1023,'ayush-kumar-hn8gya2yth8-unsplash.jpeg',0,'','2026-05-27 10:41:44','2026-05-27 10:41:44','{\"uploadName\":\"ayush-kumar-Hn8gYA2yTh8-unsplash.jpeg\"}',730148,41,41,2500,1406,1.78),
(1025,'ayush-kumar-hn8gya2yth8-unsplash.jpeg',0,'','2026-06-03 21:36:08','2026-06-03 21:36:08','{\"uploadName\":\"ayush-kumar-Hn8gYA2yTh8-unsplash.jpeg\"}',730148,41,41,2500,1406,1.78),
(1027,'john-kinnander-fxx0srwehz8-unsplash.jpg',0,'','2026-05-04 12:13:29','2026-05-04 12:13:29','{\"uploadName\":\"john-kinnander-fXX0SRwEhz8-unsplash.jpg\"}',1181245,41,41,5184,3456,1.50),
(1029,'ayush-kumar-hn8gya2yth8-unsplash.jpeg',0,'','2026-06-11 10:31:05','2026-06-11 10:31:05','{\"uploadName\":\"ayush-kumar-Hn8gYA2yTh8-unsplash.jpeg\"}',730148,41,41,2500,1406,1.78),
(1030,'aryo-yarahmadi-xdbtmtqjmh4-unsplash.jpg',0,'','2026-05-04 12:13:29','2026-05-04 12:13:29','{\"uploadName\":\"aryo-yarahmadi-XDbTmTQjmH4-unsplash.jpg\"}',563338,41,41,4705,3137,1.50),
(1035,'brunno-tozzo-10itqxfpvak-unsplash.jpg',0,'','2026-05-27 10:55:53','2026-05-27 10:55:53','{\"uploadName\":\"brunno-tozzo-10ITQxFpVak-unsplash.jpg\"}',522670,41,41,2400,1600,1.50),
(1041,'ayush-kumar-hn8gya2yth8-unsplash-1.jpeg',0,'','2026-06-03 21:51:03','2026-06-03 21:51:03','{\"uploadName\":\"ayush-kumar-Hn8gYA2yTh8-unsplash.jpeg\"}',730148,41,41,2500,1406,1.78),
(1042,'tom-morel-ktvazl5c7fm-unsplash-1.jpg',0,'','2026-06-05 09:44:40','2026-06-05 09:44:40','{\"uploadName\":\"tom-morel-ktVazL5c7FM-unsplash.jpg\"}',247456,41,41,2400,1800,1.33),
(1043,'ayush-kumar-hn8gya2yth8-unsplash.jpeg',0,'','2026-06-03 23:52:27','2026-06-03 23:52:27','{\"uploadName\":\"ayush-kumar-Hn8gYA2yTh8-unsplash.jpeg\"}',730148,41,41,2500,1406,1.78),
(1044,'tom-morel-ktvazl5c7fm-unsplash.jpg',0,'','2026-06-04 00:00:09','2026-06-04 00:00:09','{\"uploadName\":\"tom-morel-ktVazL5c7FM-unsplash.jpg\"}',247456,41,41,2400,1800,1.33),
(1046,'ayush-kumar-hn8gya2yth8-unsplash.jpeg',0,'','2026-06-04 00:13:43','2026-06-04 00:13:43','{\"uploadName\":\"ayush-kumar-Hn8gYA2yTh8-unsplash.jpeg\"}',730148,41,41,2500,1406,1.78),
(1047,'sigmund-u_rh6c28g0k-unsplash-1.jpg',0,'','2026-06-05 09:36:45','2026-06-05 09:36:45','{\"uploadName\":\"sigmund-u_RH6c28G0k-unsplash.jpg\"}',160700,41,41,2400,1600,1.50),
(1048,'cdc-ifpqtennlj8-unsplash.jpg',0,'','2026-06-05 09:38:27','2026-06-05 09:38:27','{\"uploadName\":\"cdc-IFpQtennlj8-unsplash.jpg\"}',299303,41,41,2400,1600,1.50),
(1055,'brunno-tozzo-10itqxfpvak-unsplash.jpg',0,'','2026-06-07 23:35:28','2026-06-07 23:35:28','{\"uploadName\":\"brunno-tozzo-10ITQxFpVak-unsplash.jpg\"}',522670,41,41,2400,1600,1.50),
(1057,'cdc-ifpqtennlj8-unsplash.jpg',0,'','2026-06-07 23:35:28','2026-06-07 23:35:28','{\"uploadName\":\"cdc-IFpQtennlj8-unsplash.jpg\"}',299303,41,41,2400,1600,1.50),
(1061,'sigmund-u_rh6c28g0k-unsplash.jpg',0,'','2026-06-08 10:15:29','2026-06-08 10:15:29','{\"uploadName\":\"sigmund-u_RH6c28G0k-unsplash.jpg\"}',160700,41,41,2400,1600,1.50),
(1066,'sigmund-u_rh6c28g0k-unsplash.jpg',0,'','2026-06-08 12:20:58','2026-06-08 12:20:58','{\"uploadName\":\"sigmund-u_RH6c28G0k-unsplash.jpg\"}',160700,41,41,2400,1600,1.50),
(1067,'matthias_imboden_06_2026.jpg',0,'','2026-06-10 11:19:49','2026-06-10 11:19:49','{\"uploadName\":\"Matthias Imboden 06.2026.jpg\"}',182363,41,41,800,1034,0.77),
(1068,'tom-morel-ktvazl5c7fm-unsplash.jpg',0,'','2026-06-08 12:14:44','2026-06-08 12:14:44','{\"uploadName\":\"tom-morel-ktVazL5c7FM-unsplash.jpg\"}',247456,41,41,2400,1800,1.33),
(1069,'aha.jpg',0,'','2026-06-10 11:19:49','2026-06-10 11:19:49','{\"uploadName\":\"AHA.JPG\"}',390932,41,41,1000,1518,0.66),
(1070,'pw_website_photo.jpg',0,'','2026-06-10 11:20:27','2026-06-10 11:20:27','{\"uploadName\":\"PW Website Photo.jpg\"}',247528,41,41,1000,1333,0.75),
(1071,'silvia_holler-_rtda_dipartimento_di_biologia_cellulare-_computazionale_e_integrata_-_cibio_1.jpg',0,'','2026-06-10 11:16:06','2026-06-10 11:16:06','{\"uploadName\":\"Silvia Holler,  RTDa Dipartimento di Biologia Cellulare, Computazionale e Integrata - CIBIO (1).JPG\"}',825555,41,41,4203,6062,0.69),
(1072,'martin_photo_2023.jpg',0,'','2026-06-10 11:17:07','2026-06-10 11:17:07','{\"uploadName\":\"Martin photo 2023.jpg\"}',473494,41,41,1200,1800,0.67);
/*!40000 ALTER TABLE `field_c_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_c_subtitle`
--

DROP TABLE IF EXISTS `field_c_subtitle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_c_subtitle` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(191)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_c_subtitle`
--

LOCK TABLES `field_c_subtitle` WRITE;
/*!40000 ALTER TABLE `field_c_subtitle` DISABLE KEYS */;
INSERT INTO `field_c_subtitle` VALUES
(1023,'Beyond visible light, sensing what matters'),
(1025,'BrightIR'),
(1029,'Error 404'),
(1035,'What we\'re doing, what we want to achieve'),
(1037,'A new class of miniaturized infrared light sources.'),
(1038,'From emitter to functional sensing platform.'),
(1039,'Adapting the sensing platform to different needs.'),
(1042,'News One Subtitle'),
(1043,'Our Latest News'),
(1044,'BrightIR at BiotechSF2026'),
(1046,'Get in touch'),
(1047,'This is an event news'),
(1048,'This is a paper pub new'),
(1055,'Hero Subtitle'),
(1057,'ImageTextPreTitle'),
(1061,'Who we are');
/*!40000 ALTER TABLE `field_c_subtitle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_c_text`
--

DROP TABLE IF EXISTS `field_c_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_c_text` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(191)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_c_text`
--

LOCK TABLES `field_c_text` WRITE;
/*!40000 ALTER TABLE `field_c_text` DISABLE KEYS */;
INSERT INTO `field_c_text` VALUES
(1018,'<p>This project has received funding from the European Union&rsquo;s Horizon Europe EIC 2025 Transition Open programme under grant agreement No 101290530. Views and opinions expressed are however those of the author(s) only and do not necessarily reflect those of the European Union or the European Innovation Council and SMEs Executive Agency (EISMEA). Neither the European Union nor the granting authority can be held responsible for them.</p>'),
(1025,'<p>Infrared light encodes chemical information invisible to the naked eye. The concentration of CO<sub>2</sub> in the air we breathe, the composition of biological fluids, the presence of trace compounds in the environment: all of these leave a distinct fingerprint in the infrared spectrum.</p>\n<p>Reading that fingerprint today requires instruments that are large, costly, and generally confined to specialized lab settings. Infrared light sources in particular have lagged behind in miniaturization and cost reduction, limiting the scalability and accessibility of the technology.</p>\n<p>BRIGHTIR directly addresses this gap. We are developing ultra-compact infrared emitters, with improved efficiency, and a scalable manufacturing path enabling high volume low cost production. The goal is to create portable, scalable, and low cost sensors making infrared-based chemical sensing ubiquitous, thereby opening the door to new possibilities in wellness monitoring and environmental sensing.</p>'),
(1030,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
(1037,'<p>The emitter is the core of the BRIGHTIR technology. 4K-MEMS develops a thermal infrared emitter chip designed to be compact, efficient, and implemented with high volume manufacturing processes.</p>\n<p>Current infrared light sources present significant limitations in size and cost that have restricted their use to specialized laboratory or high-end industrial settings. Our work aims to overcome these constraints and produce a component that can realistically be integrated into portable, low</p>'),
(1038,'<p>Beyond the light source itself, BRIGHTIR works on integrating the emitter into complete sensing systems. We are building and testing sensor prototypes that demonstrate the technology in relevant use cases: going from cell culture to phantom skin test.</p>\n<p>This step is essential to validate performance in real conditions and understand the practical requirements of different application domains.</p>'),
(1039,'<p>A single emitter technology can support multiple sensing configurations depending on the target application. BRIGHTIR explores variants of the core sensor design to address distinct use cases across environmental monitoring and health-related measurements. This work helps define which adaptations are technically feasible and where the clearest opportunities for deployment exist.</p>\n<p>As a first concrete test, the sensor will be validated for lactate monitoring in sports performance applications. This trial will be conducted by the University of Trento (UNITN), providing an initial real-world benchmark for the technology.</p>'),
(1057,'<p>ImageText ContentImageText ContentImageText ContentImageText ContentImageText ContentImageText ContentImageText Content</p>'),
(1067,'<p>Matthias Imboden is a physicist and entrepreneur focused on bringing advanced microtechnology into practical applications. He is the Founder and CEO of 4K-MEMS SA, where he leads the development of broadband infrared light engines for embedded spectroscopy and sensing applications.</p>\n<p>Since founding 4K-MEMS in 2020, Matthias has guided the company from core emitter technology toward integrated solutions for compact, cost-effective infrared sensing. His work combines technical expertise with a product-oriented perspective, with the aim of enabling IR spectroscopy to be integrated into consumer, industrial, and medical devices.</p>\n<p>Before launching 4K-MEMS, Matthias worked as a Project Manager at Swatch Group SA, where he contributed to the development of new technologies for wearables, including actuators, sensors, and energy management systems. This experience gave him insight into the challenges of translating advanced hardware concepts into product-relevant technologies.</p>\n<p>Matthias holds a Ph.D. in Physics from Boston University and has worked across microfabrication, MEMS, optics, sensing, and advanced materials. His earlier research included nanoelectromechanical systems, optical beam steering, thermal MEMS, dynamic micro-electrode arrays, and novel fabrication methods.</p>\n<p><strong>Across his career, Matthias has combined scientific depth with practical technology development. He has published extensively in peer-reviewed journals and is named on more than 30 patents, reflecting a strong track record in research, applied innovation, and intellectual property creation. </strong></p>'),
(1069,'<p>Alexandre H&auml;mmerli is a MEMS expert and the Lead of Industrialisation and Quality at 4k-mems (since 2024), where his primary focus is scaling the company\'s innovative technology to robust industrial production levels. After his studies in micro and nanotechnologies at the University of Neuch&acirc;tel, he joined Beth Pruitt\'s laboratory at Stanford University and developed self-sensing piezoresistive cantilevers for scanning probe microscopy (SPM) instruments used in 2D materials research.</p>\n<p>Transitioning from academia to high-volume manufacturing, Alexandre built a strong industrial foundation within the Swatch Group. He began in the Swatch Group Research and Development division (ASULAB), engineering new oscillators, optimizing existing designs, and developing new micro-actuator systems for watches. He then advanced to Nivarox-FAR SA, a Swatch Group industrial manufacturing subsidiary, where he specialized in process management, quality control, and the continuous improvement of micro-manufactured watch components.</p>'),
(1070,'<p>Paul Wilkinson - Paul Wilkinson is an innovator, strategist, and technologist with a Ph.D. in physical chemistry and a passion for entrepreneurial endeavors. He is the VP of Infrared Technology at 4K-MEMS, where he leads the translation of 4K-MEMS innovative optical sources to optical systems for embedded spectroscopy and sensing applications.</p>\n<p>Before joining 4K-MEMS in 2026, Paul was the VP of Technology at Matrix Sensors, Inc., where he lead the development of that organization’s core sensing technology and architected the organization’s custom test infrastructure. He has additional experience in optical metrology both at Physical Optics Corporation and as a NRC Postdoctoral Fellow at NIST.</p>\n<p>Paul holds a Ph.D. in Physical Chemistry from the University of California, Los Angeles (UCLA), and has experience in optical metrology, dynamic MEMS, sensing, materials development, instrumentation development, high-throughput testing, and industrial adsorption processes.</p>\n<p>Paul has published extensively in peer-reviewed journals, and is inventor or co-inventor on 10 patents in optical metrology, sensing, and biomedical devices. He is passionate about achieving impact on the world through innovation and execution.</p>'),
(1071,'<p>Silvia Holler is a PI in the Department of Cellular, Computational and Integrative Biology at the University of Trento. Shereceived her PhD in 2018 and has since built her research career at the intersection of analytical chemistry, biochemistry, and biomedical sensing. She leads the Laboratory of Miniaturized Sensing and Biochemical Monitoring at the University of Trento, where her group focuses on the validation and application of compact sensing technologies for the detection of clinically and biologically relevant molecules &mdash; working in close collaboration with engineering, photonics, and clinical partners to ensure that emerging platforms are assessed against real-world performance criteria.</p>\n<p>Throughout her career, she has been consistently involved in ambitious European research initiatives. She currently serves as Scientific Coordinator of OMICSENS, an EIC Pathfinder project developing miniaturized nano-photonic platforms for lung cancer biomarker detection, and the project from which BRIGHTIR directly originates.</p>'),
(1072,'<p>Martin Hanczyc is an Associate Professor in the Department of Cellular, Computational and Integrative Biology at the University of Trento, Italy and a Research Professor of Chemical and Biological Engineering at the University of New Mexico, Albuquerque USA. He formally was an Honorary Senior Lecturer at the Bartlett School of Architecture, University College London, Chief Chemist at ProtoLife and Associate Professor at the University of Southern Denmark. He received a bachelor&rsquo;s degree in Biology from Pennsylvania State University, a doctorate in Genetics from Yale University and was a postdoctorate fellow under Jack Szostak at Harvard University. He has published in the area of droplets, complex systems, evolution and the origin of life. Currently he heads the Laboratory for Artificial Biology, developing novel synthetic chemical systems based on the properties of living systems. He recently coordinated an EU project on artificial cells (ACDC) and an ERAMSUS project on Art and Science education (ABRAx). Martin is now coordinating the OMICSENS and the Bio-HhOST EIC Pathfinder projects.</p>');
/*!40000 ALTER TABLE `field_c_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_c_title`
--

DROP TABLE IF EXISTS `field_c_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_c_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(191)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_c_title`
--

LOCK TABLES `field_c_title` WRITE;
/*!40000 ALTER TABLE `field_c_title` DISABLE KEYS */;
INSERT INTO `field_c_title` VALUES
(1023,'BRIGHTIR'),
(1025,'About the project'),
(1027,'The Project'),
(1029,'Page Not Found'),
(1030,'Image Text Section'),
(1035,'Project'),
(1037,'01'),
(1038,'02'),
(1039,'03'),
(1043,'Highlights'),
(1046,'Contact Us'),
(1051,'General Enquiries'),
(1052,'Investors & Partners'),
(1055,'Hero Title'),
(1057,'ImageTextTitle'),
(1061,'Partners'),
(1067,'Matthias Imboden'),
(1069,'Alexandre Haemmerli'),
(1070,'Paul Wilkinson'),
(1071,'Silvia Holler'),
(1072,'Martin Hanczyc'),
(1076,'Smarter'),
(1077,'wearable sensor'),
(1078,'for everyday fitness monitoring');
/*!40000 ALTER TABLE `field_c_title` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_color`
--

DROP TABLE IF EXISTS `field_color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_color` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_color`
--

LOCK TABLES `field_color` WRITE;
/*!40000 ALTER TABLE `field_color` DISABLE KEYS */;
/*!40000 ALTER TABLE `field_color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_contact_cards`
--

DROP TABLE IF EXISTS `field_contact_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_contact_cards` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `count` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(1)),
  KEY `count` (`count`,`pages_id`),
  KEY `parent_id` (`parent_id`,`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_contact_cards`
--

LOCK TABLES `field_contact_cards` WRITE;
/*!40000 ALTER TABLE `field_contact_cards` DISABLE KEYS */;
INSERT INTO `field_contact_cards` VALUES
(1045,'1051,1052',2,1050);
/*!40000 ALTER TABLE `field_contact_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_contacts_email`
--

DROP TABLE IF EXISTS `field_contacts_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_contacts_email` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(191) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_contacts_email`
--

LOCK TABLES `field_contacts_email` WRITE;
/*!40000 ALTER TABLE `field_contacts_email` DISABLE KEYS */;
INSERT INTO `field_contacts_email` VALUES
(1018,'info.brightir@gmail.com');
/*!40000 ALTER TABLE `field_contacts_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_content`
--

DROP TABLE IF EXISTS `field_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_content` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(191)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_content`
--

LOCK TABLES `field_content` WRITE;
/*!40000 ALTER TABLE `field_content` DISABLE KEYS */;
INSERT INTO `field_content` VALUES
(27,'<p>Sorry, we couldn\'t find the page you were looking for. It might have been moved or deleted.</p>\n<p><a	href=\"/\">Go to Homepage</a></p>'),
(1026,'<p>Content field here</p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
(1034,'<p>Infrared light encodes chemical information invisible to the naked eye. The concentration of CO<sub>2</sub> in the air we breathe, the composition of biological fluids, the presence of trace compounds in the environment: all of these leave a distinct fingerprint in the infrared spectrum.</p>\n<p>Reading that fingerprint today requires instruments that are large, costly, and generally confined to specialized lab settings. Infrared light sources in particular have lagged behind in miniaturization and cost reduction, limiting the scalability and accessibility of the technology.</p>\n<p>BRIGHTIR directly addresses this gap. We are developing ultra-compact infrared emitters, with improved efficiency, and a scalable manufacturing path enabling high volume low cost production. The goal is to create portable, scalable, and low cost sensors making infrared-based chemical sensing ubiquitous, thereby opening the door to new possibilities in wellness monitoring and environmental sensing.</p>'),
(1037,'<p>The emitter is the core of the BRIGHTIR technology. 4K-MEMS develops a thermal infrared emitter chip designed to be compact, efficient, and implemented with high volume manufacturing processes.</p>'),
(1038,'<p>Beyond the light source itself, BRIGHTIR works on integrating the emitter into complete sensing systems.</p>'),
(1039,'<p>A single emitter technology can support multiple sensing configurations depending on the target application. BRIGHTIR explores variants of the core sensor design to address distinct use cases across environmental monitoring and health-related measurements.</p>'),
(1040,'<p>Follow the progress of BRIGHTIR here. From research milestones and conferences to patents and news, this is where we share the developments that matter most to our community and to everyone interested in the project.</p>'),
(1041,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
(1042,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea <strong>commodo consequat</strong>. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. <a href=\"https://www.google.com/\">Link to Google</a> sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>'),
(1044,'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
(1045,'<p>Interested in our technology or in collaborating with us? Feel free to get in touch.</p>'),
(1047,'<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<p>&nbsp;</p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
(1048,'<p>Lorem ipsum dolor sit amet consectetur adipiscing elit. Consectetur adipiscing elit quisque faucibus ex sapien vitae. Ex sapien vitae pellentesque sem placerat in id. Placerat in id cursus mi pretium tellus duis. Pretium tellus duis convallis tempus leo eu aenean. Lorem ipsum dolor sit amet consectetur adipiscing elit. Consectetur adipiscing elit quisque faucibus ex sapien vitae. Ex sapien vitae pellentesque sem placerat in id. Placerat in id cursus mi pretium tellus duis. Pretium tellus duis convallis tempus leo eu aenean.</p>\n<p>Lorem ipsum dolor sit amet consectetur adipiscing elit. Consectetur adipiscing elit quisque faucibus ex sapien vitae. Ex sapien vitae pellentesque sem placerat in id. Placerat in id cursus mi pretium tellus duis. Pretium tellus duis convallis tempus leo eu aenean.</p>\n<p>Lorem ipsum dolor sit amet consectetur adipiscing elit. Consectetur adipiscing elit quisque faucibus ex sapien vitae. Ex sapien vitae pellentesque sem placerat in id. Placerat in id cursus mi pretium tellus duis. Pretium tellus duis convallis tempus leo eu aenean.</p>\n<p>Lorem ipsum dolor sit amet consectetur adipiscing elit. Consectetur adipiscing elit quisque faucibus ex sapien vitae. Ex sapien vitae pellentesque sem placerat in id. Placerat in id cursus mi pretium tellus duis. Pretium tellus duis convallis tempus leo eu aenean. Lorem ipsum dolor sit amet consectetur adipiscing elit. Consectetur adipiscing elit quisque faucibus ex sapien vitae. Ex sapien vitae pellentesque sem placerat in id. Placerat in id cursus mi pretium tellus duis. Pretium tellus duis convallis tempus leo eu aenean. Lorem ipsum dolor sit amet consectetur adipiscing elit. Consectetur adipiscing elit quisque faucibus ex sapien vitae. Ex sapien vitae pellentesque sem placerat in id. Placerat in id cursus mi pretium tellus duis. Pretium tellus duis convallis tempus leo eu aenean.</p>'),
(1051,'<p>For questions about the BRIGHTIR project, its research outcomes, collaboration opportunities, or press and media requests, our communications team is happy to help.</p>'),
(1052,'<p>Interested in co-funding, licensing, or strategic partnership opportunities within the BRIGHTIR ecosystem? Our business development team will be in touch promptly.</p>'),
(1054,'<p>Hero Content Hero <strong>Content</strong> Hero Content Hero Content Hero Content Hero Content Hero Content </p>\n<p>Hero Content Hero Content <em>Hero Content</em> Hero Content Hero Content Hero Content Hero Content </p>\n<p>Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content <a	href=\"/contact-us/\">This is a link to Contact Page</a> Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content </p>\n<p>Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content Hero Content </p>\n<ul>\n<li>item one</li>\n<li>item two</li>\n<li>item three</li>\n</ul>\n<ol>\n<li>item</li>\n<li>item2</li>\n<li>item3</li>\n</ol>'),
(1058,'<p>BRIGHTIR brings together two complementary partners: 4K-MEMS, developing the miniaturized broadband infrared emitter and sensor, that form the core of the project, and the University of Trento, working on sensor validation for real-world chemical sensing.</p>'),
(1062,'<p>The University of Trento is a research-intensive institution consistently ranked among the most dynamic universities in Italy, with a strong track record of collaboration with industry, startups, and innovation ecosystems. Its infrastructure supports advanced experimental work across multiple disciplines, making it a natural environment for bridging laboratory research and applied technology development.</p>\n<p>Within BRIGHTIR, UNITN will serve as the primary site for sensor validation, leveraging its facilities and expertise to test the technology in relevant real-world conditions.</p>\n<p>The experimental work will be led by the Laboratory of Miniaturized Sensing and Biochemical Monitoring, headed by Prof. Silvia Holler, whose research focuses on compact sensing systems and non-invasive biochemical analysis, a profile that aligns directly with the goals of BRIGHTIR\'s sensor testing phase. This work will be supported by the collaboration with the Laboratory of Artificial Biology, led by Prof. Martin Hanczyc</p>'),
(1064,'<p>4K-MEMS SA, founded in 2020, is at the forefront of developing state-of-the-art broadband near infrared (NIR) light sources for embedded sensing applications. As a fabless entity, our core competencies lie in the innovative design and rigorous testing of our products, while manufacturing is expertly handled by our partners. Our cutting-edge SWIR emitters are crafted based on a patented architecture that employs novel materials and advanced microfabrication techniques, setting new standards for size, brightness, and response time.</p>\n<p>Our technology promises to revolutionize the field by offering scalable manufacturing methods that not only facilitate deep integration with modern micro-technologies but also significantly reduce the cost per unit. This breakthrough enables the widespread incorporation of chemical sensing technology into consumer products, ranging from personalized wellness devices to smart appliances, enhancing both performance and safety.</p>\n<p>At 4K-MEMS, we are driven by the vision of making infrared-based sensing ubiquitous, providing industries and consumers alike with the ability to obtain accurate, firsthand information about the materials they use daily. Our compact, cost-effective emitters are designed to be universally applicable, paving the way for a future where high-quality broadband infrared sensing is a standard feature in a wide array of products.</p>');
/*!40000 ALTER TABLE `field_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_copyright`
--

DROP TABLE IF EXISTS `field_copyright`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_copyright` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(191)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_copyright`
--

LOCK TABLES `field_copyright` WRITE;
/*!40000 ALTER TABLE `field_copyright` DISABLE KEYS */;
INSERT INTO `field_copyright` VALUES
(1018,'<p>Copyright 2026 © BRIGHTIR</p>');
/*!40000 ALTER TABLE `field_copyright` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_date`
--

DROP TABLE IF EXISTS `field_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_date` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` datetime NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_date`
--

LOCK TABLES `field_date` WRITE;
/*!40000 ALTER TABLE `field_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `field_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_email`
--

DROP TABLE IF EXISTS `field_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_email` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(191) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_email`
--

LOCK TABLES `field_email` WRITE;
/*!40000 ALTER TABLE `field_email` DISABLE KEYS */;
INSERT INTO `field_email` VALUES
(1051,'info.brightir@gmail.com'),
(1052,'info@4kmems.ch'),
(41,'syneus@gmail.com');
/*!40000 ALTER TABLE `field_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_featured`
--

DROP TABLE IF EXISTS `field_featured`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_featured` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` tinyint(4) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_featured`
--

LOCK TABLES `field_featured` WRITE;
/*!40000 ALTER TABLE `field_featured` DISABLE KEYS */;
INSERT INTO `field_featured` VALUES
(1042,1),
(1047,1);
/*!40000 ALTER TABLE `field_featured` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_goals_pretitle`
--

DROP TABLE IF EXISTS `field_goals_pretitle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_goals_pretitle` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(191)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_goals_pretitle`
--

LOCK TABLES `field_goals_pretitle` WRITE;
/*!40000 ALTER TABLE `field_goals_pretitle` DISABLE KEYS */;
INSERT INTO `field_goals_pretitle` VALUES
(1,'Project Goals'),
(1034,'Project Goals');
/*!40000 ALTER TABLE `field_goals_pretitle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_goals_title`
--

DROP TABLE IF EXISTS `field_goals_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_goals_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(191)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_goals_title`
--

LOCK TABLES `field_goals_title` WRITE;
/*!40000 ALTER TABLE `field_goals_title` DISABLE KEYS */;
INSERT INTO `field_goals_title` VALUES
(1,'Developing new capabilities'),
(1034,'Developing new capabilities');
/*!40000 ALTER TABLE `field_goals_title` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_hero_fieldset`
--

DROP TABLE IF EXISTS `field_hero_fieldset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_hero_fieldset` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_hero_fieldset`
--

LOCK TABLES `field_hero_fieldset` WRITE;
/*!40000 ALTER TABLE `field_hero_fieldset` DISABLE KEYS */;
INSERT INTO `field_hero_fieldset` VALUES
(1,1023),
(1026,1027),
(27,1029),
(1034,1035),
(1040,1043),
(1045,1046),
(1054,1055),
(1058,1061),
(1062,1066),
(1064,1068);
/*!40000 ALTER TABLE `field_hero_fieldset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_hero_size`
--

DROP TABLE IF EXISTS `field_hero_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_hero_size` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(10) unsigned NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_hero_size`
--

LOCK TABLES `field_hero_size` WRITE;
/*!40000 ALTER TABLE `field_hero_size` DISABLE KEYS */;
INSERT INTO `field_hero_size` VALUES
(1029,1,0),
(1035,1,0),
(1043,1,0),
(1046,1,0),
(1061,1,0),
(1066,1,0),
(1068,1,0),
(1023,2,0);
/*!40000 ALTER TABLE `field_hero_size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_highlights_pretitle`
--

DROP TABLE IF EXISTS `field_highlights_pretitle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_highlights_pretitle` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(191)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_highlights_pretitle`
--

LOCK TABLES `field_highlights_pretitle` WRITE;
/*!40000 ALTER TABLE `field_highlights_pretitle` DISABLE KEYS */;
INSERT INTO `field_highlights_pretitle` VALUES
(1,'Latest News');
/*!40000 ALTER TABLE `field_highlights_pretitle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_highlights_title`
--

DROP TABLE IF EXISTS `field_highlights_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_highlights_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(191)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_highlights_title`
--

LOCK TABLES `field_highlights_title` WRITE;
/*!40000 ALTER TABLE `field_highlights_title` DISABLE KEYS */;
INSERT INTO `field_highlights_title` VALUES
(1,'Recent highlights');
/*!40000 ALTER TABLE `field_highlights_title` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_image_gallery`
--

DROP TABLE IF EXISTS `field_image_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_image_gallery` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(191) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `filedata` mediumtext DEFAULT NULL,
  `filesize` int(11) DEFAULT NULL,
  `created_users_id` int(10) unsigned NOT NULL DEFAULT 0,
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT 0,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `ratio` decimal(4,2) DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `filesize` (`filesize`),
  KEY `width` (`width`),
  KEY `height` (`height`),
  KEY `ratio` (`ratio`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `filedata` (`filedata`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_image_gallery`
--

LOCK TABLES `field_image_gallery` WRITE;
/*!40000 ALTER TABLE `field_image_gallery` DISABLE KEYS */;
INSERT INTO `field_image_gallery` VALUES
(1042,'brunno-tozzo-10itqxfpvak-unsplash.jpg',0,'','2026-06-03 21:58:11','2026-06-03 21:58:11','{\"uploadName\":\"brunno-tozzo-10ITQxFpVak-unsplash.jpg\"}',338327,41,41,1600,1066,1.50),
(1042,'milad-fakurian-em2ns9yy4du-unsplash.jpg',1,'','2026-06-03 21:58:11','2026-06-03 21:58:11','{\"uploadName\":\"milad-fakurian-Em2nS9yY4dU-unsplash.jpg\"}',145017,41,41,1600,1066,1.50),
(1042,'tom-morel-ktvazl5c7fm-unsplash.jpg',2,'','2026-06-03 21:58:11','2026-06-03 21:58:11','{\"uploadName\":\"tom-morel-ktVazL5c7FM-unsplash.jpg\"}',141118,41,41,1600,1200,1.33),
(1042,'sigmund-u_rh6c28g0k-unsplash.jpg',3,'','2026-06-03 21:58:11','2026-06-03 21:58:11','{\"uploadName\":\"sigmund-u_RH6c28G0k-unsplash.jpg\"}',92031,41,41,1600,1066,1.50),
(1044,'national-cancer-institute-zz_3tccrk7o-unsplash.jpg',0,'','2026-06-04 00:00:09','2026-06-04 00:00:09','{\"uploadName\":\"national-cancer-institute-zz_3tCcrk7o-unsplash.jpg\"}',364473,41,41,1600,1138,1.41),
(1044,'sigmund-u_rh6c28g0k-unsplash.jpg',1,'','2026-06-04 00:00:09','2026-06-04 00:00:09','{\"uploadName\":\"sigmund-u_RH6c28G0k-unsplash.jpg\"}',92031,41,41,1600,1066,1.50),
(1044,'cdc-ifpqtennlj8-unsplash.jpg',2,'','2026-06-04 00:00:09','2026-06-04 00:00:09','{\"uploadName\":\"cdc-IFpQtennlj8-unsplash.jpg\"}',167000,41,41,1600,1066,1.50),
(1047,'brunno-tozzo-10itqxfpvak-unsplash.jpg',0,'','2026-06-05 09:36:28','2026-06-05 09:36:28','{\"uploadName\":\"brunno-tozzo-10ITQxFpVak-unsplash.jpg\"}',338327,41,41,1600,1066,1.50),
(1047,'milad-fakurian-em2ns9yy4du-unsplash.jpg',1,'','2026-06-05 09:36:28','2026-06-05 09:36:28','{\"uploadName\":\"milad-fakurian-Em2nS9yY4dU-unsplash.jpg\"}',145017,41,41,1600,1066,1.50),
(1047,'tom-morel-ktvazl5c7fm-unsplash.jpg',2,'','2026-06-05 09:36:28','2026-06-05 09:36:28','{\"uploadName\":\"tom-morel-ktVazL5c7FM-unsplash.jpg\"}',141118,41,41,1600,1200,1.33),
(1047,'sigmund-u_rh6c28g0k-unsplash.jpg',3,'','2026-06-05 09:36:28','2026-06-05 09:36:28','{\"uploadName\":\"sigmund-u_RH6c28G0k-unsplash.jpg\"}',92031,41,41,1600,1066,1.50),
(1048,'tom-morel-ktvazl5c7fm-unsplash.jpg',0,'','2026-06-05 09:38:27','2026-06-05 09:38:27','{\"uploadName\":\"tom-morel-ktVazL5c7FM-unsplash.jpg\"}',141118,41,41,1600,1200,1.33),
(1048,'sigmund-u_rh6c28g0k-unsplash.jpg',1,'','2026-06-05 09:38:27','2026-06-05 09:38:27','{\"uploadName\":\"sigmund-u_RH6c28G0k-unsplash.jpg\"}',92031,41,41,1600,1066,1.50),
(1048,'cdc-ifpqtennlj8-unsplash-1.jpg',2,'','2026-06-05 09:38:27','2026-06-05 09:38:27','{\"uploadName\":\"cdc-IFpQtennlj8-unsplash.jpg\"}',167000,41,41,1600,1066,1.50),
(1048,'national-cancer-institute-zz_3tccrk7o-unsplash.jpg',3,'','2026-06-05 09:38:27','2026-06-05 09:38:27','{\"uploadName\":\"national-cancer-institute-zz_3tCcrk7o-unsplash.jpg\"}',364473,41,41,1600,1138,1.41);
/*!40000 ALTER TABLE `field_image_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_image_position`
--

DROP TABLE IF EXISTS `field_image_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_image_position` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(10) unsigned NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_image_position`
--

LOCK TABLES `field_image_position` WRITE;
/*!40000 ALTER TABLE `field_image_position` DISABLE KEYS */;
INSERT INTO `field_image_position` VALUES
(1069,1,0),
(1072,1,0),
(1025,2,0),
(1057,2,0),
(1067,2,0),
(1070,2,0),
(1071,2,0);
/*!40000 ALTER TABLE `field_image_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_imagetext`
--

DROP TABLE IF EXISTS `field_imagetext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_imagetext` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `count` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(1)),
  KEY `count` (`count`,`pages_id`),
  KEY `parent_id` (`parent_id`,`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_imagetext`
--

LOCK TABLES `field_imagetext` WRITE;
/*!40000 ALTER TABLE `field_imagetext` DISABLE KEYS */;
INSERT INTO `field_imagetext` VALUES
(1,'1025',1,1024),
(1026,'1030',1,1028),
(1054,'1057',1,1056),
(1062,'1071,1072',2,1063),
(1064,'1067,1069,1070',3,1065);
/*!40000 ALTER TABLE `field_imagetext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_link_blank`
--

DROP TABLE IF EXISTS `field_link_blank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_link_blank` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` tinyint(4) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_link_blank`
--

LOCK TABLES `field_link_blank` WRITE;
/*!40000 ALTER TABLE `field_link_blank` DISABLE KEYS */;
/*!40000 ALTER TABLE `field_link_blank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_link_url`
--

DROP TABLE IF EXISTS `field_link_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_link_url` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(191)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_link_url`
--

LOCK TABLES `field_link_url` WRITE;
/*!40000 ALTER TABLE `field_link_url` DISABLE KEYS */;
INSERT INTO `field_link_url` VALUES
(1020,'/'),
(1021,'/project'),
(1022,'/contact-us'),
(1031,'/results'),
(1032,'/highlights'),
(1059,'/partners');
/*!40000 ALTER TABLE `field_link_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_logo`
--

DROP TABLE IF EXISTS `field_logo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_logo` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(191) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `filedata` mediumtext DEFAULT NULL,
  `filesize` int(11) DEFAULT NULL,
  `created_users_id` int(10) unsigned NOT NULL DEFAULT 0,
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT 0,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `ratio` decimal(4,2) DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `filesize` (`filesize`),
  KEY `width` (`width`),
  KEY `height` (`height`),
  KEY `ratio` (`ratio`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `filedata` (`filedata`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_logo`
--

LOCK TABLES `field_logo` WRITE;
/*!40000 ALTER TABLE `field_logo` DISABLE KEYS */;
INSERT INTO `field_logo` VALUES
(1018,'logo_brightir_def.png',0,'','2026-05-04 10:28:08','2026-05-04 10:28:08','',268906,41,41,2434,805,3.02),
(1062,'unitrento-logo.jpg',0,'','2026-06-08 10:20:08','2026-06-08 10:20:08','',17975,41,41,250,78,3.21),
(1064,'4k-mems-logo.png',0,'','2026-06-08 10:20:47','2026-06-08 10:20:47','',131194,41,41,4296,1218,3.53);
/*!40000 ALTER TABLE `field_logo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_logos`
--

DROP TABLE IF EXISTS `field_logos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_logos` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(191) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `filedata` mediumtext DEFAULT NULL,
  `filesize` int(11) DEFAULT NULL,
  `created_users_id` int(10) unsigned NOT NULL DEFAULT 0,
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT 0,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `ratio` decimal(4,2) DEFAULT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `filesize` (`filesize`),
  KEY `width` (`width`),
  KEY `height` (`height`),
  KEY `ratio` (`ratio`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `filedata` (`filedata`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_logos`
--

LOCK TABLES `field_logos` WRITE;
/*!40000 ALTER TABLE `field_logos` DISABLE KEYS */;
INSERT INTO `field_logos` VALUES
(1018,'eic-logo-fundedby-cmyk_en.png',0,'','2026-06-10 12:34:22','2026-06-10 12:34:22','{\"uploadName\":\"EIC-logo-FundedBy-CMYK_EN.png\"}',67273,41,41,1600,213,7.51);
/*!40000 ALTER TABLE `field_logos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_multi_line_title`
--

DROP TABLE IF EXISTS `field_multi_line_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_multi_line_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `count` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(1)),
  KEY `count` (`count`,`pages_id`),
  KEY `parent_id` (`parent_id`,`pages_id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_multi_line_title`
--

LOCK TABLES `field_multi_line_title` WRITE;
/*!40000 ALTER TABLE `field_multi_line_title` DISABLE KEYS */;
INSERT INTO `field_multi_line_title` VALUES
(1023,'1076,1077,1078',3,1075),
(1035,'',0,1079);
/*!40000 ALTER TABLE `field_multi_line_title` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_pass`
--

DROP TABLE IF EXISTS `field_pass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_pass` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` char(40) NOT NULL,
  `salt` char(32) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_pass`
--

LOCK TABLES `field_pass` WRITE;
/*!40000 ALTER TABLE `field_pass` DISABLE KEYS */;
INSERT INTO `field_pass` VALUES
(40,'',''),
(41,'puIjOhWmfz87uRRYWeRH.eMq7cUo.uu','$2y$11$JbqQkepU4Kwh36uV9/9RV.');
/*!40000 ALTER TABLE `field_pass` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_permissions`
--

DROP TABLE IF EXISTS `field_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_permissions` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_permissions`
--

LOCK TABLES `field_permissions` WRITE;
/*!40000 ALTER TABLE `field_permissions` DISABLE KEYS */;
INSERT INTO `field_permissions` VALUES
(38,32,1),
(38,34,2),
(38,35,3),
(37,36,0),
(38,36,0),
(38,50,4),
(38,51,5),
(38,52,7),
(38,53,8),
(38,54,6);
/*!40000 ALTER TABLE `field_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_privacy_file`
--

DROP TABLE IF EXISTS `field_privacy_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_privacy_file` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(191) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `filedata` mediumtext DEFAULT NULL,
  `filesize` int(11) DEFAULT NULL,
  `created_users_id` int(10) unsigned NOT NULL DEFAULT 0,
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `filesize` (`filesize`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `filedata` (`filedata`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_privacy_file`
--

LOCK TABLES `field_privacy_file` WRITE;
/*!40000 ALTER TABLE `field_privacy_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `field_privacy_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_process`
--

DROP TABLE IF EXISTS `field_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_process` (
  `pages_id` int(11) NOT NULL DEFAULT 0,
  `data` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_process`
--

LOCK TABLES `field_process` WRITE;
/*!40000 ALTER TABLE `field_process` DISABLE KEYS */;
INSERT INTO `field_process` VALUES
(10,7),
(23,10),
(3,12),
(8,12),
(9,14),
(6,17),
(11,47),
(16,48),
(21,50),
(29,66),
(30,68),
(22,76),
(28,76),
(2,87),
(300,104),
(301,109),
(302,121),
(303,129),
(31,136),
(304,138),
(1007,150),
(1010,182),
(1012,233);
/*!40000 ALTER TABLE `field_process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_roles`
--

DROP TABLE IF EXISTS `field_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_roles` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_roles`
--

LOCK TABLES `field_roles` WRITE;
/*!40000 ALTER TABLE `field_roles` DISABLE KEYS */;
INSERT INTO `field_roles` VALUES
(40,37,0),
(41,37,0),
(41,38,2);
/*!40000 ALTER TABLE `field_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_title`
--

DROP TABLE IF EXISTS `field_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(191)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_title`
--

LOCK TABLES `field_title` WRITE;
/*!40000 ALTER TABLE `field_title` DISABLE KEYS */;
INSERT INTO `field_title` VALUES
(1,'Home'),
(2,'Admin'),
(3,'Pages'),
(6,'Add Page'),
(7,'Trash'),
(8,'Tree'),
(9,'Save Sort'),
(10,'Edit'),
(11,'Templates'),
(16,'Fields'),
(21,'Modules'),
(22,'Setup'),
(23,'Login'),
(27,'404 Page Not Found'),
(28,'Access'),
(29,'Users'),
(30,'Roles'),
(31,'Permissions'),
(32,'Edit pages'),
(34,'Delete pages'),
(35,'Move pages (change parent)'),
(36,'View pages'),
(50,'Sort child pages'),
(51,'Change templates on pages'),
(52,'Administer users'),
(53,'User can update profile/password'),
(54,'Lock or unlock a page'),
(300,'Search'),
(301,'Empty Trash'),
(302,'Insert Link'),
(303,'Insert Image'),
(304,'Profile'),
(1006,'Use Page Lister'),
(1007,'Find'),
(1010,'Recent'),
(1011,'Can see recently edited pages'),
(1012,'Logs'),
(1013,'Can view system logs'),
(1014,'Can manage system logs'),
(1015,'Repeaters'),
(1016,'hero_fieldset'),
(1017,'imagetext'),
(1018,'Site Settings'),
(1019,'MainMenu'),
(1020,'Home'),
(1021,'Project'),
(1022,'Contact Us'),
(1024,'home'),
(1026,'The BRIGHTIR Project'),
(1028,'project'),
(1031,'Results'),
(1032,'Highlights'),
(1034,'Project'),
(1036,'Goals'),
(1037,'Emitter Development'),
(1038,'Sensor Development'),
(1039,'Sensor Testing'),
(1040,'Highlights'),
(1041,'Paper XYZ presented at BrightMeeting 2026'),
(1042,'News One'),
(1044,'News Two'),
(1045,'Contact Us'),
(1047,'Highlight 12'),
(1048,'Highlight 123'),
(1049,'contact_cards'),
(1050,'contact-us'),
(1054,'Test Page'),
(1056,'test-page'),
(1058,'Partners'),
(1059,'Partners'),
(1060,'partners'),
(1062,'Università di Trento'),
(1063,'universita-di-trento'),
(1064,'4K-Mems'),
(1065,'4k-mems'),
(1074,'multi_line_title'),
(1075,'for-page-1'),
(1079,'for-page-1034'),
(1083,'for-page-1064'),
(1084,'for-page-1040'),
(1085,'for-page-1058'),
(1086,'for-page-1045'),
(1087,'http404'),
(1088,'for-page-27');
/*!40000 ALTER TABLE `field_title` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldgroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
INSERT INTO `fieldgroups` VALUES
(2,'admin'),
(83,'basic-page'),
(107,'contact-us'),
(104,'Goal'),
(103,'Goals'),
(106,'Highlight'),
(105,'Highlights'),
(1,'home'),
(101,'menu'),
(100,'menu-item'),
(110,'partner'),
(109,'partners'),
(5,'permission'),
(102,'project'),
(108,'repeater_contact_cards'),
(97,'repeater_hero_fieldset'),
(98,'repeater_imagetext'),
(111,'repeater_multi_line_title'),
(4,'role'),
(99,'site-settings'),
(3,'user');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups_fields`
--

DROP TABLE IF EXISTS `fieldgroups_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldgroups_fields` (
  `fieldgroups_id` int(10) unsigned NOT NULL DEFAULT 0,
  `fields_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sort` int(11) unsigned NOT NULL DEFAULT 0,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`fieldgroups_id`,`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups_fields`
--

LOCK TABLES `fieldgroups_fields` WRITE;
/*!40000 ALTER TABLE `fieldgroups_fields` DISABLE KEYS */;
INSERT INTO `fieldgroups_fields` VALUES
(1,1,0,NULL),
(1,98,1,NULL),
(1,107,4,NULL),
(1,119,2,'{\"columnWidth\":50}'),
(1,120,3,'{\"columnWidth\":50,\"maxlength\":2048}'),
(1,121,5,'{\"columnWidth\":50,\"maxlength\":2048}'),
(1,122,6,'{\"columnWidth\":50,\"maxlength\":2048}'),
(2,1,0,NULL),
(2,2,1,NULL),
(3,3,0,NULL),
(3,4,2,NULL),
(3,92,1,NULL),
(3,97,3,NULL),
(4,5,0,NULL),
(5,1,0,NULL),
(83,1,0,NULL),
(83,98,1,NULL),
(83,103,2,NULL),
(83,107,3,NULL),
(97,99,0,NULL),
(97,100,3,NULL),
(97,102,1,NULL),
(97,118,4,NULL),
(97,124,2,NULL),
(98,99,1,'{\"columnWidth\":25}'),
(98,100,3,'{\"columnWidth\":25,\"label\":\"Pretitle\"}'),
(98,101,4,'{\"columnWidth\":50}'),
(98,102,2,'{\"columnWidth\":25}'),
(98,106,0,'{\"columnWidth\":25}'),
(99,1,0,NULL),
(99,101,4,'{\"label\":\"Footer Text\"}'),
(99,104,3,NULL),
(99,109,1,NULL),
(99,110,5,NULL),
(99,111,2,NULL),
(99,123,6,NULL),
(100,1,0,NULL),
(100,112,2,NULL),
(100,113,1,NULL),
(101,1,0,NULL),
(102,1,0,NULL),
(102,98,1,NULL),
(102,103,4,NULL),
(102,119,2,NULL),
(102,120,3,NULL),
(103,1,0,NULL),
(104,1,3,NULL),
(104,100,2,'{\"label\":\"Pretitle\"}'),
(104,101,4,NULL),
(104,102,0,'{\"label\":\"Goal Number\"}'),
(104,103,5,'{\"description\":\"Used in goal cards in homepage\",\"label\":\"Abstract\"}'),
(104,114,1,'{\"description\":\"\"}'),
(105,1,0,NULL),
(105,98,1,NULL),
(105,103,2,NULL),
(106,1,0,NULL),
(106,99,3,'{\"label\":\"Hero Image\"}'),
(106,100,1,NULL),
(106,103,4,NULL),
(106,114,2,NULL),
(106,115,5,NULL),
(107,1,0,NULL),
(107,98,1,NULL),
(107,103,2,NULL),
(107,116,3,NULL),
(108,92,2,NULL),
(108,102,0,NULL),
(108,103,1,NULL),
(108,117,3,NULL),
(109,1,0,NULL),
(109,98,1,NULL),
(109,103,2,NULL),
(110,1,0,NULL),
(110,98,1,NULL),
(110,103,3,NULL),
(110,107,4,NULL),
(110,109,2,NULL),
(111,102,0,NULL);
/*!40000 ALTER TABLE `fieldgroups_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(128) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `name` varchar(191) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `flags` int(11) NOT NULL DEFAULT 0,
  `label` varchar(191) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES
(1,'FieldtypePageTitle','title',13,'Title','{\"required\":1,\"textformatters\":[\"TextformatterEntities\"],\"size\":0,\"maxlength\":255}'),
(2,'FieldtypeModule','process',25,'Process','{\"description\":\"The process that is executed on this page. Since this is mostly used by ProcessWire internally, it is recommended that you don\'t change the value of this unless adding your own pages in the admin.\",\"collapsed\":1,\"required\":1,\"moduleTypes\":[\"Process\"],\"permanent\":1}'),
(3,'FieldtypePassword','pass',24,'Set Password','{\"collapsed\":1,\"size\":50,\"maxlength\":128}'),
(4,'FieldtypePage','roles',24,'Roles','{\"derefAsPage\":0,\"parent_id\":30,\"labelFieldName\":\"name\",\"inputfield\":\"InputfieldCheckboxes\",\"description\":\"User will inherit the permissions assigned to each role. You may assign multiple roles to a user. When accessing a page, the user will only inherit permissions from the roles that are also assigned to the page\'s template.\"}'),
(5,'FieldtypePage','permissions',24,'Permissions','{\"derefAsPage\":0,\"parent_id\":31,\"labelFieldName\":\"title\",\"inputfield\":\"InputfieldCheckboxes\"}'),
(92,'FieldtypeEmail','email',9,'E-Mail Address','{\"size\":70,\"maxlength\":255}'),
(97,'FieldtypeModule','admin_theme',8,'Admin Theme','{\"moduleTypes\":[\"AdminTheme\"],\"labelField\":\"title\",\"inputfieldClass\":\"InputfieldRadios\"}'),
(98,'FieldtypeFieldsetPage','hero_fieldset',0,'Hero','{\"repeaterLoading\":2,\"repeaterMaxItems\":1,\"repeaterMinItems\":1,\"template_id\":43,\"parent_id\":1016,\"repeaterFields\":[99,102,124,100,118],\"collapsed\":0}'),
(99,'FieldtypeImage','c_image',0,'Image','{\"fileSchema\":270,\"maxFiles\":1,\"extensions\":\"gif jpg jpeg png\",\"descriptionRows\":1,\"gridMode\":\"grid\",\"focusMode\":\"on\",\"clientQuality\":90,\"inputfieldClass\":\"InputfieldImage\"}'),
(100,'FieldtypeText','c_subtitle',0,'Subtitle','{\"textformatters\":[\"TextformatterEntities\"],\"maxlength\":2048}'),
(101,'FieldtypeTextarea','c_text',0,'Text','{\"inputfieldClass\":\"InputfieldTinyMCE\",\"contentType\":1,\"height\":500,\"lazyMode\":1,\"features\":[\"toolbar\",\"menubar\",\"stickybars\",\"purifier\",\"imgUpload\",\"imgResize\",\"pasteFilter\"],\"toolbar\":\"styles bold italic pwlink pwimage blockquote hr bullist numlist table anchor code\",\"plugins\":[\"anchor\",\"code\",\"link\",\"lists\",\"pwimage\",\"pwlink\",\"table\"],\"rows\":15,\"inlineMode\":0,\"collapsed\":0,\"minlength\":0,\"maxlength\":0,\"showCount\":0}'),
(102,'FieldtypeText','c_title',0,'Title','{\"textformatters\":[\"TextformatterEntities\"],\"maxlength\":2048}'),
(103,'FieldtypeTextarea','content',0,'Content','{\"inputfieldClass\":\"InputfieldTinyMCE\",\"contentType\":1,\"height\":500,\"lazyMode\":1,\"features\":[\"toolbar\",\"menubar\",\"stickybars\",\"purifier\",\"imgUpload\",\"imgResize\",\"pasteFilter\"],\"toolbar\":\"styles bold italic pwlink pwimage blockquote hr bullist numlist table anchor code\",\"plugins\":[\"anchor\",\"code\",\"link\",\"lists\",\"pwimage\",\"pwlink\",\"table\"],\"rows\":15,\"inlineMode\":0,\"collapsed\":0,\"minlength\":0,\"maxlength\":0,\"showCount\":0}'),
(104,'FieldtypeTextarea','copyright',0,'Copyright','{\"inputfieldClass\":\"InputfieldTinyMCE\",\"contentType\":1,\"height\":500,\"lazyMode\":1,\"features\":[\"toolbar\",\"menubar\",\"stickybars\",\"purifier\",\"imgUpload\",\"imgResize\",\"pasteFilter\"],\"toolbar\":\"styles bold italic pwlink pwimage blockquote hr bullist numlist table anchor code\",\"plugins\":[\"anchor\",\"code\",\"link\",\"lists\",\"pwimage\",\"pwlink\",\"table\"],\"rows\":15,\"inlineMode\":0,\"collapsed\":0,\"minlength\":0,\"maxlength\":0,\"showCount\":0}'),
(105,'FieldtypeDatetime','date',0,'Date','{\"dateOutputFormat\":\"Y-m-d\",\"dateInputFormat\":\"Y-m-d\",\"inputType\":\"html\",\"htmlType\":\"date\",\"dateSelectFormat\":\"yMd\",\"yearFrom\":1924,\"yearTo\":2044,\"size\":25}'),
(106,'FieldtypeOptions','image_position',0,'Image Position','{\"inputfieldClass\":\"InputfieldRadios\",\"collapsed\":0,\"optionColumns\":0}'),
(107,'FieldtypeRepeater','imagetext',0,'ImageText','{\"repeaterLoading\":1,\"repeaterFields\":[106,99,102,100,101],\"template_id\":44,\"parent_id\":1017,\"familyFriendly\":0,\"familyToggle\":0,\"repeaterCollapse\":0,\"rememberOpen\":0,\"accordionMode\":0,\"loudControls\":0,\"noScroll\":0,\"collapsed\":0}'),
(108,'FieldtypeColor','color',0,'Color','{\"defaultValue\":\"ff80ff95\"}'),
(109,'FieldtypeImage','logo',0,'Logo','{\"fileSchema\":270,\"maxFiles\":1,\"textformatters\":[\"TextformatterEntities\"],\"extensions\":\"gif jpg jpeg png\",\"outputFormat\":0,\"descriptionRows\":1,\"useTags\":0,\"gridMode\":\"grid\",\"focusMode\":\"on\",\"resizeServer\":0,\"clientQuality\":90,\"maxReject\":0,\"dimensionsByAspectRatio\":0,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldImage\",\"collapsed\":0}'),
(110,'FieldtypeFile','privacy_file',0,'Privacy File','{\"maxFiles\":1,\"textformatters\":[\"TextformatterEntities\"],\"extensions\":\"pdf doc docx xls xlsx gif jpg jpeg png\",\"outputFormat\":0,\"descriptionRows\":1,\"useTags\":0,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldFile\",\"fileSchema\":14}'),
(111,'FieldtypeEmail','contacts_email',0,'Contacts Email','{\"textformatters\":[\"TextformatterEntities\"],\"collapsed\":0,\"minlength\":0,\"maxlength\":250,\"showCount\":0,\"size\":0,\"allowIDN\":0}'),
(112,'FieldtypeCheckbox','link_blank',0,'Target Blank?',''),
(113,'FieldtypeURL','link_url',0,'Link URL','{\"textformatters\":[\"TextformatterEntities\"],\"maxlength\":1024}'),
(114,'FieldtypeCheckbox','featured',0,'Featured','{\"collapsed\":0}'),
(115,'FieldtypeImage','image_gallery',0,'Image Gallery','{\"fileSchema\":270,\"maxFiles\":12,\"textformatters\":[\"TextformatterEntities\"],\"extensions\":\"gif jpg jpeg png\",\"outputFormat\":0,\"descriptionRows\":1,\"useTags\":0,\"collapsed\":0,\"gridMode\":\"grid\",\"focusMode\":\"on\",\"resizeServer\":0,\"clientQuality\":90,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldImage\",\"maxWidth\":1600}'),
(116,'FieldtypeRepeater','contact_cards',0,'Contact Cards','{\"template_id\":54,\"parent_id\":1049,\"repeaterFields\":[102,103,92,117],\"familyFriendly\":0,\"familyToggle\":0,\"repeaterCollapse\":0,\"repeaterLoading\":1,\"rememberOpen\":0,\"accordionMode\":0,\"loudControls\":0,\"noScroll\":0,\"collapsed\":0}'),
(117,'FieldtypeOptions','brand_color',0,'Brand Color','{\"inputfieldClass\":\"InputfieldRadios\",\"collapsed\":0,\"optionColumns\":0}'),
(118,'FieldtypeOptions','hero_size',0,'Hero Size','{\"inputfieldClass\":\"InputfieldSelect\",\"collapsed\":0}'),
(119,'FieldtypeText','goals_title',0,'Goals Title','{\"textformatters\":[\"TextformatterEntities\"],\"collapsed\":0,\"minlength\":0,\"maxlength\":2048,\"showCount\":0,\"size\":0}'),
(120,'FieldtypeText','goals_pretitle',0,'Goals Pretitle','{\"textformatters\":[\"TextformatterEntities\"]}'),
(121,'FieldtypeText','highlights_title',0,'Highlights Title','{\"textformatters\":[\"TextformatterEntities\"]}'),
(122,'FieldtypeText','highlights_pretitle',0,'Highlights Pretitle','{\"textformatters\":[\"TextformatterEntities\"]}'),
(123,'FieldtypeImage','logos',0,'Logos','{\"fileSchema\":270,\"textformatters\":[\"TextformatterEntities\"],\"extensions\":\"gif jpg jpeg png\",\"outputFormat\":0,\"descriptionRows\":1,\"useTags\":0,\"gridMode\":\"grid\",\"focusMode\":\"on\",\"maxWidth\":1600,\"resizeServer\":0,\"clientQuality\":90,\"defaultValuePage\":0,\"inputfieldClass\":\"InputfieldImage\"}'),
(124,'FieldtypeRepeater','multi_line_title',0,'Multi Line Title','{\"template_id\":57,\"parent_id\":1074,\"repeaterFields\":[102],\"familyFriendly\":0,\"familyToggle\":0,\"repeaterCollapse\":0,\"repeaterLoading\":1,\"rememberOpen\":0,\"accordionMode\":0,\"loudControls\":0,\"noScroll\":0,\"collapsed\":0}');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldtype_options`
--

DROP TABLE IF EXISTS `fieldtype_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldtype_options` (
  `fields_id` int(10) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL,
  `title` text DEFAULT NULL,
  `value` varchar(171) DEFAULT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`fields_id`,`option_id`),
  UNIQUE KEY `title` (`title`(171),`fields_id`),
  KEY `value` (`value`,`fields_id`),
  KEY `sort` (`sort`,`fields_id`),
  FULLTEXT KEY `title_ft` (`title`),
  FULLTEXT KEY `value_ft` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldtype_options`
--

LOCK TABLES `fieldtype_options` WRITE;
/*!40000 ALTER TABLE `fieldtype_options` DISABLE KEYS */;
INSERT INTO `fieldtype_options` VALUES
(106,1,'left','',0),
(106,2,'right','',1),
(117,1,'teal','',0),
(117,2,'yellow','',1),
(118,1,'small','',0),
(118,2,'large','',1);
/*!40000 ALTER TABLE `fieldtype_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(128) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `flags` int(11) NOT NULL DEFAULT 0,
  `data` mediumtext NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `class` (`class`)
) ENGINE=InnoDB AUTO_INCREMENT=755 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES
(1,'FieldtypeTextarea',0,'','2026-04-30 21:45:56'),
(3,'FieldtypeText',0,'','2026-04-30 21:45:56'),
(4,'FieldtypePage',3,'','2026-04-30 21:45:56'),
(6,'FieldtypeFile',0,'','2026-04-30 21:45:56'),
(7,'ProcessPageEdit',1,'','2026-04-30 21:45:56'),
(10,'ProcessLogin',0,'','2026-04-30 21:45:56'),
(12,'ProcessPageList',0,'{\"pageLabelField\":\"title\",\"paginationLimit\":25,\"limit\":50}','2026-04-30 21:45:56'),
(14,'ProcessPageSort',0,'','2026-04-30 21:45:56'),
(15,'InputfieldPageListSelect',0,'','2026-04-30 21:45:56'),
(17,'ProcessPageAdd',0,'','2026-04-30 21:45:56'),
(25,'InputfieldAsmSelect',0,'','2026-04-30 21:45:56'),
(27,'FieldtypeModule',1,'','2026-04-30 21:45:56'),
(28,'FieldtypeDatetime',0,'','2026-04-30 21:45:56'),
(29,'FieldtypeEmail',1,'','2026-04-30 21:45:56'),
(30,'InputfieldForm',0,'','2026-04-30 21:45:56'),
(32,'InputfieldSubmit',0,'','2026-04-30 21:45:56'),
(34,'InputfieldText',0,'','2026-04-30 21:45:56'),
(35,'InputfieldTextarea',0,'','2026-04-30 21:45:56'),
(36,'InputfieldSelect',0,'','2026-04-30 21:45:56'),
(37,'InputfieldCheckbox',0,'','2026-04-30 21:45:56'),
(38,'InputfieldCheckboxes',0,'','2026-04-30 21:45:56'),
(39,'InputfieldRadios',0,'','2026-04-30 21:45:56'),
(40,'InputfieldHidden',0,'','2026-04-30 21:45:56'),
(41,'InputfieldName',0,'','2026-04-30 21:45:56'),
(43,'InputfieldSelectMultiple',0,'','2026-04-30 21:45:56'),
(45,'JqueryWireTabs',0,'','2026-04-30 21:45:56'),
(47,'ProcessTemplate',0,'','2026-04-30 21:45:56'),
(48,'ProcessField',32,'','2026-04-30 21:45:56'),
(50,'ProcessModule',0,'','2026-04-30 21:45:56'),
(55,'InputfieldFile',0,'','2026-04-30 21:45:56'),
(56,'InputfieldImage',0,'','2026-04-30 21:45:56'),
(57,'FieldtypeImage',0,'','2026-04-30 21:45:56'),
(60,'InputfieldPage',0,'{\"inputfieldClasses\":[\"InputfieldSelect\",\"InputfieldSelectMultiple\",\"InputfieldCheckboxes\",\"InputfieldRadios\",\"InputfieldAsmSelect\",\"InputfieldPageListSelect\",\"InputfieldPageListSelectMultiple\",\"InputfieldPageAutocomplete\"]}','2026-04-30 21:45:56'),
(61,'TextformatterEntities',0,'','2026-04-30 21:45:56'),
(66,'ProcessUser',0,'{\"showFields\":[\"name\",\"email\",\"roles\"]}','2026-04-30 21:45:56'),
(67,'MarkupAdminDataTable',0,'','2026-04-30 21:45:56'),
(68,'ProcessRole',0,'{\"showFields\":[\"name\"]}','2026-04-30 21:45:56'),
(76,'ProcessList',0,'','2026-04-30 21:45:56'),
(78,'InputfieldFieldset',0,'','2026-04-30 21:45:56'),
(79,'InputfieldMarkup',0,'','2026-04-30 21:45:56'),
(80,'InputfieldEmail',0,'','2026-04-30 21:45:56'),
(83,'ProcessPageView',0,'','2026-04-30 21:45:56'),
(84,'FieldtypeInteger',0,'','2026-04-30 21:45:56'),
(85,'InputfieldInteger',0,'','2026-04-30 21:45:56'),
(86,'InputfieldPageName',0,'','2026-04-30 21:45:56'),
(87,'ProcessHome',0,'','2026-04-30 21:45:56'),
(89,'FieldtypeFloat',1,'','2026-04-30 21:45:56'),
(90,'InputfieldFloat',0,'','2026-04-30 21:45:56'),
(94,'InputfieldDatetime',0,'','2026-04-30 21:45:56'),
(97,'FieldtypeCheckbox',1,'','2026-04-30 21:45:56'),
(98,'MarkupPagerNav',0,'','2026-04-30 21:45:56'),
(103,'JqueryTableSorter',1,'','2026-04-30 21:45:56'),
(104,'ProcessPageSearch',1,'{\"searchFields\":\"title\",\"displayField\":\"title path\"}','2026-04-30 21:45:56'),
(105,'FieldtypeFieldsetOpen',1,'','2026-04-30 21:45:56'),
(106,'FieldtypeFieldsetClose',1,'','2026-04-30 21:45:56'),
(107,'FieldtypeFieldsetTabOpen',1,'','2026-04-30 21:45:56'),
(108,'InputfieldURL',0,'','2026-04-30 21:45:56'),
(109,'ProcessPageTrash',1,'','2026-04-30 21:45:56'),
(111,'FieldtypePageTitle',1,'','2026-04-30 21:45:56'),
(112,'InputfieldPageTitle',0,'','2026-04-30 21:45:56'),
(113,'MarkupPageArray',3,'','2026-04-30 21:45:56'),
(114,'PagePermissions',3,'','2026-04-30 21:45:56'),
(115,'PageRender',3,'{\"clearCache\":1}','2026-04-30 21:45:56'),
(116,'JqueryCore',1,'','2026-04-30 21:45:56'),
(117,'JqueryUI',1,'','2026-04-30 21:45:56'),
(121,'ProcessPageEditLink',1,'','2026-04-30 21:45:56'),
(122,'InputfieldPassword',0,'','2026-04-30 21:45:56'),
(125,'SessionLoginThrottle',11,'','2026-04-30 21:45:56'),
(129,'ProcessPageEditImageSelect',1,'','2026-04-30 21:45:56'),
(131,'InputfieldButton',0,'','2026-04-30 21:45:56'),
(133,'FieldtypePassword',1,'','2026-04-30 21:45:56'),
(134,'ProcessPageType',33,'{\"showFields\":[]}','2026-04-30 21:45:56'),
(135,'FieldtypeURL',1,'','2026-04-30 21:45:56'),
(136,'ProcessPermission',1,'{\"showFields\":[\"name\",\"title\"]}','2026-04-30 21:45:56'),
(137,'InputfieldPageListSelectMultiple',0,'','2026-04-30 21:45:56'),
(138,'ProcessProfile',1,'{\"profileFields\":[\"pass\",\"email\",\"admin_theme\"]}','2026-04-30 21:45:56'),
(139,'SystemUpdater',1,'{\"systemVersion\":21,\"coreVersion\":\"3.0.255\"}','2026-04-30 21:45:56'),
(149,'InputfieldSelector',42,'','2026-04-30 21:45:56'),
(150,'ProcessPageLister',32,'','2026-04-30 21:45:56'),
(151,'JqueryMagnific',1,'','2026-04-30 21:45:56'),
(155,'InputfieldTinyMCE',0,'','2026-04-30 21:45:56'),
(156,'MarkupHTMLPurifier',0,'','2026-04-30 21:45:56'),
(159,'.Modules.wire/modules/',8192,'PagePermissions.module\nSystem/SystemUpdater/SystemUpdater.module\nSystem/SystemNotifications/SystemNotifications.module\nSystem/SystemNotifications/FieldtypeNotifications.module\nLanguageSupport/FieldtypeTextLanguage.module\nLanguageSupport/ProcessLanguageTranslator.module\nLanguageSupport/LanguageTabs.module\nLanguageSupport/LanguageSupportFields.module\nLanguageSupport/ProcessLanguage.module\nLanguageSupport/FieldtypePageTitleLanguage.module\nLanguageSupport/FieldtypeTextareaLanguage.module\nLanguageSupport/LanguageSupportPageNames.module\nLanguageSupport/LanguageSupport.module\nPage/PageFrontEdit/PageFrontEdit.module\nAdminTheme/AdminThemeReno/AdminThemeReno.module\nAdminTheme/AdminThemeUikit/AdminThemeUikit.module\nAdminTheme/AdminThemeDefault/AdminThemeDefault.module\nPagePaths.module\nInputfield/InputfieldSubmit/InputfieldSubmit.module\nInputfield/InputfieldCKEditor/InputfieldCKEditor.module\nInputfield/InputfieldPageListSelect/InputfieldPageListSelect.module\nInputfield/InputfieldPageListSelect/InputfieldPageListSelectMultiple.module\nInputfield/InputfieldSelect.module\nInputfield/InputfieldAsmSelect/InputfieldAsmSelect.module\nInputfield/InputfieldName.module\nInputfield/InputfieldDatetime/InputfieldDatetime.module\nInputfield/InputfieldIcon/InputfieldIcon.module\nInputfield/InputfieldPageName/InputfieldPageName.module\nInputfield/InputfieldPassword/InputfieldPassword.module\nInputfield/InputfieldSelector/InputfieldSelector.module\nInputfield/InputfieldFieldset.module\nInputfield/InputfieldInteger.module\nInputfield/InputfieldPageTitle/InputfieldPageTitle.module\nInputfield/InputfieldHidden.module\nInputfield/InputfieldImage/InputfieldImage.module\nInputfield/InputfieldMarkup.module\nInputfield/InputfieldForm.module\nInputfield/InputfieldTextTags/InputfieldTextTags.module\nInputfield/InputfieldTinyMCE/InputfieldTinyMCE.module.php\nInputfield/InputfieldFile/InputfieldFile.module\nInputfield/InputfieldCheckboxes/InputfieldCheckboxes.module\nInputfield/InputfieldSelectMultiple.module\nInputfield/InputfieldPageAutocomplete/InputfieldPageAutocomplete.module\nInputfield/InputfieldCheckbox/InputfieldCheckbox.module\nInputfield/InputfieldURL.module\nInputfield/InputfieldFloat.module\nInputfield/InputfieldToggle/InputfieldToggle.module\nInputfield/InputfieldRadios/InputfieldRadios.module\nInputfield/InputfieldPageTable/InputfieldPageTable.module\nInputfield/InputfieldPage/InputfieldPage.module\nInputfield/InputfieldButton.module\nInputfield/InputfieldTextarea.module\nInputfield/InputfieldText/InputfieldText.module\nInputfield/InputfieldEmail.module\nProcess/ProcessLogin/ProcessLogin.module\nProcess/ProcessPageSort.module\nProcess/ProcessPageLister/ProcessPageLister.module\nProcess/ProcessPageEditImageSelect/ProcessPageEditImageSelect.module\nProcess/ProcessField/ProcessField.module\nProcess/ProcessPagesExportImport/ProcessPagesExportImport.module\nProcess/ProcessLogger/ProcessLogger.module\nProcess/ProcessUser/ProcessUser.module\nProcess/ProcessPageSearch/ProcessPageSearch.module\nProcess/ProcessPageAdd/ProcessPageAdd.module\nProcess/ProcessPageEditLink/ProcessPageEditLink.module\nProcess/ProcessTemplate/ProcessTemplate.module\nProcess/ProcessPageList/ProcessPageList.module\nProcess/ProcessProfile/ProcessProfile.module\nProcess/ProcessPageClone.module\nProcess/ProcessRecentPages/ProcessRecentPages.module\nProcess/ProcessPageType/ProcessPageType.module\nProcess/ProcessModule/ProcessModule.module\nProcess/ProcessHome.module\nProcess/ProcessRole/ProcessRole.module\nProcess/ProcessPageTrash.module\nProcess/ProcessPermission/ProcessPermission.module\nProcess/ProcessForgotPassword/ProcessForgotPassword.module\nProcess/ProcessPageView.module\nProcess/ProcessList.module\nProcess/ProcessCommentsManager/ProcessCommentsManager.module\nProcess/ProcessPageEdit/ProcessPageEdit.module\nTextformatter/TextformatterSmartypants/TextformatterSmartypants.module\nTextformatter/TextformatterNewlineUL.module\nTextformatter/TextformatterStripTags.module\nTextformatter/TextformatterNewlineBR.module\nTextformatter/TextformatterMarkdownExtra/TextformatterMarkdownExtra.module\nTextformatter/TextformatterPstripper.module\nTextformatter/TextformatterEntities.module\nMarkup/MarkupPagerNav/MarkupPagerNav.module\nMarkup/MarkupPageArray.module\nMarkup/MarkupPageFields.module\nMarkup/MarkupRSS.module\nMarkup/MarkupHTMLPurifier/MarkupHTMLPurifier.module\nMarkup/MarkupCache.module\nMarkup/MarkupAdminDataTable/MarkupAdminDataTable.module\nFileValidatorZip.module\nSession/SessionHandlerDB/ProcessSessionDB.module\nSession/SessionHandlerDB/SessionHandlerDB.module\nSession/SessionLoginThrottle/SessionLoginThrottle.module\nPages/PagesVersions/PagesVersions.module.php\nImage/ImageSizerEngineAnimatedGif/ImageSizerEngineAnimatedGif.module\nImage/ImageSizerEngineIMagick/ImageSizerEngineIMagick.module\nFileCompilerTags.module\nPagePathHistory.module\nJquery/JqueryTableSorter/JqueryTableSorter.module\nJquery/JqueryMagnific/JqueryMagnific.module\nJquery/JqueryCore/JqueryCore.module\nJquery/JqueryWireTabs/JqueryWireTabs.module\nJquery/JqueryUI/JqueryUI.module\nLazyCron.module\nPageRender.module\nFieldtype/FieldtypeOptions/FieldtypeOptions.module\nFieldtype/FieldtypeTextarea.module\nFieldtype/FieldtypeDecimal.module\nFieldtype/FieldtypeFloat.module\nFieldtype/FieldtypeURL.module\nFieldtype/FieldtypePageTable.module\nFieldtype/FieldtypeSelector.module\nFieldtype/FieldtypeToggle.module\nFieldtype/FieldtypeImage/FieldtypeImage.module\nFieldtype/FieldtypeInteger.module\nFieldtype/FieldtypeFieldsetTabOpen.module\nFieldtype/FieldtypeEmail.module\nFieldtype/FieldtypeModule.module\nFieldtype/FieldtypeFieldsetClose.module\nFieldtype/FieldtypeCache.module\nFieldtype/FieldtypeComments/CommentFilterAkismet.module\nFieldtype/FieldtypeComments/FieldtypeComments.module\nFieldtype/FieldtypeComments/InputfieldCommentsAdmin.module\nFieldtype/FieldtypeCheckbox.module\nFieldtype/FieldtypePageTitle.module\nFieldtype/FieldtypeText.module\nFieldtype/FieldtypeFieldsetOpen.module\nFieldtype/FieldtypeDatetime.module\nFieldtype/FieldtypeRepeater/FieldtypeFieldsetPage.module\nFieldtype/FieldtypeRepeater/FieldtypeRepeater.module\nFieldtype/FieldtypeRepeater/InputfieldRepeater.module\nFieldtype/FieldtypePage.module\nFieldtype/FieldtypePassword.module\nFieldtype/FieldtypeFile/FieldtypeFile.module','2026-04-30 21:46:56'),
(160,'.Modules.site/modules/',8192,'FieldtypeColor/FieldtypeOptionsColor.module\nFieldtypeColor/InputfieldColor.module\nFieldtypeColor/FieldtypeColor.module','2026-04-30 21:46:56'),
(162,'.Modules.info',8192,'{\"114\":{\"name\":\"PagePermissions\",\"title\":\"Page Permissions\",\"version\":105,\"autoload\":true,\"singular\":true,\"created\":1777585556,\"permanent\":true},\"139\":{\"name\":\"SystemUpdater\",\"title\":\"System Updater\",\"version\":21,\"singular\":true,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"197\":{\"name\":\"AdminThemeUikit\",\"title\":\"Uikit\",\"version\":36,\"icon\":\"smile-o\",\"autoload\":\"template=admin\",\"created\":1777585616,\"configurable\":4},\"32\":{\"name\":\"InputfieldSubmit\",\"title\":\"Submit\",\"version\":103,\"created\":1777585556,\"permanent\":true},\"15\":{\"name\":\"InputfieldPageListSelect\",\"title\":\"Page List Select\",\"version\":101,\"created\":1777585556,\"permanent\":true},\"137\":{\"name\":\"InputfieldPageListSelectMultiple\",\"title\":\"Page List Select Multiple\",\"version\":103,\"created\":1777585556,\"permanent\":true},\"36\":{\"name\":\"InputfieldSelect\",\"title\":\"Select\",\"version\":103,\"created\":1777585556,\"permanent\":true},\"25\":{\"name\":\"InputfieldAsmSelect\",\"title\":\"asmSelect\",\"version\":203,\"created\":1777585556,\"permanent\":true},\"41\":{\"name\":\"InputfieldName\",\"title\":\"Name\",\"version\":100,\"created\":1777585556,\"permanent\":true},\"94\":{\"name\":\"InputfieldDatetime\",\"title\":\"Datetime\",\"version\":108,\"created\":1777585556,\"permanent\":true},\"238\":{\"name\":\"InputfieldIcon\",\"title\":\"Icon\",\"version\":3,\"created\":1777585627},\"86\":{\"name\":\"InputfieldPageName\",\"title\":\"Page Name\",\"version\":106,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"122\":{\"name\":\"InputfieldPassword\",\"title\":\"Password\",\"version\":102,\"created\":1777585556,\"permanent\":true},\"149\":{\"name\":\"InputfieldSelector\",\"title\":\"Selector\",\"version\":28,\"autoload\":\"template=admin\",\"created\":1777585556,\"configurable\":3,\"addFlag\":32},\"78\":{\"name\":\"InputfieldFieldset\",\"title\":\"Fieldset\",\"version\":101,\"created\":1777585556,\"permanent\":true},\"85\":{\"name\":\"InputfieldInteger\",\"title\":\"Integer\",\"version\":105,\"created\":1777585556,\"permanent\":true},\"112\":{\"name\":\"InputfieldPageTitle\",\"title\":\"Page Title\",\"version\":102,\"created\":1777585556,\"permanent\":true},\"40\":{\"name\":\"InputfieldHidden\",\"title\":\"Hidden\",\"version\":101,\"created\":1777585556,\"permanent\":true},\"56\":{\"name\":\"InputfieldImage\",\"title\":\"Images\",\"version\":129,\"created\":1777585556,\"permanent\":true},\"79\":{\"name\":\"InputfieldMarkup\",\"title\":\"Markup\",\"version\":102,\"created\":1777585556,\"permanent\":true},\"30\":{\"name\":\"InputfieldForm\",\"title\":\"Form\",\"version\":107,\"created\":1777585556,\"permanent\":true},\"667\":{\"name\":\"InputfieldTextTags\",\"title\":\"Text Tags\",\"version\":7,\"icon\":\"tags\",\"created\":1777797753},\"155\":{\"name\":\"InputfieldTinyMCE\",\"title\":\"TinyMCE\",\"version\":618,\"icon\":\"keyboard-o\",\"requiresVersions\":{\"ProcessWire\":[\">=\",\"3.0.200\"],\"MarkupHTMLPurifier\":[\">=\",0]},\"created\":1777585556,\"configurable\":4},\"55\":{\"name\":\"InputfieldFile\",\"title\":\"Files\",\"version\":129,\"created\":1777585556,\"permanent\":true},\"38\":{\"name\":\"InputfieldCheckboxes\",\"title\":\"Checkboxes\",\"version\":108,\"created\":1777585556,\"permanent\":true},\"43\":{\"name\":\"InputfieldSelectMultiple\",\"title\":\"Select Multiple\",\"version\":101,\"created\":1777585556,\"permanent\":true},\"37\":{\"name\":\"InputfieldCheckbox\",\"title\":\"Checkbox\",\"version\":106,\"created\":1777585556,\"permanent\":true},\"108\":{\"name\":\"InputfieldURL\",\"title\":\"URL\",\"version\":103,\"created\":1777585556},\"90\":{\"name\":\"InputfieldFloat\",\"title\":\"Float\",\"version\":105,\"created\":1777585556,\"permanent\":true},\"662\":{\"name\":\"InputfieldToggle\",\"title\":\"Toggle\",\"version\":1,\"created\":1777797753},\"39\":{\"name\":\"InputfieldRadios\",\"title\":\"Radio Buttons\",\"version\":106,\"created\":1777585556,\"permanent\":true},\"60\":{\"name\":\"InputfieldPage\",\"title\":\"Page\",\"version\":109,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"131\":{\"name\":\"InputfieldButton\",\"title\":\"Button\",\"version\":100,\"created\":1777585556,\"permanent\":true},\"35\":{\"name\":\"InputfieldTextarea\",\"title\":\"Textarea\",\"version\":103,\"created\":1777585556,\"permanent\":true},\"34\":{\"name\":\"InputfieldText\",\"title\":\"Text\",\"version\":106,\"created\":1777585556,\"permanent\":true},\"80\":{\"name\":\"InputfieldEmail\",\"title\":\"Email\",\"version\":102,\"created\":1777585556},\"10\":{\"name\":\"ProcessLogin\",\"title\":\"Login\",\"version\":109,\"permission\":\"page-view\",\"created\":1777585556,\"configurable\":4,\"permanent\":true},\"14\":{\"name\":\"ProcessPageSort\",\"title\":\"Page Sort and Move\",\"version\":101,\"permission\":\"page-edit\",\"created\":1777585556,\"permanent\":true},\"150\":{\"name\":\"ProcessPageLister\",\"title\":\"Lister\",\"version\":26,\"icon\":\"search\",\"permission\":\"page-lister\",\"created\":1777585556,\"configurable\":true,\"permanent\":true,\"useNavJSON\":true,\"addFlag\":32},\"129\":{\"name\":\"ProcessPageEditImageSelect\",\"title\":\"Page Edit Image\",\"version\":121,\"permission\":\"page-edit\",\"singular\":1,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"48\":{\"name\":\"ProcessField\",\"title\":\"Fields\",\"version\":114,\"icon\":\"cube\",\"permission\":\"field-admin\",\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true,\"addFlag\":32},\"233\":{\"name\":\"ProcessLogger\",\"title\":\"Logs\",\"version\":2,\"icon\":\"tree\",\"permission\":\"logs-view\",\"singular\":1,\"created\":1777585627,\"useNavJSON\":true},\"66\":{\"name\":\"ProcessUser\",\"title\":\"Users\",\"version\":107,\"icon\":\"group\",\"permission\":\"user-admin\",\"created\":1777585556,\"configurable\":\"ProcessUserConfig.php\",\"permanent\":true,\"useNavJSON\":true},\"104\":{\"name\":\"ProcessPageSearch\",\"title\":\"Page Search\",\"version\":108,\"permission\":\"page-edit\",\"singular\":1,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"17\":{\"name\":\"ProcessPageAdd\",\"title\":\"Page Add\",\"version\":109,\"icon\":\"plus-circle\",\"permission\":\"page-edit\",\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true},\"121\":{\"name\":\"ProcessPageEditLink\",\"title\":\"Page Edit Link\",\"version\":112,\"icon\":\"link\",\"permission\":\"page-edit\",\"singular\":true,\"created\":1777585556,\"configurable\":4,\"permanent\":true},\"47\":{\"name\":\"ProcessTemplate\",\"title\":\"Templates\",\"version\":114,\"icon\":\"cubes\",\"permission\":\"template-admin\",\"created\":1777585556,\"configurable\":4,\"permanent\":true,\"useNavJSON\":true},\"12\":{\"name\":\"ProcessPageList\",\"title\":\"Page List\",\"version\":124,\"icon\":\"sitemap\",\"permission\":\"page-edit\",\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true},\"138\":{\"name\":\"ProcessProfile\",\"title\":\"User Profile\",\"version\":105,\"permission\":\"profile-edit\",\"singular\":1,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"182\":{\"name\":\"ProcessRecentPages\",\"title\":\"Recent Pages\",\"version\":2,\"icon\":\"clock-o\",\"permission\":\"page-edit-recent\",\"singular\":1,\"created\":1777585616,\"useNavJSON\":true,\"nav\":[{\"url\":\"?edited=1\",\"label\":\"Edited\",\"icon\":\"users\",\"navJSON\":\"navJSON\\/?edited=1\"},{\"url\":\"?added=1\",\"label\":\"Created\",\"icon\":\"users\",\"navJSON\":\"navJSON\\/?added=1\"},{\"url\":\"?edited=1&me=1\",\"label\":\"Edited by me\",\"icon\":\"user\",\"navJSON\":\"navJSON\\/?edited=1&me=1\"},{\"url\":\"?added=1&me=1\",\"label\":\"Created by me\",\"icon\":\"user\",\"navJSON\":\"navJSON\\/?added=1&me=1\"},{\"url\":\"another\\/\",\"label\":\"Add another\",\"icon\":\"plus-circle\",\"navJSON\":\"anotherNavJSON\\/\"}]},\"134\":{\"name\":\"ProcessPageType\",\"title\":\"Page Type\",\"version\":101,\"singular\":1,\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true,\"addFlag\":32},\"50\":{\"name\":\"ProcessModule\",\"title\":\"Modules\",\"version\":121,\"permission\":\"module-admin\",\"created\":1777585556,\"permanent\":true,\"useNavJSON\":true,\"nav\":[{\"url\":\"?site#tab_site_modules\",\"label\":\"Site\",\"icon\":\"plug\",\"navJSON\":\"navJSON\\/?site=1\"},{\"url\":\"?core#tab_core_modules\",\"label\":\"Core\",\"icon\":\"plug\",\"navJSON\":\"navJSON\\/?core=1\"},{\"url\":\"?configurable#tab_configurable_modules\",\"label\":\"Configure\",\"icon\":\"gear\",\"navJSON\":\"navJSON\\/?configurable=1\"},{\"url\":\"?install#tab_install_modules\",\"label\":\"Install\",\"icon\":\"sign-in\",\"navJSON\":\"navJSON\\/?install=1\"},{\"url\":\"?new#tab_new_modules\",\"label\":\"New\",\"icon\":\"plus\"},{\"url\":\"?reset=1\",\"label\":\"Refresh\",\"icon\":\"refresh\"}]},\"87\":{\"name\":\"ProcessHome\",\"title\":\"Admin Home\",\"version\":101,\"permission\":\"page-view\",\"created\":1777585556,\"permanent\":true},\"68\":{\"name\":\"ProcessRole\",\"title\":\"Roles\",\"version\":104,\"icon\":\"gears\",\"permission\":\"role-admin\",\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true},\"109\":{\"name\":\"ProcessPageTrash\",\"title\":\"Page Trash\",\"version\":103,\"singular\":1,\"created\":1777585556,\"permanent\":true},\"136\":{\"name\":\"ProcessPermission\",\"title\":\"Permissions\",\"version\":101,\"icon\":\"gear\",\"permission\":\"permission-admin\",\"singular\":1,\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true},\"83\":{\"name\":\"ProcessPageView\",\"title\":\"Page View\",\"version\":106,\"permission\":\"page-view\",\"created\":1777585556,\"permanent\":true},\"76\":{\"name\":\"ProcessList\",\"title\":\"List\",\"version\":101,\"permission\":\"page-view\",\"created\":1777585556,\"permanent\":true},\"7\":{\"name\":\"ProcessPageEdit\",\"title\":\"Page Edit\",\"version\":112,\"icon\":\"edit\",\"permission\":\"page-edit\",\"singular\":1,\"created\":1777585556,\"configurable\":3,\"permanent\":true,\"useNavJSON\":true},\"723\":{\"name\":\"TextformatterMarkdownExtra\",\"title\":\"Markdown\\/Parsedown Extra\",\"version\":180,\"singular\":1,\"created\":1777798259,\"configurable\":4},\"61\":{\"name\":\"TextformatterEntities\",\"title\":\"HTML Entity Encoder (htmlspecialchars)\",\"version\":100,\"created\":1777585556},\"98\":{\"name\":\"MarkupPagerNav\",\"title\":\"Pager (Pagination) Navigation\",\"version\":105,\"created\":1777585556},\"113\":{\"name\":\"MarkupPageArray\",\"title\":\"PageArray Markup\",\"version\":100,\"autoload\":true,\"singular\":true,\"created\":1777585556},\"156\":{\"name\":\"MarkupHTMLPurifier\",\"title\":\"HTML Purifier\",\"version\":497,\"created\":1777585556},\"67\":{\"name\":\"MarkupAdminDataTable\",\"title\":\"Admin Data Table\",\"version\":108,\"created\":1777585556,\"permanent\":true},\"280\":{\"name\":\"FileValidatorZip\",\"title\":\"ZIP file validator\",\"version\":1,\"icon\":\"file-archive-o\",\"created\":1777585660,\"configurable\":4,\"validates\":[\"zip\"]},\"125\":{\"name\":\"SessionLoginThrottle\",\"title\":\"Session Login Throttle\",\"version\":103,\"autoload\":\"function\",\"singular\":true,\"created\":1777585556,\"configurable\":3},\"103\":{\"name\":\"JqueryTableSorter\",\"title\":\"jQuery Table Sorter Plugin\",\"version\":\"2.31.3\",\"singular\":1,\"created\":1777585556},\"151\":{\"name\":\"JqueryMagnific\",\"title\":\"jQuery Magnific Popup\",\"version\":\"1.1.0\",\"singular\":1,\"created\":1777585556},\"116\":{\"name\":\"JqueryCore\",\"title\":\"jQuery Core\",\"version\":\"1.12.4\",\"singular\":true,\"created\":1777585556,\"permanent\":true},\"45\":{\"name\":\"JqueryWireTabs\",\"title\":\"jQuery Wire Tabs Plugin\",\"version\":110,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"117\":{\"name\":\"JqueryUI\",\"title\":\"jQuery UI\",\"version\":\"1.10.4\",\"singular\":true,\"created\":1777585556,\"permanent\":true},\"115\":{\"name\":\"PageRender\",\"title\":\"Page Render\",\"version\":105,\"autoload\":true,\"singular\":true,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"696\":{\"name\":\"FieldtypeOptions\",\"title\":\"Select Options\",\"version\":2,\"singular\":1,\"created\":1777797930},\"1\":{\"name\":\"FieldtypeTextarea\",\"title\":\"Textarea\",\"version\":107,\"created\":1777585556,\"permanent\":true},\"89\":{\"name\":\"FieldtypeFloat\",\"title\":\"Float\",\"version\":108,\"singular\":1,\"created\":1777585556,\"permanent\":true},\"135\":{\"name\":\"FieldtypeURL\",\"title\":\"URL\",\"version\":101,\"singular\":1,\"created\":1777585556,\"permanent\":true},\"57\":{\"name\":\"FieldtypeImage\",\"title\":\"Images\",\"version\":102,\"created\":1777585556,\"configurable\":4,\"permanent\":true},\"84\":{\"name\":\"FieldtypeInteger\",\"title\":\"Integer\",\"version\":102,\"created\":1777585556,\"permanent\":true},\"107\":{\"name\":\"FieldtypeFieldsetTabOpen\",\"title\":\"Fieldset in Tab (Open)\",\"version\":100,\"singular\":1,\"created\":1777585556,\"permanent\":true},\"29\":{\"name\":\"FieldtypeEmail\",\"title\":\"E-Mail\",\"version\":101,\"singular\":true,\"created\":1777585556},\"27\":{\"name\":\"FieldtypeModule\",\"title\":\"Module Reference\",\"version\":102,\"singular\":true,\"created\":1777585556,\"permanent\":true},\"106\":{\"name\":\"FieldtypeFieldsetClose\",\"title\":\"Fieldset (Close)\",\"version\":100,\"singular\":1,\"created\":1777585556,\"permanent\":true},\"97\":{\"name\":\"FieldtypeCheckbox\",\"title\":\"Checkbox\",\"version\":101,\"singular\":true,\"created\":1777585556,\"permanent\":true},\"111\":{\"name\":\"FieldtypePageTitle\",\"title\":\"Page Title\",\"version\":100,\"singular\":true,\"created\":1777585556,\"permanent\":true},\"3\":{\"name\":\"FieldtypeText\",\"title\":\"Text\",\"version\":102,\"created\":1777585556,\"permanent\":true},\"105\":{\"name\":\"FieldtypeFieldsetOpen\",\"title\":\"Fieldset (Open)\",\"version\":101,\"singular\":1,\"created\":1777585556,\"permanent\":true},\"28\":{\"name\":\"FieldtypeDatetime\",\"title\":\"Datetime\",\"version\":105,\"created\":1777585556},\"677\":{\"name\":\"FieldtypeRepeater\",\"title\":\"Repeater\",\"version\":113,\"installs\":[\"InputfieldRepeater\"],\"autoload\":true,\"singular\":true,\"created\":1777797837,\"configurable\":3},\"679\":{\"name\":\"FieldtypeFieldsetPage\",\"title\":\"Fieldset (Page)\",\"version\":1,\"requiresVersions\":{\"FieldtypeRepeater\":[\">=\",0]},\"autoload\":true,\"singular\":true,\"created\":1777797837,\"configurable\":3},\"678\":{\"name\":\"InputfieldRepeater\",\"title\":\"Repeater\",\"version\":111,\"requiresVersions\":{\"FieldtypeRepeater\":[\">=\",0]},\"created\":1777797837},\"4\":{\"name\":\"FieldtypePage\",\"title\":\"Page Reference\",\"version\":107,\"autoload\":true,\"singular\":true,\"created\":1777585556,\"configurable\":3,\"permanent\":true},\"133\":{\"name\":\"FieldtypePassword\",\"title\":\"Password\",\"version\":101,\"singular\":true,\"created\":1777585556,\"permanent\":true},\"6\":{\"name\":\"FieldtypeFile\",\"title\":\"Files\",\"version\":107,\"created\":1777585556,\"configurable\":4,\"permanent\":true},\"739\":{\"name\":\"InputfieldColor\",\"title\":\"Color\",\"version\":116,\"created\":1777798842},\"738\":{\"name\":\"FieldtypeColor\",\"title\":\"Color\",\"version\":118,\"installs\":[\"InputfieldColor\"],\"singular\":1,\"created\":1777798842},\"750\":{\"name\":\"InputfieldPageAutocomplete\",\"title\":\"Page Auto Complete\",\"version\":113}}','2026-04-30 21:46:56'),
(163,'.ModulesVerbose.info',8192,'{\"114\":{\"summary\":\"Adds various permission methods to Page objects that are used by Process modules.\",\"core\":true,\"versionStr\":\"1.0.5\"},\"139\":{\"summary\":\"Manages system versions and upgrades.\",\"core\":true,\"versionStr\":\"0.2.1\"},\"197\":{\"summary\":\"Uikit v3 admin theme\",\"core\":true,\"versionStr\":\"0.3.6\"},\"32\":{\"summary\":\"Form submit button\",\"core\":true,\"versionStr\":\"1.0.3\"},\"15\":{\"summary\":\"Selection of a single page from a ProcessWire page tree list\",\"core\":true,\"versionStr\":\"1.0.1\"},\"137\":{\"summary\":\"Selection of multiple pages from a ProcessWire page tree list\",\"core\":true,\"versionStr\":\"1.0.3\"},\"36\":{\"summary\":\"Selection of a single value from a select pulldown\",\"core\":true,\"versionStr\":\"1.0.3\"},\"25\":{\"summary\":\"Multiple selection, progressive enhancement to select multiple\",\"core\":true,\"versionStr\":\"2.0.3\"},\"41\":{\"summary\":\"Text input validated as a ProcessWire name field\",\"core\":true,\"versionStr\":\"1.0.0\"},\"94\":{\"summary\":\"Inputfield that accepts date and optionally time\",\"core\":true,\"versionStr\":\"1.0.8\"},\"238\":{\"summary\":\"Select an icon\",\"core\":true,\"versionStr\":\"0.0.3\"},\"86\":{\"summary\":\"Text input validated as a ProcessWire Page name field\",\"core\":true,\"versionStr\":\"1.0.6\"},\"122\":{\"summary\":\"Password input with confirmation field.\",\"core\":true,\"versionStr\":\"1.0.2\"},\"149\":{\"summary\":\"Build a page finding selector visually.\",\"author\":\"Avoine + ProcessWire\",\"core\":true,\"versionStr\":\"0.2.8\"},\"78\":{\"summary\":\"Groups one or more fields together in a container\",\"core\":true,\"versionStr\":\"1.0.1\"},\"85\":{\"summary\":\"Integer (positive or negative)\",\"core\":true,\"versionStr\":\"1.0.5\"},\"112\":{\"summary\":\"Handles input of Page Title and auto-generation of Page Name (when name is blank)\",\"core\":true,\"versionStr\":\"1.0.2\"},\"40\":{\"summary\":\"Hidden input in a form\",\"core\":true,\"versionStr\":\"1.0.1\"},\"56\":{\"summary\":\"One or more image uploads (sortable)\",\"core\":true,\"versionStr\":\"1.2.9\"},\"79\":{\"summary\":\"Contains any other markup and optionally child Inputfields\",\"core\":true,\"versionStr\":\"1.0.2\"},\"30\":{\"summary\":\"Contains one or more fields in a form\",\"core\":true,\"versionStr\":\"1.0.7\"},\"667\":{\"summary\":\"Enables input of user entered tags or selection of predefined tags.\",\"core\":true,\"versionStr\":\"0.0.7\"},\"155\":{\"summary\":\"TinyMCE rich text editor version 6.8.2.\",\"core\":true,\"versionStr\":\"6.1.8\"},\"55\":{\"summary\":\"One or more file uploads (sortable)\",\"core\":true,\"versionStr\":\"1.2.9\"},\"38\":{\"summary\":\"Multiple checkbox toggles\",\"core\":true,\"versionStr\":\"1.0.8\"},\"43\":{\"summary\":\"Select multiple items from a list\",\"core\":true,\"versionStr\":\"1.0.1\"},\"37\":{\"summary\":\"Single checkbox toggle\",\"core\":true,\"versionStr\":\"1.0.6\"},\"108\":{\"summary\":\"URL in valid format\",\"core\":true,\"versionStr\":\"1.0.3\"},\"90\":{\"summary\":\"Floating point number with precision\",\"core\":true,\"versionStr\":\"1.0.5\"},\"662\":{\"summary\":\"A toggle providing similar input capability to a checkbox but much more configurable.\",\"core\":true,\"versionStr\":\"0.0.1\"},\"39\":{\"summary\":\"Radio buttons for selection of a single item\",\"core\":true,\"versionStr\":\"1.0.6\"},\"60\":{\"summary\":\"Select one or more pages\",\"core\":true,\"versionStr\":\"1.0.9\"},\"131\":{\"summary\":\"Form button element that you can optionally pass an href attribute to.\",\"core\":true,\"versionStr\":\"1.0.0\"},\"35\":{\"summary\":\"Multiple lines of text\",\"core\":true,\"versionStr\":\"1.0.3\"},\"34\":{\"summary\":\"Single line of text\",\"core\":true,\"versionStr\":\"1.0.6\"},\"80\":{\"summary\":\"E-Mail address in valid format\",\"core\":true,\"versionStr\":\"1.0.2\"},\"10\":{\"summary\":\"Login to ProcessWire\",\"core\":true,\"versionStr\":\"1.0.9\"},\"14\":{\"summary\":\"Handles page sorting and moving for PageList\",\"core\":true,\"versionStr\":\"1.0.1\"},\"150\":{\"summary\":\"Admin tool for finding and listing pages by any property.\",\"author\":\"Ryan Cramer\",\"core\":true,\"versionStr\":\"0.2.6\",\"permissions\":{\"page-lister\":\"Use Page Lister\"}},\"129\":{\"summary\":\"Provides image manipulation functions for image fields and rich text editors.\",\"core\":true,\"versionStr\":\"1.2.1\"},\"48\":{\"summary\":\"Edit individual fields that hold page data\",\"core\":true,\"versionStr\":\"1.1.4\",\"searchable\":\"fields\"},\"233\":{\"summary\":\"View and manage system logs.\",\"author\":\"Ryan Cramer\",\"core\":true,\"versionStr\":\"0.0.2\",\"permissions\":{\"logs-view\":\"Can view system logs\",\"logs-edit\":\"Can manage system logs\"},\"page\":{\"name\":\"logs\",\"parent\":\"setup\",\"title\":\"Logs\"}},\"66\":{\"summary\":\"Manage system users\",\"core\":true,\"versionStr\":\"1.0.7\",\"searchable\":\"users\"},\"104\":{\"summary\":\"Provides a page search engine for admin use.\",\"core\":true,\"versionStr\":\"1.0.8\"},\"17\":{\"summary\":\"Add a new page\",\"core\":true,\"versionStr\":\"1.0.9\"},\"121\":{\"summary\":\"Provides a link capability as used by some Fieldtype modules (like rich text editors).\",\"core\":true,\"versionStr\":\"1.1.2\"},\"47\":{\"summary\":\"List and edit the templates that control page output\",\"core\":true,\"versionStr\":\"1.1.4\",\"searchable\":\"templates\"},\"12\":{\"summary\":\"List pages in a hierarchical tree structure\",\"core\":true,\"versionStr\":\"1.2.4\"},\"138\":{\"summary\":\"Enables user to change their password, email address and other settings that you define.\",\"core\":true,\"versionStr\":\"1.0.5\"},\"182\":{\"summary\":\"Shows a list of recently edited pages in your admin.\",\"author\":\"Ryan Cramer\",\"href\":\"http:\\/\\/modules.processwire.com\\/\",\"core\":true,\"versionStr\":\"0.0.2\",\"permissions\":{\"page-edit-recent\":\"Can see recently edited pages\"},\"page\":{\"name\":\"recent-pages\",\"parent\":\"page\",\"title\":\"Recent\"}},\"134\":{\"summary\":\"List, Edit and Add pages of a specific type\",\"core\":true,\"versionStr\":\"1.0.1\"},\"50\":{\"summary\":\"List, edit or install\\/uninstall modules\",\"core\":true,\"versionStr\":\"1.2.1\"},\"87\":{\"summary\":\"Acts as a placeholder Process for the admin root. Ensures proper flow control after login.\",\"core\":true,\"versionStr\":\"1.0.1\"},\"68\":{\"summary\":\"Manage user roles and what permissions are attached\",\"core\":true,\"versionStr\":\"1.0.4\"},\"109\":{\"summary\":\"Handles emptying of Page trash\",\"core\":true,\"versionStr\":\"1.0.3\"},\"136\":{\"summary\":\"Manage system permissions\",\"core\":true,\"versionStr\":\"1.0.1\"},\"83\":{\"summary\":\"All page views are routed through this Process\",\"core\":true,\"versionStr\":\"1.0.6\"},\"76\":{\"summary\":\"Lists the Process assigned to each child page of the current\",\"core\":true,\"versionStr\":\"1.0.1\"},\"7\":{\"summary\":\"Edit a Page\",\"core\":true,\"versionStr\":\"1.1.2\"},\"723\":{\"summary\":\"Markdown\\/Parsedown extra lightweight markup language by Emanuil Rusev. Based on Markdown by John Gruber.\",\"core\":true,\"versionStr\":\"1.8.0\"},\"61\":{\"summary\":\"Entity encode ampersands, quotes (single and double) and greater-than\\/less-than signs using htmlspecialchars(str, ENT_QUOTES). It is recommended that you use this on all text\\/textarea fields except those using a rich text editor or a markup language like Markdown.\",\"core\":true,\"versionStr\":\"1.0.0\"},\"98\":{\"summary\":\"Generates markup for pagination navigation\",\"core\":true,\"versionStr\":\"1.0.5\"},\"113\":{\"summary\":\"Adds renderPager() method to all PaginatedArray types, for easy pagination output. Plus a render() method to PageArray instances.\",\"core\":true,\"versionStr\":\"1.0.0\"},\"156\":{\"summary\":\"Front-end to the HTML Purifier library.\",\"core\":true,\"versionStr\":\"4.9.7\"},\"67\":{\"summary\":\"Generates markup for data tables used by ProcessWire admin\",\"core\":true,\"versionStr\":\"1.0.8\"},\"280\":{\"summary\":\"Validates ZIP files with various configurable rules.\",\"author\":\"Ryan Cramer\",\"core\":true,\"versionStr\":\"0.0.1\"},\"125\":{\"summary\":\"Throttles login attempts to help prevent dictionary attacks.\",\"core\":true,\"versionStr\":\"1.0.3\"},\"103\":{\"summary\":\"Provides a jQuery plugin for sorting tables.\",\"href\":\"https:\\/\\/mottie.github.io\\/tablesorter\\/\",\"core\":true,\"versionStr\":\"2.31.3\"},\"151\":{\"summary\":\"Provides lightbox capability for image galleries. Replacement for FancyBox. Uses Magnific Popup by @dimsemenov.\",\"href\":\"https:\\/\\/github.com\\/dimsemenov\\/Magnific-Popup\\/\",\"core\":true,\"versionStr\":\"1.1.0\"},\"116\":{\"summary\":\"jQuery Core as required by ProcessWire Admin and plugins\",\"href\":\"https:\\/\\/jquery.com\",\"core\":true,\"versionStr\":\"1.12.4\"},\"45\":{\"summary\":\"Provides a jQuery plugin for generating tabs in ProcessWire.\",\"core\":true,\"versionStr\":\"1.1.0\"},\"117\":{\"summary\":\"jQuery UI as required by ProcessWire and plugins\",\"href\":\"https:\\/\\/ui.jquery.com\",\"core\":true,\"versionStr\":\"1.10.4\"},\"115\":{\"summary\":\"Adds a render method to Page and caches page output.\",\"core\":true,\"versionStr\":\"1.0.5\"},\"696\":{\"summary\":\"Field that stores single and multi select options.\",\"core\":true,\"versionStr\":\"0.0.2\"},\"1\":{\"summary\":\"Field that stores multiple lines of text\",\"core\":true,\"versionStr\":\"1.0.7\"},\"89\":{\"summary\":\"Field that stores a floating point number\",\"core\":true,\"versionStr\":\"1.0.8\"},\"135\":{\"summary\":\"Field that stores a URL\",\"core\":true,\"versionStr\":\"1.0.1\"},\"57\":{\"summary\":\"Field that stores one or more GIF, JPG, or PNG images\",\"core\":true,\"versionStr\":\"1.0.2\"},\"84\":{\"summary\":\"Field that stores an integer\",\"core\":true,\"versionStr\":\"1.0.2\"},\"107\":{\"summary\":\"Open a fieldset to group fields. Same as Fieldset (Open) except that it displays in a tab instead.\",\"core\":true,\"versionStr\":\"1.0.0\"},\"29\":{\"summary\":\"Field that stores an e-mail address\",\"core\":true,\"versionStr\":\"1.0.1\"},\"27\":{\"summary\":\"Field that stores a reference to another module\",\"core\":true,\"versionStr\":\"1.0.2\"},\"106\":{\"summary\":\"Close a fieldset opened by FieldsetOpen. \",\"core\":true,\"versionStr\":\"1.0.0\"},\"97\":{\"summary\":\"This Fieldtype stores an ON\\/OFF toggle via a single checkbox. The ON value is 1 and OFF value is 0.\",\"core\":true,\"versionStr\":\"1.0.1\"},\"111\":{\"summary\":\"Field that stores a page title\",\"core\":true,\"versionStr\":\"1.0.0\"},\"3\":{\"summary\":\"Field that stores a single line of text\",\"core\":true,\"versionStr\":\"1.0.2\"},\"105\":{\"summary\":\"Open a fieldset to group fields. Should be followed by a Fieldset (Close) after one or more fields.\",\"core\":true,\"versionStr\":\"1.0.1\"},\"28\":{\"summary\":\"Field that stores a date and optionally time\",\"core\":true,\"versionStr\":\"1.0.5\"},\"677\":{\"summary\":\"Maintains a collection of fields that are repeated for any number of times.\",\"core\":true,\"versionStr\":\"1.1.3\"},\"679\":{\"summary\":\"Fieldset with fields isolated to separate namespace (page), enabling re-use of fields.\",\"core\":true,\"versionStr\":\"0.0.1\"},\"678\":{\"summary\":\"Repeats fields from another template. Provides the input for FieldtypeRepeater.\",\"core\":true,\"versionStr\":\"1.1.1\"},\"4\":{\"summary\":\"Field that stores one or more references to ProcessWire pages\",\"core\":true,\"versionStr\":\"1.0.7\"},\"133\":{\"summary\":\"Field that stores a hashed and salted password\",\"core\":true,\"versionStr\":\"1.0.1\"},\"6\":{\"summary\":\"Field that stores one or more files\",\"core\":true,\"versionStr\":\"1.0.7\"},\"739\":{\"summary\":\"Inputfield for colors\",\"href\":\"https:\\/\\/processwire.com\\/talk\\/topic\\/16679-fieldtypecolor\\/\",\"versionStr\":\"1.1.6\"},\"738\":{\"summary\":\"Field that stores a color value as 32bit integer reflecting a RGBA value. Many options for Input (HTML5 Inputfield Color, Textfield with changing background, various jQuery\\/JS ColorPickers, custom jQuery\\/JS\\/CSS) and Output (RGB, RGBA, HSL, HSLA, HEX, Array).\",\"href\":\"https:\\/\\/processwire.com\\/talk\\/topic\\/16679-fieldtypecolor\\/\",\"versionStr\":\"1.1.8\"},\"750\":{\"summary\":\"Multiple Page selection using auto completion and sorting capability. Intended for use as an input field for Page reference fields.\",\"core\":true,\"versionStr\":\"1.1.3\"}}','2026-04-30 21:46:56'),
(166,'.ModulesUninstalled.info',8192,'{\"SystemNotifications\":{\"name\":\"SystemNotifications\",\"title\":\"System Notifications\",\"version\":12,\"versionStr\":\"0.1.2\",\"summary\":\"Adds support for notifications in ProcessWire (currently in development)\",\"icon\":\"bell\",\"installs\":[\"FieldtypeNotifications\"],\"autoload\":true,\"created\":1777585371,\"installed\":false,\"configurable\":\"SystemNotificationsConfig.php\",\"core\":true},\"FieldtypeNotifications\":{\"name\":\"FieldtypeNotifications\",\"title\":\"Notifications\",\"version\":4,\"versionStr\":\"0.0.4\",\"summary\":\"Field that stores user notifications.\",\"requiresVersions\":{\"SystemNotifications\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeTextLanguage\":{\"name\":\"FieldtypeTextLanguage\",\"title\":\"Text (Multi-language)\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Field that stores a single line of text in multiple languages\",\"requiresVersions\":{\"LanguageSupportFields\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"ProcessLanguageTranslator\":{\"name\":\"ProcessLanguageTranslator\",\"title\":\"Language Translator\",\"version\":103,\"versionStr\":\"1.0.3\",\"author\":\"Ryan Cramer\",\"summary\":\"Provides language translation capabilities for ProcessWire core and modules.\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"permission\":\"lang-edit\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"LanguageTabs\":{\"name\":\"LanguageTabs\",\"title\":\"Languages Support - Tabs\",\"version\":117,\"versionStr\":\"1.1.7\",\"author\":\"adamspruijt, ryan, flipzoom\",\"summary\":\"Organizes multi-language fields into tabs for a cleaner easier to use interface.\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"autoload\":\"template=admin\",\"singular\":true,\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"LanguageSupportFields\":{\"name\":\"LanguageSupportFields\",\"title\":\"Languages Support - Fields\",\"version\":101,\"versionStr\":\"1.0.1\",\"author\":\"Ryan Cramer\",\"summary\":\"Required to use multi-language fields.\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"installs\":[\"FieldtypePageTitleLanguage\",\"FieldtypeTextareaLanguage\",\"FieldtypeTextLanguage\"],\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"core\":true},\"ProcessLanguage\":{\"name\":\"ProcessLanguage\",\"title\":\"Languages\",\"version\":103,\"versionStr\":\"1.0.3\",\"author\":\"Ryan Cramer\",\"summary\":\"Manage system languages\",\"icon\":\"language\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"permission\":\"lang-edit\",\"permissions\":{\"lang-edit\":\"Administer languages and static translation files\"},\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true,\"useNavJSON\":true},\"FieldtypePageTitleLanguage\":{\"name\":\"FieldtypePageTitleLanguage\",\"title\":\"Page Title (Multi-Language)\",\"version\":100,\"versionStr\":\"1.0.0\",\"author\":\"Ryan Cramer\",\"summary\":\"Field that stores a page title in multiple languages. Use this only if you want title inputs created for ALL languages on ALL pages. Otherwise create separate languaged-named title fields, i.e. title_fr, title_es, title_fi, etc. \",\"requiresVersions\":{\"LanguageSupportFields\":[\">=\",0],\"FieldtypeTextLanguage\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeTextareaLanguage\":{\"name\":\"FieldtypeTextareaLanguage\",\"title\":\"Textarea (Multi-language)\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Field that stores a multiple lines of text in multiple languages\",\"requiresVersions\":{\"LanguageSupportFields\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"LanguageSupportPageNames\":{\"name\":\"LanguageSupportPageNames\",\"title\":\"Languages Support - Page Names\",\"version\":14,\"versionStr\":\"0.1.4\",\"author\":\"Ryan Cramer\",\"summary\":\"Required to use multi-language page names.\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0],\"LanguageSupportFields\":[\">=\",0]},\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"LanguageSupport\":{\"name\":\"LanguageSupport\",\"title\":\"Languages Support\",\"version\":104,\"versionStr\":\"1.0.4\",\"author\":\"Ryan Cramer\",\"summary\":\"ProcessWire multi-language support.\",\"installs\":[\"ProcessLanguage\",\"ProcessLanguageTranslator\"],\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true,\"addFlag\":32},\"PageFrontEdit\":{\"name\":\"PageFrontEdit\",\"title\":\"Front-End Page Editor\",\"version\":6,\"versionStr\":\"0.0.6\",\"author\":\"Ryan Cramer\",\"summary\":\"Enables front-end editing of page fields.\",\"icon\":\"cube\",\"permissions\":{\"page-edit-front\":\"Use the front-end page editor\"},\"autoload\":true,\"created\":1777585371,\"installed\":false,\"configurable\":\"PageFrontEditConfig.php\",\"core\":true,\"license\":\"MPL 2.0\"},\"AdminThemeReno\":{\"name\":\"AdminThemeReno\",\"title\":\"Reno\",\"version\":17,\"versionStr\":\"0.1.7\",\"author\":\"Tom Reno (Renobird)\",\"summary\":\"Admin theme for ProcessWire 2.5+ by Tom Reno (Renobird)\",\"requiresVersions\":{\"AdminThemeDefault\":[\">=\",0]},\"autoload\":\"template=admin\",\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"AdminThemeUikit\":{\"name\":\"AdminThemeUikit\",\"title\":\"Uikit\",\"version\":36,\"versionStr\":\"0.3.6\",\"summary\":\"Uikit v3 admin theme\",\"icon\":\"smile-o\",\"autoload\":\"template=admin\",\"created\":1777585616,\"installed\":false,\"configurable\":4,\"core\":true},\"PagePaths\":{\"name\":\"PagePaths\",\"title\":\"Page Paths\",\"version\":4,\"versionStr\":\"0.0.4\",\"summary\":\"Enables page paths\\/urls to be queryable by selectors. Also offers potential for improved load performance. Builds an index at install (may take time on a large site).\",\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"InputfieldCKEditor\":{\"name\":\"InputfieldCKEditor\",\"title\":\"CKEditor\",\"version\":172,\"versionStr\":\"1.7.2\",\"summary\":\"CKEditor textarea rich text editor.\",\"installs\":[\"MarkupHTMLPurifier\"],\"created\":1777585371,\"installed\":false,\"core\":true},\"InputfieldIcon\":{\"name\":\"InputfieldIcon\",\"title\":\"Icon\",\"version\":3,\"versionStr\":\"0.0.3\",\"summary\":\"Select an icon\",\"created\":1777585371,\"installed\":false,\"core\":true},\"InputfieldTextTags\":{\"name\":\"InputfieldTextTags\",\"title\":\"Text Tags\",\"version\":7,\"versionStr\":\"0.0.7\",\"summary\":\"Enables input of user entered tags or selection of predefined tags.\",\"icon\":\"tags\",\"created\":1777585371,\"installed\":false,\"core\":true},\"InputfieldPageAutocomplete\":{\"name\":\"InputfieldPageAutocomplete\",\"title\":\"Page Auto Complete\",\"version\":113,\"versionStr\":\"1.1.3\",\"summary\":\"Multiple Page selection using auto completion and sorting capability. Intended for use as an input field for Page reference fields.\",\"created\":1777585371,\"installed\":false,\"core\":true},\"InputfieldToggle\":{\"name\":\"InputfieldToggle\",\"title\":\"Toggle\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"A toggle providing similar input capability to a checkbox but much more configurable.\",\"created\":1777585371,\"installed\":false,\"core\":true},\"InputfieldPageTable\":{\"name\":\"InputfieldPageTable\",\"title\":\"ProFields: Page Table\",\"version\":14,\"versionStr\":\"0.1.4\",\"summary\":\"Inputfield to accompany FieldtypePageTable\",\"requiresVersions\":{\"FieldtypePageTable\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"ProcessPagesExportImport\":{\"name\":\"ProcessPagesExportImport\",\"title\":\"Pages Export\\/Import\",\"version\":1,\"versionStr\":\"0.0.1\",\"author\":\"Ryan Cramer\",\"summary\":\"Enables exporting and importing of pages. Development version, not yet recommended for production use.\",\"icon\":\"paper-plane-o\",\"permission\":\"page-edit-export\",\"created\":1777585371,\"installed\":false,\"core\":true,\"page\":{\"name\":\"export-import\",\"parent\":\"page\",\"title\":\"Export\\/Import\"}},\"ProcessLogger\":{\"name\":\"ProcessLogger\",\"title\":\"Logs\",\"version\":2,\"versionStr\":\"0.0.2\",\"author\":\"Ryan Cramer\",\"summary\":\"View and manage system logs.\",\"icon\":\"tree\",\"permission\":\"logs-view\",\"permissions\":{\"logs-view\":\"Can view system logs\",\"logs-edit\":\"Can manage system logs\"},\"created\":1777585371,\"installed\":false,\"core\":true,\"page\":{\"name\":\"logs\",\"parent\":\"setup\",\"title\":\"Logs\"},\"useNavJSON\":true},\"ProcessPageClone\":{\"name\":\"ProcessPageClone\",\"title\":\"Page Clone\",\"version\":106,\"versionStr\":\"1.0.6\",\"summary\":\"Provides ability to clone\\/copy\\/duplicate pages in the admin. Adds a &quot;copy&quot; option to all applicable pages in the PageList.\",\"permission\":\"page-clone\",\"permissions\":{\"page-clone\":\"Clone a page\",\"page-clone-tree\":\"Clone a tree of pages\"},\"autoload\":\"template=admin\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true,\"page\":{\"name\":\"clone\",\"title\":\"Clone\",\"parent\":\"page\",\"status\":1024}},\"ProcessRecentPages\":{\"name\":\"ProcessRecentPages\",\"title\":\"Recent Pages\",\"version\":2,\"versionStr\":\"0.0.2\",\"author\":\"Ryan Cramer\",\"summary\":\"Shows a list of recently edited pages in your admin.\",\"href\":\"http:\\/\\/modules.processwire.com\\/\",\"icon\":\"clock-o\",\"permission\":\"page-edit-recent\",\"permissions\":{\"page-edit-recent\":\"Can see recently edited pages\"},\"singular\":1,\"created\":1777585616,\"installed\":false,\"core\":true,\"page\":{\"name\":\"recent-pages\",\"parent\":\"page\",\"title\":\"Recent\"},\"useNavJSON\":true,\"nav\":[{\"url\":\"?edited=1\",\"label\":\"Edited\",\"icon\":\"users\",\"navJSON\":\"navJSON\\/?edited=1\"},{\"url\":\"?added=1\",\"label\":\"Created\",\"icon\":\"users\",\"navJSON\":\"navJSON\\/?added=1\"},{\"url\":\"?edited=1&me=1\",\"label\":\"Edited by me\",\"icon\":\"user\",\"navJSON\":\"navJSON\\/?edited=1&me=1\"},{\"url\":\"?added=1&me=1\",\"label\":\"Created by me\",\"icon\":\"user\",\"navJSON\":\"navJSON\\/?added=1&me=1\"},{\"url\":\"another\\/\",\"label\":\"Add another\",\"icon\":\"plus-circle\",\"navJSON\":\"anotherNavJSON\\/\"}]},\"ProcessForgotPassword\":{\"name\":\"ProcessForgotPassword\",\"title\":\"Forgot Password\",\"version\":104,\"versionStr\":\"1.0.4\",\"summary\":\"Provides password reset\\/email capability for the Login process.\",\"permission\":\"page-view\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"ProcessCommentsManager\":{\"name\":\"ProcessCommentsManager\",\"title\":\"Comments\",\"version\":12,\"versionStr\":\"0.1.2\",\"author\":\"Ryan Cramer\",\"summary\":\"Manage comments in your site outside of the page editor.\",\"icon\":\"comments\",\"requiresVersions\":{\"FieldtypeComments\":[\">=\",0]},\"permission\":\"comments-manager\",\"permissions\":{\"comments-manager\":\"Use the comments manager\"},\"created\":1777585371,\"installed\":false,\"searchable\":\"comments\",\"core\":true,\"page\":{\"name\":\"comments\",\"parent\":\"setup\",\"title\":\"Comments\"},\"nav\":[{\"url\":\"?go=approved\",\"label\":\"Approved\"},{\"url\":\"?go=pending\",\"label\":\"Pending\"},{\"url\":\"?go=spam\",\"label\":\"Spam\"},{\"url\":\"?go=all\",\"label\":\"All\"}]},\"TextformatterSmartypants\":{\"name\":\"TextformatterSmartypants\",\"title\":\"SmartyPants Typographer\",\"version\":171,\"versionStr\":\"1.7.1\",\"summary\":\"Smart typography for web sites, by Michel Fortin based on SmartyPants by John Gruber. If combined with Markdown, it should be applied AFTER Markdown.\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true,\"url\":\"https:\\/\\/github.com\\/michelf\\/php-smartypants\"},\"TextformatterNewlineUL\":{\"name\":\"TextformatterNewlineUL\",\"title\":\"Newlines to Unordered List\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Converts newlines to <li> list items and surrounds in an <ul> unordered list. \",\"created\":1777585371,\"installed\":false,\"core\":true},\"TextformatterStripTags\":{\"name\":\"TextformatterStripTags\",\"title\":\"Strip Markup Tags\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Strips HTML\\/XHTML Markup Tags\",\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"TextformatterNewlineBR\":{\"name\":\"TextformatterNewlineBR\",\"title\":\"Newlines to XHTML Line Breaks\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Converts newlines to XHTML line break <br \\/> tags. \",\"created\":1777585371,\"installed\":false,\"core\":true},\"TextformatterMarkdownExtra\":{\"name\":\"TextformatterMarkdownExtra\",\"title\":\"Markdown\\/Parsedown Extra\",\"version\":180,\"versionStr\":\"1.8.0\",\"summary\":\"Markdown\\/Parsedown extra lightweight markup language by Emanuil Rusev. Based on Markdown by John Gruber.\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"TextformatterPstripper\":{\"name\":\"TextformatterPstripper\",\"title\":\"Paragraph Stripper\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Strips paragraph <p> tags that may have been applied by other text formatters before it. \",\"created\":1777585371,\"installed\":false,\"core\":true},\"MarkupPageFields\":{\"name\":\"MarkupPageFields\",\"title\":\"Markup Page Fields\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Adds $page->renderFields() and $page->images->render() methods that return basic markup for output during development and debugging.\",\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"core\":true,\"permanent\":true},\"MarkupRSS\":{\"name\":\"MarkupRSS\",\"title\":\"Markup RSS Feed\",\"version\":105,\"versionStr\":\"1.0.5\",\"summary\":\"Renders an RSS feed. Given a PageArray, renders an RSS feed of them.\",\"icon\":\"rss-square\",\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"MarkupCache\":{\"name\":\"MarkupCache\",\"title\":\"Markup Cache\",\"version\":101,\"versionStr\":\"1.0.1\",\"summary\":\"A simple way to cache segments of markup in your templates. \",\"href\":\"https:\\/\\/processwire.com\\/api\\/modules\\/markupcache\\/\",\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"FileValidatorZip\":{\"name\":\"FileValidatorZip\",\"title\":\"ZIP file validator\",\"version\":1,\"versionStr\":\"0.0.1\",\"author\":\"Ryan Cramer\",\"summary\":\"Validates ZIP files with various configurable rules.\",\"icon\":\"file-archive-o\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true,\"validates\":[\"zip\"]},\"ProcessSessionDB\":{\"name\":\"ProcessSessionDB\",\"title\":\"Sessions\",\"version\":5,\"versionStr\":\"0.0.5\",\"summary\":\"Enables you to browse active database sessions.\",\"icon\":\"dashboard\",\"requiresVersions\":{\"SessionHandlerDB\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true,\"page\":{\"name\":\"sessions-db\",\"parent\":\"access\",\"title\":\"Sessions\"}},\"SessionHandlerDB\":{\"name\":\"SessionHandlerDB\",\"title\":\"Session Handler Database\",\"version\":6,\"versionStr\":\"0.0.6\",\"summary\":\"Installing this module makes ProcessWire store sessions in the database rather than the file system. Note that this module will log you out after install or uninstall.\",\"installs\":[\"ProcessSessionDB\"],\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"PagesVersions\":{\"name\":\"PagesVersions\",\"title\":\"Pages Versions\",\"version\":2,\"versionStr\":\"0.0.2\",\"author\":\"Ryan Cramer\",\"summary\":\"Provides a version control API for pages in ProcessWire.\",\"icon\":\"code-fork\",\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"core\":true},\"ImageSizerEngineAnimatedGif\":{\"name\":\"ImageSizerEngineAnimatedGif\",\"title\":\"Animated GIF Image Sizer\",\"version\":1,\"versionStr\":\"0.0.1\",\"author\":\"Horst Nogajski\",\"summary\":\"Upgrades image manipulations for animated GIFs.\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"ImageSizerEngineIMagick\":{\"name\":\"ImageSizerEngineIMagick\",\"title\":\"IMagick Image Sizer\",\"version\":3,\"versionStr\":\"0.0.3\",\"author\":\"Horst Nogajski\",\"summary\":\"Upgrades image manipulations to use PHP\'s ImageMagick library when possible.\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"FileCompilerTags\":{\"name\":\"FileCompilerTags\",\"title\":\"Tags File Compiler\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Enables {var} or {var.property} variables in markup sections of a file. Can be used with any API variable.\",\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"PagePathHistory\":{\"name\":\"PagePathHistory\",\"title\":\"Page Path History\",\"version\":8,\"versionStr\":\"0.0.8\",\"summary\":\"Keeps track of past URLs where pages have lived and automatically redirects (301 permanent) to the new location whenever the past URL is accessed.\",\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"configurable\":4,\"core\":true},\"LazyCron\":{\"name\":\"LazyCron\",\"title\":\"Lazy Cron\",\"version\":104,\"versionStr\":\"1.0.4\",\"summary\":\"Provides hooks that are automatically executed at various intervals. It is called \'lazy\' because it\'s triggered by a pageview, so the interval is guaranteed to be at least the time requested, rather than exactly the time requested. This is fine for most cases, but you can make it not lazy by connecting this to a real CRON job. See the module file for details. \",\"href\":\"https:\\/\\/processwire.com\\/api\\/modules\\/lazy-cron\\/\",\"autoload\":true,\"singular\":true,\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeOptions\":{\"name\":\"FieldtypeOptions\",\"title\":\"Select Options\",\"version\":2,\"versionStr\":\"0.0.2\",\"summary\":\"Field that stores single and multi select options.\",\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeDecimal\":{\"name\":\"FieldtypeDecimal\",\"title\":\"Decimal\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Field that stores a decimal number\",\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypePageTable\":{\"name\":\"FieldtypePageTable\",\"title\":\"ProFields: Page Table\",\"version\":8,\"versionStr\":\"0.0.8\",\"summary\":\"A fieldtype containing a group of editable pages.\",\"installs\":[\"InputfieldPageTable\"],\"autoload\":true,\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeSelector\":{\"name\":\"FieldtypeSelector\",\"title\":\"Selector\",\"version\":13,\"versionStr\":\"0.1.3\",\"author\":\"Avoine + ProcessWire\",\"summary\":\"Build a page finding selector visually.\",\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeToggle\":{\"name\":\"FieldtypeToggle\",\"title\":\"Toggle (Yes\\/No)\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Configurable yes\\/no, on\\/off toggle alternative to a checkbox, plus optional \\u201cother\\u201d option.\",\"requiresVersions\":{\"InputfieldToggle\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeCache\":{\"name\":\"FieldtypeCache\",\"title\":\"Cache\",\"version\":102,\"versionStr\":\"1.0.2\",\"summary\":\"Caches the values of other fields for fewer runtime queries. Can also be used to combine multiple text fields and have them all be searchable under the cached field name.\",\"created\":1777585371,\"installed\":false,\"core\":true},\"CommentFilterAkismet\":{\"name\":\"CommentFilterAkismet\",\"title\":\"Comment Filter: Akismet\",\"version\":200,\"versionStr\":\"2.0.0\",\"summary\":\"Uses the Akismet service to identify comment spam. Module plugin for the Comments Fieldtype.\",\"requiresVersions\":{\"FieldtypeComments\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"FieldtypeComments\":{\"name\":\"FieldtypeComments\",\"title\":\"Comments\",\"version\":110,\"versionStr\":\"1.1.0\",\"summary\":\"Field that stores user posted comments for a single Page\",\"installs\":[\"InputfieldCommentsAdmin\"],\"created\":1777585371,\"installed\":false,\"core\":true},\"InputfieldCommentsAdmin\":{\"name\":\"InputfieldCommentsAdmin\",\"title\":\"Comments Admin\",\"version\":104,\"versionStr\":\"1.0.4\",\"summary\":\"Provides an administrative interface for working with comments\",\"requiresVersions\":{\"FieldtypeComments\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"FieldtypeFieldsetPage\":{\"name\":\"FieldtypeFieldsetPage\",\"title\":\"Fieldset (Page)\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Fieldset with fields isolated to separate namespace (page), enabling re-use of fields.\",\"requiresVersions\":{\"FieldtypeRepeater\":[\">=\",0]},\"autoload\":true,\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"FieldtypeRepeater\":{\"name\":\"FieldtypeRepeater\",\"title\":\"Repeater\",\"version\":113,\"versionStr\":\"1.1.3\",\"summary\":\"Maintains a collection of fields that are repeated for any number of times.\",\"installs\":[\"InputfieldRepeater\"],\"autoload\":true,\"created\":1777585371,\"installed\":false,\"configurable\":3,\"core\":true},\"InputfieldRepeater\":{\"name\":\"InputfieldRepeater\",\"title\":\"Repeater\",\"version\":111,\"versionStr\":\"1.1.1\",\"summary\":\"Repeats fields from another template. Provides the input for FieldtypeRepeater.\",\"requiresVersions\":{\"FieldtypeRepeater\":[\">=\",0]},\"created\":1777585371,\"installed\":false,\"core\":true},\"AdminThemeDefault\":{\"name\":\"AdminThemeDefault\",\"title\":\"Default\",\"version\":14,\"versionStr\":\"0.1.4\",\"summary\":\"Minimal admin theme that supports all ProcessWire features.\",\"autoload\":\"template=admin\",\"created\":1777585371,\"installed\":false,\"configurable\":19,\"core\":true},\"FieldtypeOptionsColor\":{\"name\":\"FieldtypeOptionsColor\",\"title\":\"Select Color Options\",\"version\":102,\"versionStr\":\"1.0.2\",\"summary\":\"Field that stores colors as single and multi select options.\",\"requiresVersions\":{\"FieldtypeOptions\":[\">=\",0]},\"installs\":[\"FieldtypeOptions\"],\"created\":1777798785,\"installed\":false}}','2026-04-30 21:46:56'),
(168,'.ModulesVersions.info',8192,'[]','2026-04-30 21:46:56'),
(182,'ProcessRecentPages',1,'','2026-04-30 21:46:56'),
(197,'AdminThemeUikit',10,'{\"useAsLogin\":\"\",\"themeName\":\"default\",\"defaultStyleName\":\"light\",\"defaultToggles\":[\"useInputFocus\"],\"defaultMainColor\":\"custom\",\"defaultMainColorCustom\":\"#3197b9\",\"defaultMainColorCustomDark\":\"#eb1d61\",\"defaultCustomCssFile\":\"\",\"userAvatar\":\"icon.user-circle\",\"userLabel\":\"{Name}\",\"logoURL\":\"\",\"logoAction\":\"0\",\"layout\":\"\",\"ukGrid\":\"0\",\"maxWidth\":1600,\"groupNotices\":\"1\",\"cssURL\":\"\",\"inputSize\":\"m\",\"noBorderTypes\":[],\"offsetTypes\":[],\"toggleBehavior\":\"0\"}','2026-04-30 21:46:56'),
(233,'ProcessLogger',1,'','2026-04-30 21:47:07'),
(238,'InputfieldIcon',0,'','2026-04-30 21:47:07'),
(280,'FileValidatorZip',0,'','2026-04-30 21:47:40'),
(662,'InputfieldToggle',0,'','2026-05-03 08:42:33'),
(667,'InputfieldTextTags',0,'','2026-05-03 08:42:33'),
(677,'FieldtypeRepeater',3,'{\"repeatersRootPageID\":1015}','2026-05-03 08:43:57'),
(678,'InputfieldRepeater',0,'','2026-05-03 08:43:57'),
(679,'FieldtypeFieldsetPage',3,'{\"repeatersRootPageID\":1015}','2026-05-03 08:43:57'),
(696,'FieldtypeOptions',1,'','2026-05-03 08:45:30'),
(723,'TextformatterMarkdownExtra',1,'','2026-05-03 08:50:59'),
(738,'FieldtypeColor',1,'','2026-05-03 09:00:42'),
(739,'InputfieldColor',0,'','2026-05-03 09:00:42'),
(750,'InputfieldPageAutocomplete',0,'','2026-06-03 19:57:50');
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT 0,
  `templates_id` int(11) unsigned NOT NULL DEFAULT 0,
  `name` varchar(128) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT 1,
  `modified` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT 2,
  `created` timestamp NOT NULL DEFAULT '2015-12-18 05:09:00',
  `created_users_id` int(10) unsigned NOT NULL DEFAULT 2,
  `published` datetime DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_parent_id` (`name`,`parent_id`),
  KEY `parent_id` (`parent_id`),
  KEY `templates_id` (`templates_id`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `status` (`status`),
  KEY `published` (`published`)
) ENGINE=InnoDB AUTO_INCREMENT=1089 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1,'home',9,'2026-06-10 10:28:19',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',0),
(2,1,2,'pwadmin',1035,'2026-04-30 21:46:56',40,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',5),
(3,2,2,'page',21,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',0),
(6,3,2,'add',21,'2026-04-30 21:47:09',40,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',1),
(7,1,2,'trash',1039,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',6),
(8,3,2,'list',21,'2026-04-30 21:47:09',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',0),
(9,3,2,'sort',1047,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',3),
(10,3,2,'edit',1045,'2026-04-30 21:47:09',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',4),
(11,22,2,'template',21,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',0),
(16,22,2,'field',21,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',2),
(21,2,2,'module',21,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',2),
(22,2,2,'setup',21,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',1),
(23,2,2,'login',1035,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',4),
(27,1,29,'http404',1035,'2026-06-11 08:33:31',41,'2026-04-30 21:45:56',3,'2026-04-30 23:45:56',4),
(28,2,2,'access',13,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',3),
(29,28,2,'users',29,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',0),
(30,28,2,'roles',29,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',1),
(31,28,2,'permissions',29,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',2),
(32,31,5,'page-edit',25,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',2),
(34,31,5,'page-delete',25,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',3),
(35,31,5,'page-move',25,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',4),
(36,31,5,'page-view',25,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',0),
(37,30,4,'guest',25,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',0),
(38,30,4,'superuser',25,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',1),
(40,29,3,'guest',25,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',1),
(41,29,3,'berry-admin',1,'2026-04-30 21:46:56',40,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',0),
(50,31,5,'page-sort',25,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',5),
(51,31,5,'page-template',25,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',6),
(52,31,5,'user-admin',25,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',10),
(53,31,5,'profile-edit',1,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',13),
(54,31,5,'page-lock',1,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',8),
(300,3,2,'search',1045,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',6),
(301,3,2,'trash',1047,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',6),
(302,3,2,'link',1041,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',7),
(303,3,2,'image',1041,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',8),
(304,2,2,'profile',1025,'2026-04-30 21:45:56',41,'2026-04-30 21:45:56',41,'2026-04-30 23:45:56',5),
(1006,31,5,'page-lister',1,'2026-04-30 21:45:56',40,'2026-04-30 21:45:56',40,'2026-04-30 23:45:56',9),
(1007,3,2,'lister',1,'2026-04-30 21:45:56',40,'2026-04-30 21:45:56',40,'2026-04-30 23:45:56',9),
(1010,3,2,'recent-pages',1,'2026-04-30 21:46:56',40,'2026-04-30 21:46:56',40,'2026-04-30 23:46:56',10),
(1011,31,5,'page-edit-recent',1,'2026-04-30 21:46:56',40,'2026-04-30 21:46:56',40,'2026-04-30 23:46:56',10),
(1012,22,2,'logs',1,'2026-04-30 21:47:07',40,'2026-04-30 21:47:07',40,'2026-04-30 23:47:07',2),
(1013,31,5,'logs-view',1,'2026-04-30 21:47:07',40,'2026-04-30 21:47:07',40,'2026-04-30 23:47:07',11),
(1014,31,5,'logs-edit',1,'2026-04-30 21:47:07',40,'2026-04-30 21:47:07',40,'2026-04-30 23:47:07',12),
(1015,2,2,'repeaters',1036,'2026-05-03 08:43:57',41,'2026-05-03 08:43:57',41,'2026-05-03 10:43:57',6),
(1016,1015,2,'for-field-98',17,'2026-05-03 08:43:57',41,'2026-05-03 08:43:57',41,'2026-05-03 10:43:57',0),
(1017,1015,2,'for-field-107',17,'2026-05-03 08:49:15',41,'2026-05-03 08:49:15',41,'2026-05-03 10:49:15',1),
(1018,1,45,'site-settings',1057,'2026-06-11 08:26:32',41,'2026-05-03 21:00:15',41,'2026-05-03 23:01:57',3),
(1019,1,47,'mainmenu',1025,'2026-06-08 07:16:49',41,'2026-05-04 08:24:01',41,'2026-05-04 10:24:09',4),
(1020,1019,46,'home',1,'2026-05-04 08:26:49',41,'2026-05-04 08:26:07',41,'2026-05-04 10:26:49',0),
(1021,1019,46,'project',1,'2026-05-04 08:27:16',41,'2026-05-04 08:27:08',41,'2026-05-04 10:27:11',1),
(1022,1019,46,'contact-us',1,'2026-05-04 08:27:43',41,'2026-05-04 08:27:38',41,'2026-05-04 10:27:43',4),
(1023,1016,43,'for-page-1',1,'2026-06-10 10:28:19',41,'2026-05-04 09:46:14',41,'2026-05-04 11:46:14',0),
(1024,1017,2,'for-page-1',17,'2026-05-04 09:46:14',41,'2026-05-04 09:46:14',41,'2026-05-04 11:46:14',0),
(1025,1024,44,'1777888762-363-1',1,'2026-06-10 09:26:28',41,'2026-05-04 09:59:22',41,'2026-05-04 11:59:45',0),
(1026,7,29,'1026.1.5_project',8193,'2026-05-27 08:54:20',41,'2026-05-04 10:11:42',41,'2026-05-04 12:13:29',5),
(1027,1016,43,'for-page-1026',1,'2026-05-27 08:54:20',41,'2026-05-04 10:11:42',41,'2026-05-04 12:13:29',1),
(1028,1017,2,'for-page-1026',17,'2026-05-04 10:11:42',41,'2026-05-04 10:11:42',41,'2026-05-04 12:11:42',1),
(1029,1016,43,'for-page-27',1025,'2026-06-11 08:33:31',41,'2026-05-04 10:12:04',40,'2026-05-04 12:12:04',2),
(1030,1028,44,'1777889548-7339-1',1,'2026-05-04 10:45:18',41,'2026-05-04 10:12:28',41,'2026-05-04 12:13:29',0),
(1031,7,46,'1031.1019.2_results',8193,'2026-05-27 08:28:20',41,'2026-05-12 20:22:45',41,'2026-05-12 22:22:52',2),
(1032,1019,46,'news-events',1,'2026-05-27 08:28:32',41,'2026-05-12 20:23:28',41,'2026-05-12 22:23:34',2),
(1034,1,48,'project',1,'2026-06-10 10:27:15',41,'2026-05-27 08:54:30',41,'2026-05-27 10:55:53',5),
(1035,1016,43,'for-page-1034',1,'2026-06-10 10:27:15',41,'2026-05-27 08:54:30',41,'2026-05-27 10:55:53',3),
(1036,1,49,'goals',5,'2026-06-03 19:43:12',41,'2026-05-27 09:42:44',41,'2026-05-27 11:43:26',6),
(1037,1036,50,'emitter-development',1,'2026-06-10 12:17:09',41,'2026-05-27 09:46:14',41,'2026-05-27 11:46:36',0),
(1038,1036,50,'sensor-development',1,'2026-06-05 07:19:26',41,'2026-05-27 09:46:57',41,'2026-05-27 11:47:09',1),
(1039,1036,50,'sensor-evaluation',1,'2026-06-05 07:17:39',41,'2026-05-27 09:47:19',41,'2026-05-27 11:47:32',2),
(1040,1,51,'highlights',1,'2026-06-11 08:25:17',41,'2026-06-03 19:42:48',41,'2026-06-03 21:42:48',7),
(1041,7,52,'1041.1040._paper-xyz-presented-at-brightmeeting-2026',8193,'2026-06-03 19:54:09',41,'2026-06-03 19:43:57',41,'2026-06-03 21:43:59',0),
(1042,1040,52,'news-one',1,'2026-06-10 12:09:15',41,'2026-06-03 19:55:45',41,'2026-06-03 21:58:11',2),
(1043,1016,43,'for-page-1040',1,'2026-06-11 08:25:17',41,'2026-06-03 21:51:06',41,'2026-06-03 23:51:06',4),
(1044,1040,52,'news-two',1,'2026-06-03 22:00:13',41,'2026-06-03 21:59:17',41,'2026-06-04 00:00:09',1),
(1045,1,53,'contact-us',1,'2026-06-11 08:25:40',41,'2026-06-03 22:11:56',41,'2026-06-04 00:12:09',8),
(1046,1016,43,'for-page-1045',1,'2026-06-11 08:25:40',41,'2026-06-03 22:13:26',41,'2026-06-04 00:13:26',5),
(1047,1040,52,'highlight-12',1,'2026-06-10 12:09:28',41,'2026-06-05 07:35:45',41,'2026-06-05 09:36:28',0),
(1048,1040,52,'highlight-123',1,'2026-06-05 07:38:27',41,'2026-06-05 07:37:30',41,'2026-06-05 09:38:27',3),
(1049,1015,2,'for-field-116',17,'2026-06-06 22:10:18',41,'2026-06-06 22:10:18',41,'2026-06-07 00:10:18',2),
(1050,1049,2,'for-page-1045',17,'2026-06-06 22:11:43',41,'2026-06-06 22:11:43',41,'2026-06-07 00:11:43',0),
(1051,1050,54,'1780783926-5017-1',1,'2026-06-11 08:25:40',41,'2026-06-06 22:12:06',41,'2026-06-07 00:13:03',0),
(1052,1050,54,'1780783949-7018-1',1,'2026-06-11 08:24:01',41,'2026-06-06 22:12:29',41,'2026-06-07 00:13:03',1),
(1054,7,29,'1054.1.9_test-page',8193,'2026-06-11 08:28:57',41,'2026-06-07 21:34:44',41,'2026-06-07 23:35:28',9),
(1055,1016,43,'for-page-1054',1,'2026-06-11 08:28:57',41,'2026-06-07 21:34:44',41,'2026-06-07 23:35:28',6),
(1056,1017,2,'for-page-1054',17,'2026-06-07 21:34:44',41,'2026-06-07 21:34:44',41,'2026-06-07 23:34:44',2),
(1057,1056,44,'1780868099-8521-1',1,'2026-06-07 21:35:32',41,'2026-06-07 21:34:59',41,'2026-06-07 23:35:28',0),
(1058,1,55,'partners',1,'2026-06-11 08:25:03',41,'2026-06-08 07:16:07',41,'2026-06-08 09:16:09',10),
(1059,1019,46,'partners',1,'2026-06-08 07:16:48',41,'2026-06-08 07:16:25',41,'2026-06-08 09:16:33',3),
(1060,1017,2,'for-page-1058',17,'2026-06-08 08:07:17',41,'2026-06-08 08:07:17',41,'2026-06-08 10:07:17',3),
(1061,1016,43,'for-page-1058',1,'2026-06-11 08:25:03',41,'2026-06-08 08:14:53',40,'2026-06-08 10:14:53',7),
(1062,1058,56,'universita-di-trento',1,'2026-06-10 09:17:18',41,'2026-06-08 08:18:16',41,'2026-06-08 10:20:08',0),
(1063,1017,2,'for-page-1062',17,'2026-06-08 08:18:16',41,'2026-06-08 08:18:16',41,'2026-06-08 10:18:16',4),
(1064,1058,56,'4k-mems',1,'2026-06-10 12:04:46',41,'2026-06-08 08:20:29',41,'2026-06-08 10:20:47',1),
(1065,1017,2,'for-page-1064',17,'2026-06-08 08:20:29',41,'2026-06-08 08:20:29',41,'2026-06-08 10:20:29',5),
(1066,1016,43,'for-page-1062',1,'2026-06-10 09:17:18',41,'2026-06-08 09:24:37',40,'2026-06-08 11:24:37',8),
(1067,1065,44,'1780910815-5072-1',1,'2026-06-10 12:04:46',41,'2026-06-08 09:26:55',41,'2026-06-08 11:27:31',0),
(1068,1016,43,'for-page-1064',1,'2026-06-10 12:04:46',41,'2026-06-08 09:27:31',41,'2026-06-08 11:27:31',9),
(1069,1065,44,'1780913644-2588-1',1,'2026-06-10 12:04:46',41,'2026-06-08 10:14:04',41,'2026-06-08 12:14:29',1),
(1070,1065,44,'1780913655-4635-1',1,'2026-06-10 09:20:27',41,'2026-06-08 10:14:15',41,'2026-06-08 12:14:29',2),
(1071,1063,44,'1780914019-8385-1',1,'2026-06-10 09:16:06',41,'2026-06-08 10:20:19',41,'2026-06-08 12:20:59',0),
(1072,1063,44,'1780914027-6634-1',1,'2026-06-10 09:17:07',41,'2026-06-08 10:20:27',41,'2026-06-08 12:20:59',1),
(1074,1015,2,'for-field-124',17,'2026-06-10 10:17:50',41,'2026-06-10 10:17:50',41,'2026-06-10 12:17:50',3),
(1075,1074,2,'for-page-1023',17,'2026-06-10 10:18:27',41,'2026-06-10 10:18:27',41,'2026-06-10 12:18:27',0),
(1076,1075,57,'1781086714-3014-1',1,'2026-06-10 10:28:12',41,'2026-06-10 10:18:34',41,'2026-06-10 12:19:00',0),
(1077,1075,57,'1781086723-4816-1',1,'2026-06-10 10:28:12',41,'2026-06-10 10:18:43',41,'2026-06-10 12:19:00',1),
(1078,1075,57,'1781086736-4478-1',1,'2026-06-10 10:28:12',41,'2026-06-10 10:18:56',41,'2026-06-10 12:19:00',2),
(1079,1074,2,'for-page-1035',17,'2026-06-10 10:26:29',41,'2026-06-10 10:26:29',41,'2026-06-10 12:26:29',1),
(1083,1074,2,'for-page-1068',17,'2026-06-10 12:04:24',41,'2026-06-10 12:04:24',41,'2026-06-10 14:04:24',2),
(1084,1074,2,'for-page-1043',17,'2026-06-10 12:07:33',41,'2026-06-10 12:07:33',41,'2026-06-10 14:07:33',3),
(1085,1074,2,'for-page-1061',17,'2026-06-10 12:07:56',41,'2026-06-10 12:07:56',41,'2026-06-10 14:07:56',4),
(1086,1074,2,'for-page-1046',17,'2026-06-10 12:09:58',41,'2026-06-10 12:09:58',41,'2026-06-10 14:09:58',5),
(1087,1017,2,'for-page-27',17,'2026-06-11 08:29:23',41,'2026-06-11 08:29:23',41,'2026-06-11 10:29:23',6),
(1088,1074,2,'for-page-1029',17,'2026-06-11 08:29:23',41,'2026-06-11 08:29:23',41,'2026-06-11 10:29:23',6);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_access`
--

DROP TABLE IF EXISTS `pages_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages_access` (
  `pages_id` int(11) NOT NULL,
  `templates_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`pages_id`),
  KEY `templates_id` (`templates_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_access`
--

LOCK TABLES `pages_access` WRITE;
/*!40000 ALTER TABLE `pages_access` DISABLE KEYS */;
INSERT INTO `pages_access` VALUES
(32,2,'2026-04-30 21:45:56'),
(34,2,'2026-04-30 21:45:56'),
(35,2,'2026-04-30 21:45:56'),
(36,2,'2026-04-30 21:45:56'),
(37,2,'2026-04-30 21:45:56'),
(38,2,'2026-04-30 21:45:56'),
(50,2,'2026-04-30 21:45:56'),
(51,2,'2026-04-30 21:45:56'),
(52,2,'2026-04-30 21:45:56'),
(53,2,'2026-04-30 21:45:56'),
(54,2,'2026-04-30 21:45:56'),
(1006,2,'2026-04-30 21:45:56'),
(1011,2,'2026-04-30 21:46:56'),
(1013,2,'2026-04-30 21:47:07'),
(1014,2,'2026-04-30 21:47:07'),
(1018,1,'2026-05-03 21:00:15'),
(1019,1,'2026-05-04 08:24:01'),
(1020,1,'2026-05-04 08:26:07'),
(1021,1,'2026-05-04 08:27:08'),
(1022,1,'2026-05-04 08:27:38'),
(1023,2,'2026-05-04 09:46:14'),
(1025,2,'2026-05-04 09:59:22'),
(1026,2,'2026-05-27 08:54:20'),
(1027,2,'2026-05-04 10:11:42'),
(1029,2,'2026-05-04 10:12:04'),
(1030,2,'2026-05-04 10:12:28'),
(1031,2,'2026-05-27 08:28:20'),
(1032,1,'2026-05-12 20:23:28'),
(1034,1,'2026-05-27 08:54:30'),
(1035,2,'2026-05-27 08:54:30'),
(1036,1,'2026-05-27 09:42:44'),
(1037,1,'2026-05-27 09:46:14'),
(1038,1,'2026-05-27 09:46:57'),
(1039,1,'2026-05-27 09:47:19'),
(1040,1,'2026-06-03 19:42:48'),
(1041,2,'2026-06-03 19:54:09'),
(1042,1,'2026-06-03 19:55:45'),
(1043,2,'2026-06-03 21:51:06'),
(1044,1,'2026-06-03 21:59:17'),
(1045,1,'2026-06-03 22:11:56'),
(1046,2,'2026-06-03 22:13:26'),
(1047,1,'2026-06-05 07:35:45'),
(1048,1,'2026-06-05 07:37:30'),
(1051,2,'2026-06-06 22:12:06'),
(1052,2,'2026-06-06 22:12:29'),
(1054,2,'2026-06-11 08:28:57'),
(1055,2,'2026-06-07 21:34:44'),
(1057,2,'2026-06-07 21:34:59'),
(1058,1,'2026-06-08 07:16:07'),
(1059,1,'2026-06-08 07:16:25'),
(1061,2,'2026-06-08 08:14:53'),
(1062,1,'2026-06-08 08:18:16'),
(1064,1,'2026-06-08 08:20:29'),
(1066,2,'2026-06-08 09:24:37'),
(1067,2,'2026-06-08 09:26:55'),
(1068,2,'2026-06-08 09:27:31'),
(1069,2,'2026-06-08 10:14:04'),
(1070,2,'2026-06-08 10:14:15'),
(1071,2,'2026-06-08 10:20:19'),
(1072,2,'2026-06-08 10:20:27'),
(1076,2,'2026-06-10 10:18:34'),
(1077,2,'2026-06-10 10:18:43'),
(1078,2,'2026-06-10 10:18:56');
/*!40000 ALTER TABLE `pages_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_parents`
--

DROP TABLE IF EXISTS `pages_parents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages_parents` (
  `pages_id` int(10) unsigned NOT NULL,
  `parents_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`parents_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_parents`
--

LOCK TABLES `pages_parents` WRITE;
/*!40000 ALTER TABLE `pages_parents` DISABLE KEYS */;
INSERT INTO `pages_parents` VALUES
(2,1),
(3,1),
(3,2),
(7,1),
(22,1),
(22,2),
(28,1),
(28,2),
(29,1),
(29,2),
(29,28),
(30,1),
(30,2),
(30,28),
(31,1),
(31,2),
(31,28),
(1015,2),
(1016,2),
(1016,1015),
(1017,2),
(1017,1015),
(1024,2),
(1024,1015),
(1024,1017),
(1026,7),
(1028,2),
(1028,1015),
(1028,1017),
(1031,7),
(1041,7),
(1049,2),
(1049,1015),
(1050,2),
(1050,1015),
(1050,1049),
(1054,7),
(1056,2),
(1056,1015),
(1056,1017),
(1063,2),
(1063,1015),
(1063,1017),
(1065,2),
(1065,1015),
(1065,1017),
(1074,2),
(1074,1015),
(1075,2),
(1075,1015),
(1075,1074),
(1079,2),
(1079,1015),
(1079,1074);
/*!40000 ALTER TABLE `pages_parents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_sortfields`
--

DROP TABLE IF EXISTS `pages_sortfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages_sortfields` (
  `pages_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sortfield` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_sortfields`
--

LOCK TABLES `pages_sortfields` WRITE;
/*!40000 ALTER TABLE `pages_sortfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages_sortfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_login_throttle`
--

DROP TABLE IF EXISTS `session_login_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `session_login_throttle` (
  `name` varchar(128) NOT NULL,
  `attempts` int(10) unsigned NOT NULL DEFAULT 0,
  `last_attempt` int(10) unsigned NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_login_throttle`
--

LOCK TABLES `session_login_throttle` WRITE;
/*!40000 ALTER TABLE `session_login_throttle` DISABLE KEYS */;
INSERT INTO `session_login_throttle` VALUES
('berry-admin',1,1781082936);
/*!40000 ALTER TABLE `session_login_throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templates`
--

DROP TABLE IF EXISTS `templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `fieldgroups_id` int(10) unsigned NOT NULL DEFAULT 0,
  `flags` int(11) NOT NULL DEFAULT 0,
  `cache_time` mediumint(9) NOT NULL DEFAULT 0,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `fieldgroups_id` (`fieldgroups_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templates`
--

LOCK TABLES `templates` WRITE;
/*!40000 ALTER TABLE `templates` DISABLE KEYS */;
INSERT INTO `templates` VALUES
(1,'home',1,0,0,'{\"useRoles\":1,\"noParents\":1,\"childTemplates\":[29,45,47,48,49,51,53,55],\"slashUrls\":1,\"pageLabelField\":\"fa-home title\",\"compile\":0,\"modified\":1781087379,\"ns\":\"ProcessWire\",\"_lazy\":1,\"roles\":[37]}'),
(2,'admin',2,8,0,'{\"useRoles\":1,\"parentTemplates\":[2],\"allowPageNum\":1,\"redirectLogin\":23,\"slashUrls\":1,\"noGlobal\":1,\"compile\":3,\"modified\":1777585371,\"ns\":\"ProcessWire\"}'),
(3,'user',3,8,0,'{\"useRoles\":1,\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"User\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}'),
(4,'role',4,8,0,'{\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"Role\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}'),
(5,'permission',5,8,0,'{\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"guestSearchable\":1,\"pageClass\":\"Permission\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}'),
(29,'basic-page',83,0,0,'{\"slashUrls\":1,\"pageLabelField\":\"fa-pencil title\",\"compile\":0,\"modified\":1777889493,\"ns\":\"ProcessWire\",\"_lazy\":1}'),
(43,'repeater_hero_fieldset',97,8,0,'{\"noChildren\":1,\"noParents\":1,\"slashUrls\":1,\"pageClass\":\"FieldsetPage\",\"pageLabelField\":\"for_page_path\",\"noGlobal\":1,\"compile\":3,\"modified\":1777797879,\"_lazy\":\"*\"}'),
(44,'repeater_imagetext',98,8,0,'{\"noChildren\":1,\"noParents\":1,\"slashUrls\":1,\"pageClass\":\"RepeaterPage\",\"noGlobal\":1,\"compile\":3,\"modified\":1777798157,\"_lazy\":1}'),
(45,'site-settings',99,0,0,'{\"noChildren\":1,\"noParents\":-1,\"parentTemplates\":[1],\"slashUrls\":1,\"pageLabelField\":\"fa-cogs title\",\"compile\":0,\"modified\":1781085759,\"_lazy\":1}'),
(46,'menu-item',100,0,0,'{\"childTemplates\":[46],\"parentTemplates\":[46,47],\"slashUrls\":1,\"pageLabelField\":\"fa-link title\",\"compile\":0,\"modified\":1777882610,\"_lazy\":1}'),
(47,'menu',101,0,0,'{\"childTemplates\":[46],\"slashUrls\":1,\"pageLabelField\":\"fa-bars title\",\"compile\":0,\"modified\":1777882830,\"_lazy\":1}'),
(48,'project',102,0,0,'{\"noChildren\":1,\"noParents\":-1,\"parentTemplates\":[1],\"slashUrls\":1,\"compile\":0,\"modified\":1781087379,\"ns\":\"ProcessWire\",\"_lazy\":1}'),
(49,'Goals',103,0,0,'{\"noParents\":-1,\"childTemplates\":[50],\"parentTemplates\":[1],\"slashUrls\":1,\"compile\":0,\"modified\":1779874901,\"_lazy\":1}'),
(50,'Goal',104,0,0,'{\"noChildren\":1,\"parentTemplates\":[49],\"slashUrls\":1,\"compile\":0,\"modified\":1780643814,\"_lazy\":1}'),
(51,'Highlights',105,0,0,'{\"noParents\":-1,\"childTemplates\":[52],\"parentTemplates\":[1],\"slashUrls\":1,\"compile\":0,\"modified\":1781087379,\"ns\":\"ProcessWire\",\"_lazy\":1}'),
(52,'Highlight',106,0,0,'{\"noChildren\":1,\"parentTemplates\":[51],\"slashUrls\":1,\"pageLabelField\":\"fa-lightbulb-o title\",\"compile\":0,\"modified\":1781087379,\"ns\":\"ProcessWire\",\"_lazy\":1}'),
(53,'contact-us',107,0,0,'{\"noParents\":-1,\"parentTemplates\":[1],\"slashUrls\":1,\"compile\":0,\"modified\":1781087379,\"ns\":\"ProcessWire\",\"_lazy\":1}'),
(54,'repeater_contact_cards',108,8,0,'{\"noChildren\":1,\"noParents\":1,\"slashUrls\":1,\"pageClass\":\"RepeaterPage\",\"noGlobal\":1,\"compile\":3,\"modified\":1780783818}'),
(55,'partners',109,0,0,'{\"noParents\":-1,\"childTemplates\":[56],\"parentTemplates\":[1],\"slashUrls\":1,\"compile\":0,\"modified\":1781087379,\"ns\":\"ProcessWire\",\"_lazy\":1}'),
(56,'partner',110,0,0,'{\"noChildren\":1,\"parentTemplates\":[55],\"slashUrls\":1,\"compile\":0,\"modified\":1781087379,\"ns\":\"ProcessWire\",\"_lazy\":1}'),
(57,'repeater_multi_line_title',111,8,0,'{\"noChildren\":1,\"noParents\":1,\"slashUrls\":1,\"pageClass\":\"RepeaterPage\",\"noGlobal\":1,\"compile\":3,\"modified\":1781086670}');
/*!40000 ALTER TABLE `templates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-11 11:04:32
